<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/21
 * Time: 11:21
 */

namespace app\model;


use think\Model;
use app\library\MongoQuery;
class WithdrawOrder extends Model
{
    use MongoQuery;

    protected $table="withdraw_order";
    protected $database="mongo_order_db";
    protected $connection="mongo_order_db";

    protected $dataType = [
        'agent_id'=>'int',
        'pkg_id'=>'int',
        'username'=>'string',
        'platform_id'=>'string',
        'merch_agent_id'=>'int',
        'order_no'=>'string',
        'order_type'=>'int',
        'type'=>'int',
        'card_no'=>'string',
        'card_user'=>'string',
        'card_bank'=>'string',
        'card_sub_bank'=>'string',
        'money'=>'double',
        'fee'=>'double',
        'administrative_fee'=>'double',
        'discount_fee'=>'double',
        'real_money'=>'double',
        'is_first'=>'int',
        'status'=>'int',
        'create_time'=>'int',
        'cach_month'=>'int',
        'cach_day'=>'int',
        'cach_hour'=>'int',
        'apply_time'=>'int',
        'cach_time'=>'int',
        'operator'=>'string',
        'remark'=>'string',
        'gold_status'=>'int',
        'apply_hour'=>'int',
        'apply_day'=>'int',
        'apply_month'=>'int',
    ];

    public function getParam(Array $param): Array
    {
        $agent_id = $param['agent_id'] ?? '';
        $username = $param['username'] ?? '';
        $merch_agent_id = $param['merch_agent_id'] ?? 0;
        $order_no = $param['order_no'] ?? '';
        $order_type = $param['order_type'] ?? 0;
        $card_no = $param['card_no'] ?? '';
        $card_user = $param['card_user'] ?? '';
        $card_bank = $param['card_bank'] ?? '';
        $status = $param['status'] ?? -1;
        $amount_min = $param['amount_min'] ?? 0;
        $amount_max = $param['amount_max'] ?? 0;

        $create_start_time = $param['create_start_time'] ?? '';
        $create_end_time = $param['create_end_time'] ?? '';

        $apply_start_time = $param['apply_start_time'] ?? '';
        $apply_end_time = $param['apply_end_time'] ?? '';

        $where = [];
        if ($agent_id != '') {
            $where['agent_id'] = (int) $agent_id;
        }
        if ($username) {
            $where['username'] = $username;
            if (is_array($username)) {
                $where['username'] = ['$in' => $username];
            }
        }
        if ($merch_agent_id) {
            $where['merch_agent_id'] = (int) $merch_agent_id;
        }
        if ($order_type) {
            $where['order_type'] = (int) $order_type;
        }
        if ($card_no) {
            $where['card_no'] = is_array($card_no)?['$in'=>$card_no]:$card_no;
        }
        if ($order_no) {
            $where['order_no'] = is_array($order_no)?['$in'=>$order_no]:$order_no;;
        }
        if ($card_user) {
            $where['card_user'] = $card_user;
        }
        if ($card_bank) {
            $where['card_bank'] = $card_bank;
        }
        if ($status !== -1) {
            $where['status'] = (int) $status;
            if (is_array($status)) {
                $where['status'] = ['$in' => $status];
            }
        }

        if ($amount_min) {
            $where['money'] = ['$gte' => (double)$amount_min];
        }
        if ($amount_max) {
            $tmp = ['$lte' => (double)$amount_max];
            if (!empty($where['money'])) {
                $where['money'] = array_merge($where['money'], $tmp);
            } else {
                $where['money'] = $tmp;
            }
        }

        if ($create_start_time) {
            $where['create_time'] = ['$gte' => strtotime($create_start_time)];
        }
        if ($create_end_time) {
            $tmp = ['$lte' => strtotime($create_end_time)];
            if (!empty($where['create_time'])) {
                $where['create_time'] = array_merge($where['create_time'], $tmp);
            } else {
                $where['create_time'] = $tmp;
            }
        }

        if ($apply_start_time) {
            $where['apply_time'] = ['$gte' => strtotime($apply_start_time)];
        }
        if ($apply_end_time) {
            $tmp = ['$lte' => strtotime($apply_end_time)];
            if (!empty($where['apply_time'])) {
                $where['apply_time'] = array_merge($where['apply_time'], $tmp);
            } else {
                $where['apply_time'] = $tmp;
            }
        }

        $where = $this->getTypeData($where);
        return $where;
    }


    public function findOrder($param,$field,$sort=[]){

        $where = $this -> getParam($param);
        if(empty($where)){
            return [];
        }

        $list = $this -> findData($where,$field,$sort);

        return $list;
    }

    public function getOrderCount($param){

        $where = $this -> getParam($param);

        if(empty($where)){
            return [];
        }

        $list = $this -> counts($where);

        return $list;
    }

    public function updatesOrder($param,$data){

        $where = $this -> getParam($param);
        if(empty($where)){
            return [];
        }
        $res = $this -> updateData($where,$data);

        return $res;
    }
}