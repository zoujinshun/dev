<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/22
 * Time: 19:03
 */

namespace app\model;


use think\Model;
use app\library\MongoQuery;
class Order extends Model
{
    use MongoQuery;

    protected $table = "order";
    protected $database = "mongo_order_db";
    protected $connection = "mongo_order_db";

    const ORDER_ONLINE = 1;

    protected $dataType = [
        'agent_id'        => 'int',
        'pkg_id'          => 'int',
        'username'        => 'string',
        'order_name'      => 'string',
        'merch_agent_id'  => 'int',
        'order_no'        => 'string',
        'payline_id'      => 'int',
        'payment_id'      => 'int',
        'pay_receiver_id' => 'int',
        'amount'          => 'double',
        'vaild_bet'       => 'double',
        'deduce_amount'   => 'double',
        'deduce_bet'      => 'double',
        'real_amount'     => 'double',
        'payed_amount'    => 'double',
        'out_trade_no'    => 'string',
        'order_status'    => 'int',
        'pay_status'      => 'int',
        'gold_status'     => 'int',
        'notify_time'     => 'int', //到账时间
        'create_time'     => 'int',
        'create_month'    => 'int',
        'notify_month'    => 'int',
        'notify_day'      => 'int',
        'notify_hour'     => 'int',
        'is_first_order'  => 'int',
        'remark'          => 'string',
        'operator'        => 'string',
        'channel_type'    => 'string',
    ];

    public function insertOrder($param)
    {

        $record = [
            'agent_id'        => $param['agent_id'],
            'pkg_id'          => $param['pkg_id'] ?? 0,
            'username'        => $param['username'],
            'order_name'      => $param['order_name'] ?? '',
            'merch_agent_id'  => $param['merch_agent_id'],
            'order_no'        => $param['order_no'],
            'payline_id'      => $param['payline_id'],
            'payment_id'      => $param['payment_id'],
            'pay_receiver_id' => $param['pay_receiver_id'] ?? 0,
            'amount'          => (float)$param['amount'],
            'valid_bet'       => (float)$param['valid_bet'] ?? 0.00,
            'deduce_amount'   => (float)$param['deduce_amount'] ?? 0.00,
            'deduce_bet'      => (float)$param['deduce_bet'] ?? 0.00,
            'real_amount'     => 0,
            'payed_amount'    => 0,
            'out_trade_no'    => '',
            'order_status'    => $param['order_status'] ?? 0,
            'pay_status'      => 0,
            'gold_status'     => 0,
            'notify_time'     => 0,
            'create_time'     => $param['create_time'] ?? time(),
            'create_month'    => $param['create_month'] ?? date('Ym'),
            'notify_month'    => 0,
            'notify_day'      => 0,
            'notify_hour'     => 0,
            'is_first_order'  => $param['is_first_order'] ?? 0,
            'remark'          => $param['remark'] ?? '',
            'operator'        => $param['operator'] ?? '',
            'channel_type'    => $param['channel_type'] ?? '',
        ];

        $res = $this->insertData($record);

        return $res;
    }

    public function getOrder($order_no,$field){

        $where = ['order_no' => $order_no];

        $order = $this -> findData($where,$field);

        return $order;
    }

    public function updateOrder($order_no,$data){

        $where = ['order_no' => $order_no];

        $res = $this -> updateAllData($where,$data);

        return $res;
    }
}