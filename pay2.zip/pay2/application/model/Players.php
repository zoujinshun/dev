<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/20
 * Time: 17:53
 */

namespace app\model;


use think\Model;
use app\library\MongoQuery;
class Players extends Model
{
    use MongoQuery;

    protected $table = "tb_players";
    protected $database = "mongo_dh_players";
    protected $connection = "mongo_dh_players";

    public function getWhereParam(array $param = []): array
    {
        $platform_id = $param['platform_id'] ?? '';//会员账户
        $mobile_phone = $param['mobile_phone'] ?? '';//手机号码
        $vip_level = $param['vip_level'] ?? '';//VIP等级ID
        $level_setting_id = $param['level_setting_id'] ?? '';//用户层级ID
        $pusername = $param['pusername'] ?? '';//上级代理ID
        $parent_platform_id = $param['parent_platform_id'] ?? '';//上级代理账户
        $pkg_id = $param['pkg_id'] ?? '';     //注册来源中文包名
        $pkg_name = $param['pkg_name'] ?? '';     //注册来源中文包名
        $pkg_en_name = $param['pkg_en_name'] ?? '';     //注册来源英文包名
        $pkg_type = $param['pkg_type'] ?? '';     //注册来源类型
        $agent_id = $param['agent_id'] ?? ''; //当前代理ID
        $platform_type = $param['platform_type'] ?? ''; //当前代理ID
        $username = $param['username'] ?? ''; //当前会员ID
        $user_status = $param['user_status'] ?? ''; //用户状态，1正常，2冻结，3停权
        $mode = $param['mode'] ?? '';                 //代理模式
        $device_id = $param['device_id'] ?? '';       //设备号
        $realname = $param['realnamerealname'] ?? '';       //真实姓名
        $promote_level_id = $param['promote_level_id'] ?? 0; //代理等级id
        //累计充值
        $start_total_deposit = $param['start_total_deposit'] ?? 0;
        $end_total_deposit = $param['end_total_deposit'] ?? 0;
        //累计有效投注区间
        $start_valid_bet = $param['start_valid_bet'] ?? 0;
        $end_valid_bet = $param['end_valid_bet'] ?? 0;
        //累计晋级奖金
        $start_promote_gold = $param['start_promote_gold'] ?? 0;
        $end_promote_gold = $param['end_promote_gold'] ?? 0;
        //累计月奖金
        $start_month_gold = $param['start_month_gold'] ?? 0;
        $end_month_gold = $param['end_month_gold'] ?? 0;
        //累计周奖金
        $start_week_gold = $param['start_week_gold'] ?? 0;
        $end_week_gold = $param['end_week_gold'] ?? 0;
        //累计领取   包含 周奖金 月奖金 晋级奖金
        $start_get_gold = $param['start_get_gold'] ?? 0;
        $end_get_gold = $param['end_get_gold'] ?? 0;
        //注册ip
        $register_ip = $param['register_ip'] ?? 0;
        //注册时间
        $register_time = $param['register_time'] ?? '';
        //注册时间区间
        $start_register_time = $param['start_register_time'] ?? '';
        $end_register_time = $param['end_register_time'] ?? '';
        //注册时间天 区间
        $start_register_day = $param['start_register_day'] ?? '';
        $end_register_day = $param['end_register_day'] ?? '';
        // 首次成为有效代理的时间
        $subuser_first_day_start = $param['subuser_first_day_start'] ?? '';
        $subuser_first_day_end = $param['subuser_first_day_end'] ?? '';

        $where = ['account_type' => ['$nin' => [self::ACCOUNT_TYPE_TRAINING,
            null]]];
        if ($agent_id) {
            $where['agent_id'] = $agent_id;
        }
        if ($platform_type) {
            $where['platform_type'] = $platform_type;
        }

        if ($platform_id) {
            $where['platform_id'] = $platform_id;
            if (is_array($platform_id)) {
                $where['platform_id'] = ['$in' => $platform_id];
            }
        }
        if ($username) {
            if (!is_array($username)) {
                $username = [$username];
            }
            $where['username'] = ['$in' => $username];
        }
        if ($mobile_phone) {
            $where['mobile_phone'] = $mobile_phone;
        }
        if ($vip_level) {
            $where['vip_level'] = $vip_level;
        }
        if ($level_setting_id) {
            $where['level_setting_id'] = $level_setting_id;
            if (is_array($level_setting_id)) {
                $where['level_setting_id'] = ['$in' => $level_setting_id];
            }
            else {
                $level_setting_id_array = explode(",", $level_setting_id);
                if(count($level_setting_id_array) > 1) {
                    foreach ($level_setting_id_array as &$lsia) {
                        $lsia = intval($lsia);
                    }
                    unset($lsia);
                    $where['level_setting_id'] = ['$in' => $level_setting_id_array];
                }
            }
        }
        if ($pusername) {
            $where['pusername'] = $pusername;
            if (is_array($pusername)) {
                $where['pusername'] = ['$in' => $pusername];
            }
        }
        if ($parent_platform_id) {
            $where['parent_platform_id'] = $parent_platform_id;
            if (is_array($parent_platform_id)) {
                $where['level_setting_id'] = ['$in' => $parent_platform_id];
            }
        }
        if ($pkg_name) {
            $where['pkg_name'] = $pkg_name;
        }
        if ($pkg_en_name) {
            $where['pkg_en_name'] = $pkg_en_name;
        }
        if ($pkg_type) {
            $where['pkg_type'] = $pkg_type;
        }
        if ($pkg_id) {
            $where['pkg_id'] = $pkg_id;
        }
        if ($user_status) {
            $where['user_status'] = $user_status;
        }
        if ($mode) {
            $where['mode'] = $mode;
        }
        if ($device_id) {
            $where['register_device_id'] = $device_id;
        }
        if ($realname) {
            $where['realname'] = $realname;
        }
        if ($promote_level_id) {
            $where['promote_last_level_id'] = $promote_level_id;
        }

        if ($start_valid_bet) {//总有效投注
            $where['valid_bet'] = [
                '$gte' => (double) $start_valid_bet,
            ];
        }
        if ($end_valid_bet) {
            $tmp = [
                '$lte' => (double) $end_valid_bet,
            ];
            if (isset($where['valid_bet'])) {
                $where['valid_bet'] = array_merge($where['valid_bet'], $tmp);
            } else {
                $where['valid_bet'] = $tmp;
            }
        }

        if ($start_total_deposit) {//总存款
            $where['total_deposit'] = [
                '$gte' => (double) $start_total_deposit,
            ];
        }
        if ($end_total_deposit) {
            $tmp = [
                '$lte' => (double) $end_total_deposit,
            ];
            if (isset($where['total_deposit'])) {
                $where['total_deposit'] = array_merge($where['total_deposit'], $tmp);
            } else {
                $where['total_deposit'] = $tmp;
            }
        }

        if ($start_promote_gold) {//累计晋级奖金
            $where['total_vip_gift'] = [
                '$gte' => (double) $start_promote_gold,
            ];
        }
        if ($end_promote_gold) {
            $tmp = [
                '$lte' => (double) $end_promote_gold,
            ];
            if (isset($where['total_vip_gift'])) {
                $where['total_vip_gift'] = array_merge($where['total_vip_gift'], $tmp);
            } else {
                $where['total_vip_gift'] = $tmp;
            }
        }

        if ($start_month_gold) {//累计月奖金
            $where['total_month_gift'] = [
                '$gte' => (double) $start_month_gold,
            ];
        }
        if ($end_month_gold) {
            $tmp = [
                '$lte' => (double) $end_month_gold,
            ];
            if (isset($where['total_month_gift'])) {
                $where['total_month_gift'] = array_merge($where['total_month_gift'], $tmp);
            } else {
                $where['total_month_gift'] = $tmp;
            }
        }

        if ($start_week_gold) {//累计周奖金
            $where['total_week_gift'] = [
                '$gte' => (double) $start_week_gold,
            ];
        }
        if ($end_week_gold) {
            $tmp = [
                '$lte' => (double) $end_week_gold,
            ];
            if (isset($where['total_week_gift'])) {
                $where['total_week_gift'] = array_merge($where['total_week_gift'], $tmp);
            } else {
                $where['total_week_gift'] = $tmp;
            }
        }


        if (!empty($register_ip)) { //注册IP
            $where['register_ip'] = $register_ip;
            if (is_array($register_ip)) {
                $where['register_ip'] = ['$in' => $register_ip];
            }
        }
        if ($start_get_gold) {//累计领取奖金
            $where['total_vipweekmonth_recvd'] = [
                '$gte' => (double) $start_get_gold,
            ];
        }
        if ($end_get_gold) {
            $tmp = [
                '$lte' => (double) $end_get_gold,
            ];
            if (isset($where['total_vipweekmonth_recvd'])) {
                $where['total_vipweekmonth_recvd'] = array_merge($where['total_vipweekmonth_recvd'], $tmp);
            } else {
                $where['total_vipweekmonth_recvd'] = $tmp;
            }
        }

        if ($start_register_time) {
            $where['register_time'] = [
                '$gte' => strtotime($start_register_time),
            ];
        }
        if ($end_register_time) {
            $tmp = [
                '$lte' => strtotime($end_register_time),
            ];
            if (!empty($where['register_time'])) {
                $where['register_time'] = array_merge($where['register_time'], $tmp);
            } else {
                $where['register_time'] = $tmp;
            }
        }
        if ($register_time) { //注册时间
            $where['register_time'] = strtotime($register_time);
        }
        if ($start_register_day) {
            $where['register_day'] = [
                '$gte' => (int) date("Ymd", strtotime($start_register_day)),
            ];
        }
        if ($end_register_day) {
            $tmp = [
                '$lte' => (int) date("Ymd", strtotime($end_register_day)),
            ];
            if (!empty($where['register_day'])) {
                $where['register_day'] = array_merge($where['register_day'], $tmp);
            } else {
                $where['register_day'] = $tmp;
            }
        }
        if ($subuser_first_day_start) {
            $where['subuser_first_day'] = [
                '$gte' => (int) date("Ymd", strtotime($subuser_first_day_start)),
            ];
        }
        if ($subuser_first_day_end) {
            $tmp = [
                '$lte' => (int) date("Ymd", strtotime($subuser_first_day_end)),
            ];
            if (!empty($where['subuser_first_day'])) {
                $where['subuser_first_day'] = array_merge($where['subuser_first_day'], $tmp);
            } else {
                $where['subuser_first_day'] = $tmp;
            }
        }
        $where = $this->getTypeData($where);
        return $where;
    }

    public function findUserByUsername($username,$field='*'){

        $where = ['username' => $username];

        $user = $this -> findData($where,$field);

        return $user;
    }

    public function increments($param, $data)
    {
        $where = $this -> getWhereParam($param);

        $ret = $this -> incrementData($where,$data);

        return $ret;
    }
}