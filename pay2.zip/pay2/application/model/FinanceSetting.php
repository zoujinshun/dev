<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/22
 * Time: 9:52
 */

namespace app\model;


use think\Db;
use think\Model;

class FinanceSetting extends Model
{

    public function findFinanceSetting($agent_id,$field=''){
        $where = ['agent_id'=>$agent_id];

        !$field && $field = 'charge_online_min,charge_online_max,charge_online_rate,charge_online_betrate';

        $record = $this
                    -> field($field)
                    -> where($where)
                    -> find();
//        $record = Db::name($this->name) ->field($field)-> where($where) -> find();

        if(empty($record)){
            return [];
        }
        return $record;
    }
}