<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/20
 * Time: 17:39
 */

namespace app\model;


use think\Model;

class MerchAgentSetting extends Model
{
    public function findMerch($merch_agent_id,$field){

        $where = ['id'=>$merch_agent_id];

        $merch = $this
                    -> field($field)
                    -> where($where)
                    -> find();
        if(empty($merch)){
            return [];
        }
        return $merch -> toArray();
    }

    public function getAllMerchs($param,$field,$sort=''){

        if(empty($param)){
            return [];
        }

        $where = [];

        foreach($param as $key=>$value){

            if(is_array($value)){
                $where[] = [$key,'in',$value];
            }else{
                $where[] = [$key,'=',$value];
            }
        }

        $list = $this -> findAllData($where,$field,'',$sort);

        return $list;
    }
}