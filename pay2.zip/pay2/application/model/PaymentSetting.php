<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/22
 * Time: 9:56
 */

namespace app\model;


use think\Model;

class PaymentSetting extends Model
{
    const SWITCH_ON = 1;
    const SWITCH_OFF = 0;

    public function findAllPayments($agent_id,$payment_id){

        $where = ['a.agent_id'=>$agent_id,'payment_id'=>$payment_id,'a.switch'=>self::SWITCH_ON,'a.is_delete'=>self::SWITCH_OFF];

        $field = 'a.id,a.agent_id,merch_agent_id,a.merch_code,a.channel_type,a.weight,min,max,limit,total_limit,valid_time,loop_time,payment_name,payment_id,level_ids,b.merch_no,private_key,public_key,md5_key';

        $list = $this
                    -> alias('a')
                    -> setOption('field',[])
                    -> field($field)
                    -> join('merch_agent_setting b','a.merch_agent_id=b.id','left')
                    -> setOption('where',[])
                    -> where($where)
                    -> order('weight')
//                    -> fetchSql()
                    -> select();
        //echo $list;die;
        if(empty($list)){
            return [];
        }
        return $list -> toArray();
    }

    public function findPayment($payment_id,$merch_agent_id,$field=''){

        $where['payment_id'] = $payment_id;
        $where['merch_agent_id'] = $merch_agent_id;

        $payment = $this
                    -> field($field)
                    -> where($where)
                    -> find();
        if(empty($payment)){
            return [];
        }
        return $payment;
    }
}