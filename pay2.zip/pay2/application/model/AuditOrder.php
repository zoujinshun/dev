<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/21
 * Time: 11:41
 */

namespace app\model;


use app\library\MongoQuery;
use common\Keys;
use MongoDB\BSON\ObjectId;
use think\Db;
use app\library\MysqlRawQuery;
use app\library\facade\model\{WithdrawOrder as WithdrawOrderModel, PayIncomeDb};
use think\facade\Log;
use think\Model;

class AuditOrder extends Model
{
    use MongoQuery;
    protected $table = "audit_order";
    protected $database = "mongo_order_db";
    protected $connection = "mongo_order_db";

    protected $dataType = [
        'agent_id' => 'int',
        'username' => 'string',
        'withdraw_order' => 'string',
        'withdraw_create_time' => 'int',
        'money' => 'double',
        'order_no' => 'string',
        'opt_type' => 'int',
        'amount' => 'double',
        'deduce_amount' => 'double',
        'valid_bet' => 'double',
        'deduce_bet' => 'double',
        'normal_bet' => 'double',
        'normal_status' => 'int',
        'deduce_status' => 'int',
        'normal_fee' => 'double',
        'deduce_fee' => 'double',
        'normal_rate' => 'double',
        'deduce_rate' => 'double',
        'balance' => 'double',
        'remaining' => 'double',
        'start_time' => 'int',
        'end_time' => 'int',
        'create_time' => 'int',
        'withdraw_fix_money'=>'double',

    ];

    public function getWheres($param)
    {
        $where = [];
        $agent_id = $param['agent_id'] ?? '';
        $username = $param['username'] ?? '';
        $withdraw_order = $param['withdraw_order'] ?? '';

        if ($agent_id) {
            $where['agent_id'] = $agent_id;
        }

        if ($username) {
            $where['username'] = $username;
            if (is_array($username)) {
                $where['username'] = ['$in' => $username];
            }
        }

        if ($withdraw_order) {
            $where['withdraw_order'] = $withdraw_order;
            if (is_array($withdraw_order)) {
                $where['withdraw_order'] = ['$in' => $withdraw_order];
            }
        }

        $where = $this->getTypeData($where);
        return $where;
    }

    public function findOrders($param,$field,$sort=[]){

        $where = $this -> getWheres($param);
        if(empty($where)){
            return [];
        }

        $list = $this -> findAllData($where,$field,$sort);

        return $list;
    }
}