<?php

namespace app\model;

use app\library\facade\service\Game;
use app\library\MongoQuery;
use app\library\facade\model\{Player as PlayerModel, Pkg as PkgModel, Active as ActiveModel};
use MongoDB\Driver\Exception\BulkWriteException;
use think\Exception;
use think\facade\Log;
use think\Model;

class PayIncomeDb extends Model
{
    protected $table = "tb_user_pay_income_record";
    protected $connection = "mongo_payincome_log_app";
    protected $database = 'mongo_payincome_log_app';
    use MongoQuery;

    protected $dataType = [
        'idx'            => 'int',
        'username'            => 'string',
        'order_no'            => 'string',
        'game_category_id'    => 'int',
        'game_second_cate_id' => 'int',
        'record_id'           => 'string',
        'start_game_time'     => 'int',
        'finish_game_time'    => 'int',
        'finish_game_hour'    => 'int',
        'finish_game_day'     => 'int',
        'finish_game_month'   => 'int',
        'game_type'           => 'int',
        'room_id'             => 'int',
        'seat_id'             => 'int',
        'room_type'           => 'int',
        'room_level'          => 'int',
        'room_rate'           => 'double',
        'room_flag'           => 'int',
        'player_flag'         => 'int',
        'service_id'          => 'int',
        'opt_type'            => 'int',
        'all_bet'             => 'double',
        'valid_bet'           => 'double',
        'return_prize'        => 'double',
        'taxation'            => 'double',
        'item_type'           => 'int',
        'item_count'          => 'double',
        'cur_count'           => 'double',
        'opt_log'           => 'string',
        'remark'              => 'string',
        'deal_type'           => 'int',
        'pkg_type'            => 'int',
        'agent_mode'          => 'int',
        'pusername'           => 'string',
        'parent_platform_id'  => 'string',
        'prize_id'            => 'int',
        'paicai_order_no'     => 'string',
        'active_id'           => 'int',
        'income'           => 'double',
        'mgr_info'           => 'double',
        'fund_details'           => 'string',
        'level_name'           => 'string',
        'game_name'           => 'string',
        'game_pkg_id'           => 'int',
        'game_id'           => 'int',
        'pkg_id'           => 'int',
        'platform_id'           => 'string',
        'operation_id'           => 'int',
        'platform_type'           => 'int',
        'agent_id'           => 'int',

        //'order_status'        => 'int',  所有数据只能新增，所以冲销的化 只能opt_type 新增值
    ];

    //订单状态
    const ORDER_STATUS_SETTLE = 1; //已经结算
    const ORDER_STATUS_UNSETTLE = 2; //未结算
    const ORDER_STATUS_CANCEL = 3; //已经注销


    //交易类型
    const   GOLD_TYPE_PLATFORM_FUND_SWITCH = 1, //额度转换
        GOLD_TYPE_RECHARGE = 2,  //存款类
        GOLD_TYPE_WITHDRAWALS = 3, //出款类
        GOLD_TYPE_DEPOSIT_MANUAL = 4,   //人工存入
        GOLD_TYPE_ACTIVITY = 5, //活动优惠
        GOLD_TYPE_WITHDRAWAL_MANUAL = 6, //人工取款
        GOLD_TYPE_RETURNGOLD = 7,  //洗码-返水
        GOLD_TYPE_COMMISSION = 8,  //领取佣金-返佣
        GOLD_TYPE_BALANCE = 9, //余额宝记录
        GOLD_TYPE_TASK = 10; //任务

    //游戏结算：1
    const OPT_TYPE_GAME_SETTLE = 1;//游戏结算//const OPT_TYPE_RETURNGOLD_REALTIME=603;//实时返水;  self::OPT_TYPE_PAICAI=>'派彩',//会员游戏输赢
    const OPT_TYPE_GAME_FISH = 4;//捕鱼游戏结算
    //彩金
    const OPT_TYPE_CAIJIN = 9;//

    //存款类：110-295
    //---start-add----
    const OPT_TYPE_DEPOSIT_ENTERPRISE_BANK = 110;//公司入款(银行卡转帐)
    const OPT_TYPE_DEPOSIT_ENTERPRISE_WX = 111;//公司入款（微信转账）
    const OPT_TYPE_DEPOSIT_ENTERPRISE_ALI = 112;//公司入款（支付宝转账）
    const OPT_TYPE_DEPOSIT_SPAY = 113;//专享闪付()
    const OPT_TYPE_DEPOSIT_SEAT_WX = 114;//坐席充值（(微信坐席)）
    const OPT_TYPE_DEPOSIT_SEAT_QQ = 115;//坐席充值（QQ坐席）
    const OPT_TYPE_DEPOSIT_SEAT_ALI = 116;//坐席充值（支付宝坐席）
    //----end---
    const OPT_TYPE_DEPOSIT_MCH1_WX = 117;//通过商户的wx充值渠道,demo
    const OPT_TYPE_DEPOSIT_MCH1_ALI = 118;//通过商户的支付宝充值渠道,demo
    const OPT_TYPE_DEPOSIT_MCH1_BANK = 119;//通过商户的网银充值渠道,demo
    const OPT_TYPE_DEPOSIT_MCH1_QQ_BAG = 120;//通过商户的QQ充值渠道,demo
    const OPT_TYPE_DEPOSIT_MCH1_BAIDU_BAG = 121;//通过商户的百度支付充值渠道,demo
    const OPT_TYPE_DEPOSIT_MCH1_JD_PAY = 122;//通过商户的京东支付充值渠道,demo
    const OPT_TYPE_DEPOSIT_MCH1_UNION_SCAN = 123;//通过商户的银联支付充值渠道,demo
    const OPT_TYPE_DEPOSIT_MCH1_QQ_SCAN = 124;//通过商户的qq扫码支付充值渠道,demo
    const OPT_TYPE_DEPOSIT_MCH1_DK_SCAN = 125;//通过商户的点卡充值支付充值渠道,demo 10
    const OPT_TYPE_DEPOSIT_MCH1_OTHER_SCAN = 126;//通过商户的其他充值支付充值渠道,demo

    //余额宝类:296-300
    const OPT_TYPE_YEB_IN = 296;//余额宝转入
    const OPT_TYPE_YEB_OUT = 297;//余额宝转出到余额
    const OPT_TYPE_YEB_PROFIT = 298;//余额宝利息

    //出款类：301-350。(玩家生成订单，后台审核，该部分金额暂时冻结),所有取款都要稽核
    const OPT_TYPE_WITHDRAW_MANUAL = 301;//人工出款-申请（冻结操作）
    const OPT_TYPE_WITHDRAW_MANUAL_SUCCESS = 303;//人工出款-申请成功
    const OPT_TYPE_WITHDRAW_MANUAL_REFUSE = 304;//人工出款-拒绝
    const OPT_TYPE_WITHDRAW_DPAY_MCH1 = 302;//代付1出款,demo
    const OPT_TYPE_WITHDRAW_MANUAL_FAIL = 305;//出款失败，减少冻结金额，增加用户余额
    const OPT_TYPE_WITHDRAW_CANNEL = 308;//代付订单取消

    //人工存入：360-380:1.手动存款即专享闪付和坐席充值总称
    const OPT_TYPE_HANDIN_BALANCE = 360;//手动增加余额。考虑的是第四方支付回调失败，做补发
    const OPT_TYPE_HANDIN_YOUHUI = 361;//手动发放优惠，对满足自定义活动的玩家发放优惠，和优惠活动中的金币变动分开
    const OPT_TYPE_HANDIN_COMMISSION = 362;//手动发放佣金
    const OPT_TYPE_HANDIN_RETURNGOLD = 363;//手动发放返水
    const OPT_TYPE_HANDIN_ENTERPRISE = 364;//公司入款的手动存入，在公司入款异常情况，在后台给用户补单
    const OPT_TYPE_HANDIN_BATCH_BALANCE = 365;//批量手动增加余额,直接修改余额
    const OPT_TYPE_HANDIN_BATCH_YOUHUI = 366;//批量手动发放优惠
    const OPT_TYPE_HANDIN_BATCH_COMMISSION = 367;//批量手动发放佣金
    const OPT_TYPE_FORCE_INCOME = 368;//线上支付订单强制入款

    //人工提出(人工取款):381-399
    const OPT_TYPE_HANDOUT_BALANCE = 381;//手动减少余额，异常增加余额情况需要手动减少余额
    const OPT_TYPE_HANDOUT_WITHDRAW = 382;//手动取款，后台生成订单，直接审核通过，提款金额冻结
    const OPT_TYPE_HANDOUT_BATCH_BALANCE = 383;//批量手动减少余额，直接修改余额


    //额度转换:400-500
    const OPT_TYPE_PLATFORM_APP2AG = 400;//app转入AG
    const OPT_TYPE_PLATFORM_AG2APP = 401;//AG转入APP
    //优惠活动:501-600
    const OPT_TYPE_ACTIVITY_SIGN = 501;//活动-签到领取
    const OPT_TYPE_ACTIVITY_BIND = 502;//活动-绑定领取
    const OPT_TYPE_ACTIVITY_LUCK_SILVER = 503;//活动-幸运夺宝-白银-奖励领取
    const OPT_TYPE_ACTIVITY_LUCK_GOLD = 504;//活动-幸运夺宝-黄金-奖励领取
    const OPT_TYPE_ACTIVITY_LUCK_DIAMOND = 505;//活动-幸运夺宝-钻石-奖励领取
    const OPT_TYPE_ACTIVITY_ROBRED = 506;//活动-抢红包-奖励领取
    const OPT_TYPE_ACTIVITY_STAGE = 507;//活动-闯关-奖励领取
    const OPT_TYPE_ACTIVITY_RESCUE = 508;//活动-救援金-领取
    const OPT_TYPE_ACTIVITY_CHARGERETURN = 509;//活动-充值返现-奖励领取
    const OPT_TYPE_ACTIVITY_CANCEL = 510;//活动-冲销
    const OPT_TYPE_ACTIVITY_CUSTOM = 511;//活动-自定义活动
    const OPT_TYPE_ACTIVITY_ONLINE_DEPOSIT = 512;//活动-线上充值优惠
    const OPT_TYPE_ACTIVITY_OFFLINE_DEPOSIT = 513;//活动-线下充值优惠
    const OPT_TYPE_ACTIVITY_REGISTER = 514;//活动-注册活动
    const OPT_TYPE_ACTIVITY_LOGIN = 515;//活动-登录活动
    //返水:601-610
    const OPT_TYPE_RETURNGOLD_SYS = 601;//系统派发
    const OPT_TYPE_RETURNGOLD_HAND = 602;//人工派发
    const OPT_TYPE_RETURNGOLD_CANCEL = 604;//返水冲销
    const OPT_TYPE_RETURNGOLD_RECV = 605;//返水领取（即手动洗码）
    //代理佣金:611-620
    const OPT_TYPE_PROMOTE_COMMISSION_EMIT = 611;//发放佣金
    const OPT_TYPE_PROMOTE_COMMISSION_RECV = 612;//领取佣金
    const OPT_TYPE_PROMOTE_COMMISSION_CANCEL = 613;//退佣金
    //VIP晋级，周奖金，月奖金:621-630
    const OPT_TYPE_VIP = 621;//晋级奖发放
    const OPT_TYPE_VIP_WEEK = 622;//周奖发放
    const OPT_TYPE_VIP_MONTH = 623;//月奖发放
    const OPT_TYPE_VIP_RECV = 624;//晋级奖领取
    const OPT_TYPE_VIP_WEEK_RECV = 625;//周奖领取
    const OPT_TYPE_VIP_MONTH_RECV = 626;//月奖领取

    //冲销 690-700
    const OPT_TYPE_HANDIN_BATCH_CANCEL = 690;//批量冲销，直接修改余额

    //任务:100000-199999  c++ 要求的 opt = 100000 + game_type
    const OPT_TYPE_TASK_HALL = 1000;//大厅任务 ptType 要小于1999

    const OPT_TYPE_TASK_HD = 100012;//棋牌任务 炸金花
    const OPT_TYPE_TASK_LANDLORDS = 100013;//棋牌任务 斗地主
    const OPT_TYPE_TASK_HUNDRED_COW = 100017;//棋牌任务 百人牛牛
    const OPT_TYPE_TASK_BACCARAT = 100018;//棋牌任务 百家乐
    const OPT_TYPE_TASK_DRAGON_TIGER = 100019;//棋牌任务 龙虎斗
    const OPT_TYPE_TASK_RED_BLACK = 100020;//棋牌任务 红黑大战
    const OPT_TYPE_TASK_COW = 100026;//棋牌任务 通比牛牛

    const OPT_TYPE_TASK_CHILD_GAME = 100021;//捕鱼任务

    const OPT_TYPE_TASK_BMW = 100022;//街机任务 奔驰宝马
    const OPT_TYPE_TASK_ANIMAL = 100023;//街机任务 飞禽走兽
    const OPT_TYPE_TASK_FRUITS = 100024;//街机任务 超级水果机
    const OPT_TYPE_TASK_SHUIHUZHUAN = 100025;//街机任务 水浒传
    //还没出来的游戏
    const OPT_TYPE_TASK_MAHJONG = 100648;//棋牌任务 二人麻将
    const OPT_TYPE_TASK_2D_POKER_PRO = 100649;//棋牌任务 2D德州扑克
    const OPT_TASK_TYPE_TASK_3D_POKER_PRO = 100650;//棋牌任务 3D德州扑克


    /**
     * 数据库中实际存储的类型 不传则返回所有，传key则返回指定元素
     * @return array|string
     */
    public function getOptType($key = null)
    {
        $list = [
            self::OPT_TYPE_GAME_SETTLE               => '游戏结算',
            self::OPT_TYPE_GAME_FISH                 => '捕鱼游戏结算',
            //存款类：110-295
            self::OPT_TYPE_DEPOSIT_ENTERPRISE_BANK   => '公司入款-银行卡转帐',
            self::OPT_TYPE_DEPOSIT_ENTERPRISE_WX     => '公司入款-微信转账',
            self::OPT_TYPE_DEPOSIT_ENTERPRISE_ALI    => '公司入款-支付宝转账',
            self::OPT_TYPE_DEPOSIT_SPAY              => '专享闪付',
            self::OPT_TYPE_DEPOSIT_SEAT_WX           => '坐席充值-微信坐席',
            self::OPT_TYPE_DEPOSIT_SEAT_QQ           => '坐席充值-QQ坐席',
            self::OPT_TYPE_DEPOSIT_SEAT_ALI          => '坐席充值-支付宝坐席',
            self::OPT_TYPE_DEPOSIT_MCH1_WX           => '通过商户的wx充值渠道',
            self::OPT_TYPE_DEPOSIT_MCH1_ALI          => '通过商户的支付宝充值渠道',
            self::OPT_TYPE_DEPOSIT_MCH1_BANK         => '通过商户的网银充值渠道',
            self::OPT_TYPE_DEPOSIT_MCH1_QQ_BAG       => '通过商户的QQ充值渠道,demo',
            self::OPT_TYPE_DEPOSIT_MCH1_BAIDU_BAG    => '通过商户的百度支付充值渠道',
            self::OPT_TYPE_DEPOSIT_MCH1_JD_PAY       => '通过商户的京东支付',
            self::OPT_TYPE_DEPOSIT_MCH1_UNION_SCAN   => '通过商户的银联支付充值渠道',
            self::OPT_TYPE_DEPOSIT_MCH1_QQ_SCAN      => '',//通过商户的qq扫码支付充值渠道,demo
            //余额宝类:296-300
            self::OPT_TYPE_YEB_IN                    => '余额宝转入',
            self::OPT_TYPE_YEB_OUT                   => '余额宝转出',
            self::OPT_TYPE_YEB_PROFIT                => '余额宝收益',
            //出款类：301-350。(玩家生成订单，后台审核，该部分金额暂时冻结),所有取款都要稽核
            self::OPT_TYPE_WITHDRAW_MANUAL           => '人工出款-申请',
            self::OPT_TYPE_WITHDRAW_MANUAL_SUCCESS   => '人工出款-成功',//人工出款-申请成功
            self::OPT_TYPE_WITHDRAW_MANUAL_REFUSE    => '人工出款-拒绝',//人工出款-拒绝
            self::OPT_TYPE_WITHDRAW_DPAY_MCH1        => '代付1出款',
            self::OPT_TYPE_WITHDRAW_MANUAL_FAIL      => '人工出款-失败',//出款失败，减少冻结金额，增加用户余额
            self::OPT_TYPE_WITHDRAW_CANNEL           => '代付订单-取消',
            //self::OPT_TYPE_WITHDRAW_CANNEL           => '代付订单取消/拒绝',

            //人工存入：360-380:1.手动存款即专享闪付和坐席充值总称
            self::OPT_TYPE_HANDIN_BALANCE            => '手动增加余额',
            self::OPT_TYPE_HANDIN_YOUHUI             => '手动发放优惠',
            self::OPT_TYPE_HANDIN_COMMISSION         => '手动发放佣金',
            self::OPT_TYPE_HANDIN_RETURNGOLD         => '手动发放返水',
            self::OPT_TYPE_HANDIN_ENTERPRISE         => '手动存入-公司入款',
            self::OPT_TYPE_HANDIN_BATCH_BALANCE      => '批量手动增加余额',
            self::OPT_TYPE_HANDIN_BATCH_YOUHUI       => '批量手动发放优惠',
            self::OPT_TYPE_HANDIN_BATCH_COMMISSION   => '批量手动发放佣金',
            self::OPT_TYPE_FORCE_INCOME              => '',//线上支付订单强制入款
            //人工提出(人工取款):381-399
            self::OPT_TYPE_HANDOUT_BALANCE           => '手动减少余额',
            self::OPT_TYPE_HANDOUT_WITHDRAW          => '手动取款',
            self::OPT_TYPE_HANDOUT_BATCH_BALANCE     => '批量手动减少余额',
            //额度转换:400-500
            self::OPT_TYPE_PLATFORM_APP2AG           => 'app转入AG',
            self::OPT_TYPE_PLATFORM_AG2APP           => 'AG转入APP',
            //优惠活动:501-600
            self::OPT_TYPE_ACTIVITY_SIGN             => '活动-签到',
            self::OPT_TYPE_ACTIVITY_BIND             => '活动-绑定',
            self::OPT_TYPE_ACTIVITY_LUCK_SILVER      => '活动-幸运夺宝-白银转盘',
            self::OPT_TYPE_ACTIVITY_LUCK_GOLD        => '活动-幸运夺宝-黄金转盘',
            self::OPT_TYPE_ACTIVITY_LUCK_DIAMOND     => '活动-幸运夺宝-钻石转盘',
            self::OPT_TYPE_ACTIVITY_ROBRED           => '活动-抢红包',
            self::OPT_TYPE_ACTIVITY_STAGE            => '活动-闯关',
            self::OPT_TYPE_ACTIVITY_RESCUE           => '活动-救援金',
            self::OPT_TYPE_ACTIVITY_CHARGERETURN     => '活动-充值返现',
            self::OPT_TYPE_ACTIVITY_CANCEL           => '活动-冲销',
            self::OPT_TYPE_ACTIVITY_CUSTOM           => '活动-自定义活动',
            self::OPT_TYPE_ACTIVITY_ONLINE_DEPOSIT   => '活动-线上充值优惠',
            self::OPT_TYPE_ACTIVITY_OFFLINE_DEPOSIT  => '活动-线下充值优惠',
            self::OPT_TYPE_ACTIVITY_REGISTER         => '活动-注册活动',
            self::OPT_TYPE_ACTIVITY_LOGIN            => '活动-登录活动',
            //返水:601-610
            self::OPT_TYPE_RETURNGOLD_SYS            => '返水-系统派发',
            self::OPT_TYPE_RETURNGOLD_HAND           => '返水-人工派发',
            self::OPT_TYPE_RETURNGOLD_CANCEL         => '返水-冲销',
            self::OPT_TYPE_RETURNGOLD_RECV           => '返水-领取',
            //代理佣金:611-620
            self::OPT_TYPE_PROMOTE_COMMISSION_EMIT   => '代理推广-佣金发放',
            self::OPT_TYPE_PROMOTE_COMMISSION_RECV   => '代理推广-佣金领取',
            self::OPT_TYPE_PROMOTE_COMMISSION_CANCEL => '代理推广-佣金冲销',
            //VIP晋级，周奖金，月奖金:621-630
            self::OPT_TYPE_VIP                       => 'VIP-晋级奖发放',
            self::OPT_TYPE_VIP_WEEK                  => 'VIP-周奖发放',
            self::OPT_TYPE_VIP_MONTH                 => 'VIP-月奖发放',
            self::OPT_TYPE_VIP_RECV                  => 'VIP-晋级奖领取',
            self::OPT_TYPE_VIP_WEEK_RECV             => 'VIP-周奖领取',
            self::OPT_TYPE_VIP_MONTH_RECV            => 'VIP-月奖领取',
            //任务:
            self::OPT_TYPE_TASK_HALL              => '大厅任务-充值任务金额',

            self::OPT_TYPE_TASK_HD                => '棋牌任务-炸金花',
            self::OPT_TYPE_TASK_LANDLORDS         => '棋牌任务-斗地主',
            self::OPT_TYPE_TASK_RED_BLACK         => '棋牌任务-红黑大战',
            self::OPT_TYPE_TASK_COW               => '棋牌任务-通比牛牛',
            self::OPT_TYPE_TASK_BACCARAT          => '棋牌任务-百家乐',
            self::OPT_TYPE_TASK_DRAGON_TIGER      => '棋牌任务-龙虎斗',
            self::OPT_TYPE_TASK_HUNDRED_COW       => '棋牌任务-百人牛牛',
            self::OPT_TYPE_TASK_MAHJONG           => '棋牌任务-二人麻将',
            self::OPT_TYPE_TASK_2D_POKER_PRO      => '棋牌任务-2D德州扑克',
            self::OPT_TASK_TYPE_TASK_3D_POKER_PRO => '棋牌任务-3D德州扑克',

            self::OPT_TYPE_TASK_SHUIHUZHUAN    => '街机任务-水浒传',
            self::OPT_TYPE_TASK_BMW            => '街机任务-奔驰宝马',
            self::OPT_TYPE_TASK_FRUITS         => '街机任务-超级水果机',
            self::OPT_TYPE_TASK_ANIMAL         => '街机任务-飞禽走兽',
            self::OPT_TYPE_TASK_CHILD_GAME     => '街机任务-其他子游戏',
            //彩金
            self::OPT_TYPE_CAIJIN              => '彩金',
            //冲销 690-700
            self::OPT_TYPE_HANDIN_BATCH_CANCEL => '批量冲销，直接修改余额',
        ];
        return $key ? $list[$key] ?? '' : $list;
    }

    public function isVipChangeOptType($opt_type)
    {
        //360-380
        if (360 <= $opt_type && $opt_type <= 380) {
            return true;
        }
        if ($opt_type == self::OPT_TYPE_GAME_SETTLE) {
            return true;
        }
        return false;
    }

    /**
     *
     * @return array|mixed|string
     */
    public function getDealType($key = null)
    {
        $list = $this->getDealList();
        $data = array_column($list, 'name', 'deal_type');
        return ($key !== null) ? ($data[$key] ?? '') : $data;
    }

    public function getDealList()
    {
        $list = [
            [
                'deal_type' => self::GOLD_TYPE_PLATFORM_FUND_SWITCH,
                'name'      => '额度转换',
            ],
            [
                'deal_type' => self::GOLD_TYPE_RECHARGE,
                'name'      => '存款类',
            ],
            [
                'deal_type' => self::GOLD_TYPE_WITHDRAWALS,
                'name'      => '出款类',
            ],
            [
                'deal_type' => self::GOLD_TYPE_DEPOSIT_MANUAL,
                'name'      => '人工存入',
            ],
            [
                'deal_type' => self::GOLD_TYPE_ACTIVITY,
                'name'      => '优惠活动',
            ],
            [
                'deal_type' => self::GOLD_TYPE_WITHDRAWAL_MANUAL,
                'name'      => '人工提出',
            ],
            [
                'deal_type' => self::GOLD_TYPE_RETURNGOLD,
                'name'      => '返水',
            ],
            [
                'deal_type' => self::GOLD_TYPE_COMMISSION,
                'name'      => '返佣',
            ],
            [
                'deal_type' => self::GOLD_TYPE_BALANCE,
                'name'      => '余额宝',
            ],
            [
                'deal_type' => self::GOLD_TYPE_TASK,
                'name'      => '任务',
            ],
        ];
        return $list;
    }

    /**
     * 交易类型分类和实际存储数据类型关系---传入key则返回对应的opt_type 不传递则返回所有的opt_type
     * @return array|string
     */
    public function getDealOpt($key = null)
    {
        $list = [
            //"额度转换",//未对接第三方游戏平台
            self::GOLD_TYPE_PLATFORM_FUND_SWITCH => [
                self::OPT_TYPE_PLATFORM_APP2AG,//app转入AG
                self::OPT_TYPE_PLATFORM_AG2APP,//AG转入APP
                self::OPT_TYPE_GAME_SETTLE,
                self::OPT_TYPE_GAME_FISH,
            ],
            //"存款类",暂时还未对接线上充值
            self::GOLD_TYPE_RECHARGE             => [
                self::OPT_TYPE_DEPOSIT_MCH1_WX,//通过商户的wx充值渠道,demo
                self::OPT_TYPE_DEPOSIT_MCH1_ALI,//通过商户的支付宝充值渠道,demo
                self::OPT_TYPE_DEPOSIT_MCH1_BANK,//通过商户的网银充值渠道,demo
                self::OPT_TYPE_DEPOSIT_MCH1_QQ_BAG,//通过商户的QQ充值渠道,demo
                self::OPT_TYPE_DEPOSIT_MCH1_BAIDU_BAG,//通过商户的百度支付充值渠道,demo
                self::OPT_TYPE_DEPOSIT_MCH1_JD_PAY,//通过商户的京东支付充值渠道,demo
                self::OPT_TYPE_DEPOSIT_MCH1_UNION_SCAN,//通过商户的银联支付充值渠道,demo
            ],
            //"出款类",未对接代付
            self::GOLD_TYPE_WITHDRAWALS          => [
                self::OPT_TYPE_WITHDRAW_MANUAL,//人工出款-出款的申请（冻结金额）
                self::OPT_TYPE_WITHDRAW_MANUAL_SUCCESS,//人工出款-出款成功
                self::OPT_TYPE_WITHDRAW_MANUAL_REFUSE,//人工出款-拒绝
//                self::OPT_TYPE_WITHDRAW_DPAY_MCH1,//代付1出款,demo
                self::OPT_TYPE_WITHDRAW_CANNEL,//代付订单取消/拒绝
            ],
            //"人工存入",
            self::GOLD_TYPE_DEPOSIT_MANUAL       => [
                self::OPT_TYPE_HANDIN_BALANCE,//手动增加余额。考虑的是第四方支付回调失败，做补发
                self::OPT_TYPE_HANDIN_YOUHUI,//手动发放优惠，对满足自定义活动的玩家发放优惠，和优惠活动中的金币变动分开
                self::OPT_TYPE_HANDIN_COMMISSION,//手动发放佣金
                self::OPT_TYPE_HANDIN_RETURNGOLD,//手动发放返水
                self::OPT_TYPE_HANDIN_ENTERPRISE,//公司入款的手动存入，在公司入款异常情况，在后台给用户补单
                self::OPT_TYPE_HANDIN_BATCH_BALANCE,//批量手动增加余额,直接修改余额
                self::OPT_TYPE_HANDIN_BATCH_YOUHUI,//批量手动发放优惠
                self::OPT_TYPE_HANDIN_BATCH_COMMISSION,//批量手动发放佣金
                self::OPT_TYPE_DEPOSIT_ENTERPRISE_BANK, //公司入款(银行卡转帐)
                self::OPT_TYPE_DEPOSIT_ENTERPRISE_WX,//公司入款（微信转账）
                self::OPT_TYPE_DEPOSIT_ENTERPRISE_ALI, //公司入款（支付宝转账）
                self::OPT_TYPE_DEPOSIT_SPAY,//专享闪付
                self::OPT_TYPE_DEPOSIT_SEAT_WX,//坐席充值（(微信坐席)）微信代理充值
                self::OPT_TYPE_DEPOSIT_SEAT_QQ,//坐席充值（QQ坐席）    QQ代理充值
                self::OPT_TYPE_DEPOSIT_SEAT_ALI,//坐席充值（支付宝坐席）支付宝代理充值
            ],
            //"活动优惠",
            self::GOLD_TYPE_ACTIVITY             => [
                self::OPT_TYPE_ACTIVITY_SIGN,//活动-签到领取
                self::OPT_TYPE_ACTIVITY_BIND,//活动-绑定领取
                self::OPT_TYPE_ACTIVITY_LUCK_SILVER,//活动-幸运夺宝-白银-奖励领取
                self::OPT_TYPE_ACTIVITY_LUCK_GOLD,//活动-幸运夺宝-黄金-奖励领取
                self::OPT_TYPE_ACTIVITY_LUCK_DIAMOND,//活动-幸运夺宝-钻石-奖励领取
                self::OPT_TYPE_ACTIVITY_ROBRED,//活动-抢红包-奖励领取
                self::OPT_TYPE_ACTIVITY_STAGE,//活动-闯关-奖励领取
                self::OPT_TYPE_ACTIVITY_RESCUE,//活动-救援金-领取
                self::OPT_TYPE_ACTIVITY_CHARGERETURN,//活动-充值返现-奖励领取
                self::OPT_TYPE_ACTIVITY_CANCEL,//活动-冲销
                self::OPT_TYPE_ACTIVITY_CUSTOM,//活动-自定义活动
                self::OPT_TYPE_ACTIVITY_ONLINE_DEPOSIT,//活动-线上充值优惠
                self::OPT_TYPE_ACTIVITY_OFFLINE_DEPOSIT,//活动-线下充值优惠
                self::OPT_TYPE_ACTIVITY_REGISTER,//活动-注册活动
                self::OPT_TYPE_ACTIVITY_LOGIN,//活动-登录活动
                self::OPT_TYPE_VIP,   // VIP-晋级奖发放
                self::OPT_TYPE_VIP_WEEK, //VIP-周奖发放
                self::OPT_TYPE_VIP_MONTH, //VIP-月奖发放
                self::OPT_TYPE_VIP_RECV,  //VIP-晋级奖领取
                self::OPT_TYPE_VIP_WEEK_RECV, //VIP-周奖领取
                self::OPT_TYPE_VIP_MONTH_RECV, //VIP-月奖领取
            ],
            //"人工取款",
            self::GOLD_TYPE_WITHDRAWAL_MANUAL    => [
                self::OPT_TYPE_HANDOUT_BALANCE,//手动减少余额，异常增加余额情况需要手动减少余额
                self::OPT_TYPE_HANDOUT_WITHDRAW,//手动取款，后台生成订单，直接审核通过，提款金额冻结
                self::OPT_TYPE_HANDOUT_BATCH_BALANCE,//批量手动减少余额，直接修改余额
            ],
            //"洗码",=返水
            self::GOLD_TYPE_RETURNGOLD           => [
                self::OPT_TYPE_RETURNGOLD_SYS,//系统派发
                self::OPT_TYPE_RETURNGOLD_HAND,//人工派发
                self::OPT_TYPE_RETURNGOLD_CANCEL,//返水冲销
                self::OPT_TYPE_RETURNGOLD_RECV,//返水领取（即手动洗码）
            ],
            //"佣金",
            self::GOLD_TYPE_COMMISSION           => [
                self::OPT_TYPE_PROMOTE_COMMISSION_EMIT,//自动发放佣金
                self::OPT_TYPE_PROMOTE_COMMISSION_RECV,//领取佣金
                self::OPT_TYPE_PROMOTE_COMMISSION_CANCEL,//退佣金
            ],
            //"余额宝记录",
            self::GOLD_TYPE_BALANCE              => [
                self::OPT_TYPE_YEB_IN,//余额宝转入
                self::OPT_TYPE_YEB_OUT,//余额宝转出到余额
                // self::OPT_TYPE_YEB_PROFIT,//余额宝利息
            ],
            //"任务",
            self::GOLD_TYPE_TASK                 => [
                self::OPT_TYPE_TASK_HALL,//大厅任务 充值任务金额
                self::OPT_TYPE_TASK_HD,//棋牌任务 炸金花
                self::OPT_TYPE_TASK_LANDLORDS,//棋牌任务 斗地主
                self::OPT_TYPE_TASK_RED_BLACK,//棋牌任务 红黑大战
                self::OPT_TYPE_TASK_COW,//棋牌任务 通比牛牛
                self::OPT_TYPE_TASK_BACCARAT,//棋牌任务 百家乐
                self::OPT_TYPE_TASK_DRAGON_TIGER,//棋牌任务 龙虎斗
                self::OPT_TYPE_TASK_HUNDRED_COW,//棋牌任务 百人牛牛
                self::OPT_TYPE_TASK_MAHJONG,//棋牌任务 二人麻将
                self::OPT_TYPE_TASK_2D_POKER_PRO,//棋牌任务 2D德州扑克
                self::OPT_TASK_TYPE_TASK_3D_POKER_PRO,//棋牌任务 3D德州扑克
                self::OPT_TYPE_TASK_SHUIHUZHUAN,//街机任务 水浒传
                self::OPT_TYPE_TASK_BMW,//街机任务 奔驰宝马
                self::OPT_TYPE_TASK_FRUITS,//街机任务 超级水果机
                self::OPT_TYPE_TASK_ANIMAL,//街机任务 飞禽走兽
                self::OPT_TYPE_TASK_CHILD_GAME,//街机任务 其他子游戏
            ],
        ];
        return ($key != null) ? ($list[$key] ?? '') : $list;
    }

    /**
     * 通过交易细类查找交易大类
     * @param  null  $key
     * @return array|int|mixed
     */
    public function getDealTypeByOptType($key)
    {
        $lists = $this->getDealOpt();
        $data = [];
        foreach ($lists as $dealType => $list) {
            foreach ($list as $value) {
                $data[$value] = $dealType;
            }
        }
        return $data[$key] ?? 0;
    }

    /**
     * @desc 是否为充值的日志
     * @param $optType
     * @return bool
     */
    public function isDepositOptType($optType)
    {
        //110-295
        if (110 <= $optType && $optType <= 295) {
            return true;
        }
        return false;
    }

    /**
     * @desc 判断是否属于需要稽核的入款和优惠（包含活动优惠和返水）,
     * @param  null  $optType
     * @return bool
     */
    public function isExaminatingOptType($optType = null)
    {
        $list = [
            //存款 缺少线上充值定义
            self::OPT_TYPE_DEPOSIT_ENTERPRISE_BANK,//公司入款(银行卡转帐)
            self::OPT_TYPE_DEPOSIT_ENTERPRISE_WX,//公司入款（微信转账）
            self::OPT_TYPE_DEPOSIT_ENTERPRISE_ALI,//公司入款（支付宝转账）
            self::OPT_TYPE_DEPOSIT_SPAY,//专享闪付
            self::OPT_TYPE_DEPOSIT_SEAT_WX,//坐席充值（(微信坐席)）
            self::OPT_TYPE_DEPOSIT_SEAT_QQ,//坐席充值（QQ坐席）
            self::OPT_TYPE_DEPOSIT_SEAT_ALI,//坐席充值（支付宝坐席）
            self::OPT_TYPE_DEPOSIT_MCH1_WX,//通过商户的wx充值渠道,demo
            self::OPT_TYPE_DEPOSIT_MCH1_ALI,//通过商户的支付宝充值渠道,demo
            self::OPT_TYPE_DEPOSIT_MCH1_BANK,//通过商户的网银充值渠道,demo
            self::OPT_TYPE_DEPOSIT_MCH1_QQ_BAG,//通过商户的QQ充值渠道,demo
            self::OPT_TYPE_DEPOSIT_MCH1_BAIDU_BAG,//通过商户的百度支付充值渠道,demo
            self::OPT_TYPE_DEPOSIT_MCH1_JD_PAY,//通过商户的百度支付充值渠道,demo
            self::OPT_TYPE_DEPOSIT_MCH1_UNION_SCAN,//通过商户的银联支付充值渠道,demo
            self::OPT_TYPE_HANDIN_BALANCE,
            // 手动存入
            self::OPT_TYPE_HANDIN_COMMISSION,
            self::OPT_TYPE_HANDIN_ENTERPRISE,
            self::OPT_TYPE_HANDIN_BATCH_BALANCE,
            self::OPT_TYPE_HANDIN_BATCH_YOUHUI,
            self::OPT_TYPE_HANDIN_BATCH_COMMISSION,
            self::OPT_TYPE_FORCE_INCOME,

            //优惠活动
            self::OPT_TYPE_HANDIN_YOUHUI,//手动发放优惠，对满足自定义活动的玩家发放优惠，和优惠活动中的金币变动分开
            self::OPT_TYPE_ACTIVITY_SIGN,//活动-签到领取
            self::OPT_TYPE_ACTIVITY_BIND,//活动-绑定领取
            self::OPT_TYPE_ACTIVITY_LUCK_SILVER,//活动-幸运夺宝-白银-奖励领取
            self::OPT_TYPE_ACTIVITY_LUCK_GOLD,//活动-幸运夺宝-黄金-奖励领取
            self::OPT_TYPE_ACTIVITY_LUCK_DIAMOND,//活动-幸运夺宝-钻石-奖励领取
            self::OPT_TYPE_ACTIVITY_ROBRED,//活动-抢红包-奖励领取
            self::OPT_TYPE_ACTIVITY_STAGE,//活动-闯关-奖励领取
            self::OPT_TYPE_ACTIVITY_RESCUE,//活动-救援金-领取
            self::OPT_TYPE_ACTIVITY_CHARGERETURN,//活动-充值返现-奖励领取
            self::OPT_TYPE_ACTIVITY_CUSTOM,//活动-自定义活动
            self::OPT_TYPE_ACTIVITY_REGISTER,//活动-注册活动
            self::OPT_TYPE_ACTIVITY_LOGIN,//活动-登录活动
            //返水活动
            self::OPT_TYPE_HANDIN_RETURNGOLD,//手动发放返水
            self::OPT_TYPE_RETURNGOLD_SYS,//系统派发
            self::OPT_TYPE_RETURNGOLD_HAND,//人工派发
            self::OPT_TYPE_RETURNGOLD_RECV,//返水领取（即手动洗码）
        ];
        if (in_array($optType, $list)) {
            return true;
        }
        return false;
    }

    /**
     * @desc 判断是否属于需要稽核的出款
     * @param  null  $optType
     * @return bool
     */
    public function isWithdrawOrderOptType($optType = null)
    {
        $list = [
            self::OPT_TYPE_HANDOUT_WITHDRAW,
            self::OPT_TYPE_WITHDRAW_MANUAL,
            self::OPT_TYPE_WITHDRAW_DPAY_MCH1,
        ];
        if (in_array($optType, $list)) {
            return true;
        }
        return false;
    }

    public function insertLog($data)
    {
        if (!isset($data['record_id']) || !isset($data['platform_type']) || !isset($data['finish_game_time'])) {
            Log::error("代理或游戏时间字段未找到");
            return false;
        }
        try {
            $r = \app\library\facade\model\PayIncomeDbUsernameShard::insertLog($data);
            return $this->insertData($data);
//            return $this->updateData($where,$data,['upsert'=>true]);
        } catch (BulkWriteException $e) {
            Log::error($e->getMessage());
            return true;
        } catch (\Error $error) {
            Log::error($error->getMessage());
            return true;
        }
    }

    /**
     * 帐户交易列表
     * @param $agentId
     * @param $params
     * @param $size
     * @return array
     */
    public function getList($agentId, $params, $size)
    {
        $where = [
            'agent_id'  => $agentId,
            'deal_type' => ['$gt' => 0],
            'opt_type' => ['$ne' => PayIncomeDb::OPT_TYPE_YEB_PROFIT],
        ];
        if (!empty($params['username'])) {
            $where['username'] = $params['username'];
        }
        if (!empty($params['deal_type'])) {
            $where['deal_type'] = (int) $params['deal_type'];
        }
        if (!empty($params['record_id'])) {
            unset($where);
            $where['record_id'] = $params['record_id'];
        }
        //最近30天
        $endTime = time();
        $startTime = strtotime('-30 day', strtotime(date('Y-m-d')));
        $where['finish_game_time'] = [
            '$gte' => $startTime,
            '$lte' => $endTime,
        ];

        $list = [
            'username'         => '',
            'record_id'        => '',
            'deal_type'        => 0,
            'finish_game_time' => '',
            'item_count'       => 0,
            'cur_count'        => 0,
            'front_remark'     => '',
            'back_remark'      => '',
            'operator'         => '',
            'opt_type' => 0,
        ];
        $field = implode(',', array_keys($list));
        $payIncome = $this->paginate($where, $field, [], ['finish_game_time' => -1], $size);
        $data = [];
        $dealType = $this->getDealType();
        foreach ($payIncome['data'] as $income) {
            $income = array_merge($list, $income);
            $income['finish_game_time'] = (!empty($income['finish_game_time'])) ?
                date('Y-m-d H:i:s', $income['finish_game_time']) : '';
            $income['deal_type'] = $dealType[$income['deal_type']] ?? '';
            $data[] = $income;
        }
        $payIncome['data'] = $data;
        return $payIncome;
    }

    /**
     * 某一时间段的投注人数
     * @param $agentId
     * @param $startTime
     * @param $endTime
     * @param $unit  1：小时，2：天，3：月
     * @return array
     */
    public function betStatistics($agentId, $startTime, $endTime, $unit)
    {
        $match = [
            'agent_id'         => $agentId,
            'opt_type'         => [
                '$in' =>$this->getBettingOptType(),
            ],
            'finish_game_time' => ['$gte' => $startTime, '$lte' => $endTime],
        ];

        //按小时
        if ($unit == 1) {
            $_id = '$finish_game_hour';
//            $hours = [];
//            for($i=$startTime;$i<=$endTime;$i+=3600)
//            {
//                $hours[]=(int)date('YmdH', $i);
//            }
//            !empty($hours) && $match['finish_game_hour'] = ['$in'=>array_unique($hours)];
            //按天
        } elseif ($unit == 2) {
            $_id = '$finish_game_day';
//            $days = [];
//            for($i=$startTime;$i<=$endTime;$i+=86400)
//            {
//                $days[]=(int)date('Ymd', $i);
//            }
//            !empty($days) && $match['finish_game_day'] = ['$in'=>array_unique($days)];
            //按月
        } else {
            $_id = '$finish_game_month';
//            $months = [];
//            for($i=$startTime;$i<=$endTime;$i+=3600*24*28)
//            {
//                $months[]=(int)date('Ym', $i);
//            }
//            !empty($months) && $match['finish_game_month'] = ['$in'=>array_unique($months)];
        }
        $group = [
            '_id'      => $_id,
            'username' => ['$addToSet' => '$username'],
        ];
        $project = [
            'count' => ['$size' => '$username'],
            '_id'   => 1,
        ];
        $pipeline = [
            ['$match' => $match],
            ['$group' => $group],
            ['$project' => $project],
        ];
        $data = $this->aggregate($pipeline);
        return $data;
    }

    //损益

    /**
     * 用户某一段时间的损益、总投注和有效投注
     * @param $username
     * @param  string  $startTime
     * @param  string  $endTime
     * @return mixed
     */
    public function profit($username, $startTime = '', $endTime = '')
    {
        $where = [
            'username' => $username,
            'opt_type' => [
                '$in' => $this->getBettingOptType(),
            ],
        ];
        if ($startTime && $endTime) {
            $where['finish_game_time'] = [
                '$gte' => $startTime,
                '$lte' => $endTime,
            ];
        }
        $group = [
            '_id'        => null,
            'item_count' => ['$sum' => '$item_count'],
            'all_bet'    => ['$sum' => '$all_bet'],
            'valid_bet'  => ['$sum' => '$valid_bet'],
        ];
        $pipeline = [
            ['$match' => $where],
            ['$group' => $group],
        ];
        $itemCount = $this->aggregate($pipeline);
        $profit = current($itemCount);
        return $profit;
    }

    /**
     * 用户某段时间某交易大类的金额统计
     * @param $username
     * @param $dealType
     * @param $startTime
     * @param $endTime
     * @return int
     */
    public function payIncome($username, $dealType, $startTime, $endTime)
    {
        $where = [
            'username'  => $username,
            'deal_type' => $dealType,
        ];
        if ($startTime && $endTime) {
            $where['finish_game_time'] = [
                '$gte' => $startTime,
                '$lte' => $endTime,
            ];
        }
        $group = [
            '_id'   => null,
            'count' => ['$sum' => '$item_count'],
        ];
        $pipeline = [
            ['$match' => $where],
            ['$group' => $group],
        ];
        $payIncome = $this->aggregate($pipeline);
        $payIncome = current($payIncome);
        return $payIncome['count'] ?? 0;
    }


    /**
     * 返回用户在最近$limit 或者最近事件段局数内的总有效投注和盈利
     * @param $username
     * @param $limit
     * @return array
     */
    public function getThresholdByUsername(int $agent_id, String $username,  $limit = 0,  $time = 0)
    {
        $sort = ['finsish_game_time' => -1];//倒序 1是顺序
        $where = [
            'username' => (string) $username,
            'agent_id' => $agent_id,
            'opt_type' => ['$in' => $this->getBettingOptType()],
        ];
        if (!empty($time)) {
            $where['finish_game_time'] = ['$gte' => time() - $time];
        }
        $group = ['username' => '$username'];
        $count = false;
        if ($limit) {
            $count = $limit;
        }
        $fields = [
            'item_count', //盈利
            'valid_bet', //有效投注
            'count_item_count',//游戏输赢记录
        ];
        $list = $this->getStatInfo($where, $group, $fields, $sort, $count);
        $win_sum = 0;
        $continue_win_num = 0;
        foreach ($list['data'] as $k => $value) {
            $count_item_count = (array) $value['count_item_count'] ?? [];
            foreach ($count_item_count as $v) {
                if ($v > 0) {
                    $win_sum = $win_sum + 1;
                    $continue_win_num = $continue_win_num + 1; //连胜
                } else {
                    $continue_win_num = 0;//连胜重置
                }

            }
        }
        $data = [
            'item_count'       => $list[0]['item_count'] ?? 0,//损益
            'valid_bet'        => $list[0]['valid_bet'] ?? 0,//有效投注
            'win_sum'          => $win_sum, //胜利次数
            'continue_win_num' => $continue_win_num, //连胜次数
        ];
        return $data;
    }

    /**
     * @desc 统计所有$usernames的的业绩
     * @param $usernames
     * @param $start_time
     * @param $end_time
     * @return mixed
     */
    public function getValidBet(
        $usernames,
        $start_time,
        $end_time,
        $game_category_id = null,
        $game_second_cate_id = null
    ) {
        $usernames = is_array($usernames) ? $usernames : [$usernames];
        $where = [
            'username' => ['$in' => $usernames],
            'finish_game_time' => ['$gte' => $start_time, '$lt' => $end_time,],
            'opt_type'=>['$in' =>$this->getBettingOptType()]
        ];
        if ($game_category_id) {
            $where['game_category_id'] = $game_category_id;
        }
        if ($game_second_cate_id) {
            $where['game_second_cate_id'] = $game_second_cate_id;
        }
        $sum = $this->aggregate([
            ['$match' => $where],
            ['$group' => ['_id' => null, 'sum' => ['$sum' => '$valid_bet']]],
        ]);
        return $sum[0]['sum'] ?? 0;
    }


    /**
     * 按照什么分组获取的活动优惠金额，带查询条件 --返回  $data[$value]=active_count $value==$groupBy出来的值
     */
    public function getActiveDiscount($where = [], $group = [])
    {
        $where['opt_type'] = ['$in'=>$this->getDealOpt(self::GOLD_TYPE_ACTIVITY)];//活动优惠
        $fields = ['item_count'];
        $list = $this->getStatInfo($where, $group, $fields);
        $total = $this->getTotalStat($where, $group, $fields);
        $list = array_merge($total, $list);
        return $list;
    }

    /**
     * 结算状态列表
     */
    public function settleStatusList($key = false)
    {
        $list = [
            self::ORDER_STATUS_SETTLE   => '已结算',
            self::ORDER_STATUS_UNSETTLE => '未结算',
            //self::ORDER_STATUS_CANCEL=>'已注销',
        ];
        return ($key !== false) ? $list[$key] ?? '' : $list;
    }

    public function getWhereParam($param)
    {
        $agent_id = $param['agent_id'] ?? 0; //当前代理ID
        $pusername = $param['pusername'] ?? 0; //当前代理账户username
        $game_second_cate_id = $param['game_second_cate_id'] ?? 0;//游戏平台id
        $game_category_id = $param['game_category_id'] ?? 0;//游戏分类id
        $game_type = $param['game_type'] ?? 0; //游戏id
        $opt_type = $param['opt_type'] ?? 0; //操作类型
        $prize_id = $param['prize_id'] ?? 0; //彩金奖项id
        if ($opt_type) {
            if (!is_array($opt_type)) {
                $opt_type = explode(",", $opt_type); //操作类型
            }
        }
        $deal_type = $param['deal_type'] ?? 0; //交易类型
        if ($deal_type) {
            if (!is_array($deal_type)) {
                $deal_type = explode(",", $deal_type); //交易类型
            }
        }
        $finish_game_day = $param['finish_game_day'] ?? ''; //交易时间
        $active_id = $param['active_id'] ?? 0; //返水活动id或者优惠活动id
        if ($active_id) {
            if (!is_array($active_id)) {
                $active_id = explode(",", $active_id); //操作类型
            }
        }
        $username = $param['username'] ?? 0; //会员id
        $platform_id = $param['platform_id'] ?? '';//会员账户
        $agent_mode = $param['agent_mode'] ?? 0; //当前代理模式id
        $order_no = $param['order_no'] ?? ''; //订单号
        $record_id = $param['record_id'] ?? ''; //订单号

        $game_category = $param['game_category'] ?? ''; //游戏平台
        if ($game_category) {
            $game_category = json_decode(base64_decode($game_category), true);
        }

        //交易时间区间
        $start_finish_game_time = $param['start_finish_game_time'] ?? 0;//开始
        $end_finish_game_time = $param['end_finish_game_time'] ?? 0;//结束

        //投注金额区间
        $start_all_bet = $param['start_all_bet'] ?? 0;//开始
        $end_all_bet = $param['end_all_bet'] ?? 0;//结束

        //有效投注区间
        $start_valid_bet = $param['start_valid_bet'] ?? '';//开始
        $end_valid_bet = $param['end_valid_bet'] ?? '';//结束

        //损益区间
        $start_item_count = $param['start_item_count'] ?? '';//开始
        $end_item_count = $param['end_item_count'] ?? '';//结束

        //余额宝收益区间/彩金奖池余额区间/交易类型交易后的余额区间
        $start_cur_count = $param['start_cur_count'] ?? 0;//开始
        $end_cur_count = $param['end_cur_count'] ?? 0;//结束

        //余额宝收益区间
        $start_income = $param['start_income'] ?? 0;//开始
        $end_income = $param['end_income'] ?? 0;//结束

        //交易时间区间段--
        $start_finish_game_day = $param['start_finish_game_day'] ?? 0;//开始
        $end_finish_game_day = $param['end_finish_game_day'] ?? 0;//结束

        $where = [];
        if ($agent_id) {
            $where['agent_id'] = $agent_id;
        }
        if ($pusername) {
            if (!is_array($pusername)) {
                $pusername = [$pusername];
            }
            $where['pusername'] = ['$in' => $pusername];
        }
        if ($agent_mode) {
            $where['agent_mode'] = $agent_mode;
        }
        if ($order_no) {
            $where['order_no'] = $order_no;
        }
        if ($record_id) {
            $where['record_id'] = $record_id;
        }
        if ($game_second_cate_id) {
            $where['game_second_cate_id'] = $game_second_cate_id;
        }
        if ($game_category_id) {
            $where['game_category_id'] = $game_category_id;
        }
        if ($game_category) {
            $gameCategory = [];
            foreach ($game_category as $k => $v) {
                $gameSecondCateId = explode("_", $k)[1];
                $gameCateId = $v;
                foreach ($gameCateId as &$value) {
                    $value = (int) $value;
                }
                $tmp = ['game_second_cate_id' => (int) $gameSecondCateId]; //平台id
                if (!empty($gameCateId)) {
                    $tmp['game_category_id'] = ['$in' => $gameCateId];//类型id
                }
                $gameCategory[] = $tmp;
                $where['$or'] = $gameCategory;
            }
        }
        if ($game_type) {
            $where['game_type'] = $game_type;
        }
        if ($opt_type) {
            foreach ($opt_type as &$v) {
                $v = (int) $v;
            }
            $where['opt_type'] = ['$in' => $opt_type];
        }
        if ($deal_type) {
            foreach ($deal_type as &$v) {
                $v = (int) $v;
                $v == 9 && $where['opt_type'] =
                    ['$ne'=>self::OPT_TYPE_YEB_PROFIT];
            }
            $where['deal_type'] = ['$in' => $deal_type];
        }
        if ($finish_game_day) {
            $where['finish_game_day'] = date("Ymd", strtotime($finish_game_day));
        }
        if ($active_id) {
            $where['active_id'] = $active_id;
            if (is_array($active_id)) {
                $where['active_id'] = ['$in' => $active_id];
            }
        }
        if ($username) {
            $where['username'] = $username;
            if (is_array($username)) {
                $where['username'] = ['$in' => $username];
            }

        }
        if ($platform_id) {
            $where['platform_id'] = $platform_id;
        }
        if ($start_finish_game_time) {
            $where['finish_game_time'] = [
                '$gte' => strtotime($start_finish_game_time),
            ];
        }
        if ($end_finish_game_time) {
            $tmp = [
                '$lte' => strtotime($end_finish_game_time),
            ];
            if (isset($where['finish_game_time'])) {
                $where['finish_game_time'] = array_merge($where['finish_game_time'], $tmp);
            } else {
                $where['finish_game_time'] = $tmp;
            }
        }

        if ($start_all_bet) {
            $where['all_bet'] = [
                '$gte' => (double) $start_all_bet,
            ];
        }
        if ($end_all_bet) {
            $tmp = [
                '$lte' => (double) $end_all_bet,
            ];
            if (isset($where['all_bet'])) {
                $where['all_bet'] = array_merge($where['all_bet'], $tmp);
            } else {
                $where['all_bet'] = $tmp;
            }
        }

        if ($start_income) {
            $where['income'] = [
                '$gte' => (double) $start_income,
            ];
        }
        if ($end_income) {
            $tmp = [
                '$lte' => (double) $end_income,
            ];
            if (isset($where['income'])) {
                $where['income'] = array_merge($where['income'], $tmp);
            } else {
                $where['income'] = $tmp;
            }
        }

        if (is_numeric($start_valid_bet)) {
            $where['valid_bet'] = [
                '$gte' => (double) $start_valid_bet,
            ];
        }
        if (is_numeric($end_valid_bet)) {
            $tmp = [
                '$lte' => (double) $end_valid_bet,
            ];
            if (isset($where['valid_bet'])) {
                $where['valid_bet'] = array_merge($where['valid_bet'], $tmp);
            } else {
                $where['valid_bet'] = $tmp;
            }
        }

        if (is_numeric($start_item_count)) {
            $where['item_count'] = [
                '$gte' => (double) $start_item_count,
            ];
        }
        if (is_numeric($end_item_count)) {
            $tmp = [
                '$lte' => (double) $end_item_count,
            ];
            if (isset($where['item_count'])) {
                $where['item_count'] = array_merge($where['item_count'], $tmp);
            } else {
                $where['item_count'] = $tmp;
            }
        }

        if ($start_cur_count) {
            $where['cur_count'] = [
                '$gte' => (double) $start_cur_count,
            ];
        }
        if ($end_cur_count) {
            $tmp = [
                '$lte' => (double) $end_cur_count,
            ];
            if (isset($where['cur_count'])) {
                $where['cur_count'] = array_merge($where['cur_count'], $tmp);
            } else {
                $where['cur_count'] = $tmp;
            }
        }

        if ($start_finish_game_day) {
            $where['finish_game_day'] = [
                '$gte' => (int) date("Ymd", strtotime($start_finish_game_day)),
            ];
        }
        if ($end_finish_game_day) {
            $tmp = [
                '$lte' => (int) date("Ymd", strtotime($end_finish_game_day)),
            ];
            if (isset($where['finish_game_day'])) {
                $where['finish_game_day'] = array_merge($where['finish_game_day'], $tmp);
            } else {
                $where['finish_game_day'] = $tmp;
            }
        }
        if($prize_id && $game_type){ // 彩金报表 高级搜索 彩金奖项(必须要有游戏类型)
            $res = Game::getGamePrize($game_type,$prize_id);
            $where['prize_name'] = $res['name']??"";
        }

        $where = $this->getTypeData($where);
        return $where;
    }


    /**
     * 返水记录冲销或发放
     */
    public function rebateUpdateStatus($agent_id = 0, $order_no = 0, $order_status = null)
    {
        $where = [];
        if ($agent_id) {
            $where['agent_id'] = $agent_id;
        }
        if ($order_no) {
            $where['order_no'] = $order_no;
        }
        $data = [
            'order_status' => $order_status,
        ];
        $bool = $this->updateAllData($where, $data);
        return $bool;
    }

    /**
     * statinfo 的group
     * @param $groups
     * @param $fields
     * @return mixed
     */
    private function getGroup($group, $fields)
    {
        $groups = ['_id' => $group];
        if (in_array("nums", $fields)) {
            $groups['nums'] = ['$sum' => 1];    //注单量--投注订单数量
        }
        if (in_array("all_bet", $fields)) {
            $groups['all_bet'] = ['$sum' => '$all_bet'];//总投注
        }
        if (in_array("valid_bet", $fields)) {
            $groups['valid_bet'] = ['$sum' => '$valid_bet']; //有效投注-累计投注
        }
        if (in_array("item_count", $fields)) {
            $groups['item_count'] = ['$sum' => '$item_count'];//累计盈利
        }
        if (in_array("cur_count", $fields)) {
            $groups['cur_count'] = ['$sum' => '$cur_count'];//累计转出
        }
        if (in_array("income", $fields)) {
            $groups['income'] = ['$sum' => '$income'];//累计转出收益
        }
        if (in_array("taxation", $fields)) {
            $groups['taxation'] = ['$sum' => '$taxation'];//抽水
        }
        if (in_array("persons", $fields)) {
            $groups['persons'] = ['$addToSet' => '$username']; //总会员人数-去重复
        }
        if (in_array("count_username", $fields)) {
            $groups['count_username'] = ['$addToSet' => '$username']; //总会员人数-去重复
        }
        if (in_array("order_status_cancel", $fields)) { //投注明细中注销订单量
            $groups['order_status_cancel'] = [
                '$sum' => [
                    '$cond' => [
                        'if'   => [
                            '$eq' => ['$opt_type', 0], //订单被注销
                        ],
                        'then' => 1,
                        'else' => 0,
                    ],
                ],
            ];
        }
        if (in_array("sum_total_deposit", $fields)) { //不包含人工的存款--日运营报表-定时任务
            $groups['sum_total_deposit'] = [
                '$sum' => [
                    '$cond' => [
                        'if'   => [
                            '$eq' => ['$deal_type', self::GOLD_TYPE_RECHARGE],
                        ],
                        'then' => ['$subtract' => ['$item_count', '$deduce_amount']],
                        'else' => 0,
                    ],
                ],
            ];
        }
        if (in_array("sum_total_withdraw", $fields)) { //不包含人工的取款--日运营报表-定时任务
            $groups['sum_total_withdraw'] = [
                '$sum' => [
                    '$cond' => [
                        'if'   => [
                            '$eq' => ['$deal_type', self::GOLD_TYPE_WITHDRAWALS],
                        ],
                        'then' => '$item_count',
                        'else' => 0,
                    ],
                ],
            ];
        }
        if (in_array("total_deposit_persons", $fields)) { //不包含人工的存款人数--日运营报表-定时任务
            $groups['total_deposit_persons'] = [
                '$addToSet' => [
                    '$cond' => [
                        'if'   => [
                            '$eq' => ['$deal_type', self::GOLD_TYPE_RECHARGE],
                        ],
                        'then' => '$username',
                        'else' => 0,
                    ],
                ],
            ];
        }
        if (in_array("total_withdraw_persons", $fields)) { //不包含人工的取款人数--日运营报表-定时任务
            $groups['total_withdraw_persons'] = [
                '$addToSet' => [
                    '$cond' => [
                        'if'   => [
                            '$eq' => ['$deal_type', self::GOLD_TYPE_WITHDRAWALS],
                        ],
                        'then' => '$username',
                        'else' => 0,
                    ],
                ],
            ];
        }
        if (in_array("win_num", $fields)) {  //风控定时任务--胜利次数
            $groups['win_record'] = [
                '$sum' => [
                    '$cond' => [
                        'if'   => [
                            '$gt' => ['$item_count', 0],
                        ],
                        'then' => 1,
                        'else' => 0,
                    ],
                ],
            ]; //胜利次数
        }
        if (in_array("count_item_count", $fields)) { //风控定时任务--游戏输赢记录---计算连续胜利次数
            $groups['count_item_count'] = [
                '$push' => '$item_count',
            ];
        }
        if (in_array("platform_id", $fields)) { //总报表显示昵称 --账户名称
            $groups['platform_id'] = [
                '$first' => '$platform_id',
            ];
        }
        if (in_array("pkg_id", $fields)) { //总报表显示pkg_id
            $groups['pkg_id'] = [
                '$first' => '$pkg_id',
            ];
        }

        if (in_array("order_no", $fields)) { //投注分析报表--需要显示
            $groups['order_no'] = [
                '$first' => '$order_no',
            ];
        }
        if (in_array("username", $fields)) { //分析报表定时任务--需要显示
            $groups['username'] = [
                '$first' => '$username',
            ];
        }
        return $groups;
    }


    /**
     * 活动优惠类型参数
     * @param $param
     * @return array
     */
    public function getUsernameActiveParam($param)
    {
        $agent_id = $param['agent_id'] ?? 0; //当前代理ID
        $active_type = $param['active_type'] ?? 0; //优惠方式

        //优惠存入区间
        $start_active_time = $param['start_active_time'] ?? '';//开始
        $end_active_time = $param['end_active_time'] ?? '';//结束

        //优惠金额区间
        $start_active_count = $param['start_active_count'] ?? 0;;//开始
        $end_active_count = $param['end_active_count'] ?? 0;//结束

        $where = [
            'deal_type' => self::GOLD_TYPE_ACTIVITY,  //优惠活动类型
        ];
        if ($agent_id) {
            $where['agent_id'] = $agent_id;
        }
        if ($active_type) {
            $where['opt_type'] = $active_type;
        }
        if ($end_active_time) {
            $where['finish_game_time'] = [
                '$gte' => $start_active_time,
                '$lte' => $end_active_time,
            ];
        }

        if ($end_active_count) {
            $where['item_count'] = [
                '$gte' => $start_active_count,
                '$lte' => $end_active_count,
            ];
        }
        $where = $this->getTypeData($where);
        $result = $this->findAllData($where, 'username');
        $username = array_column($result, 'username');
        return $username;
    }

    /**
     * 获取交易记录分页
     * @param  array  $param
     * @param  array  $fields
     * @param  array  $sort
     * @param  int  $size
     * @return array
     */
    public function transactionPaginate(
        array $param = [],
        string $fields = "*",
        int $size = 20,
        array $sort = ['finish_game_time' => -1]
    ): array {
        $where = $this->getReportWhereParam($param);
        if (empty($where['deal_type'])) { //交易类型--没有指定交易类型
            $where['deal_type'] = ['$in' => array_column($this->getDealList(), 'deal_type')];
        }
        $list = $this->paginate($where, $fields, [], $sort, $size);
        $total = $this->getTotalStat($where, null, ['item_count']);
        $list = array_merge($list, $total);
        return $list;
    }

    private function getReportWhereParam(array $param): array
    {
        $where = $this->getWhereParam($param);
        $wherePlayer = $wherePlayer2 = PlayerModel::getWhereParam($param);
        unset($wherePlayer['agent_id']);//排除代理id
        unset($wherePlayer['username']);//排除username
        unset($wherePlayer['pkg_id']);//排除pkg_id
        unset($wherePlayer['pkg_name']);//排除pkg_name
        unset($wherePlayer['pkg_en_name']);//排除pkg_en_name
        unset($wherePlayer['pkg_type']);//排除pkg_type
        unset($wherePlayer['platform_id']);//排除platform_id
        if (count($wherePlayer) > 1) {
            $listPlayer = PlayerModel::findAllData($wherePlayer2, 'username');
            $username = array_column($listPlayer, 'username');
            if (!empty($username)) {
                if (!empty($where['username']['$in'])) {
                    $username = array_merge($where['username']['$in'], $username);
                } else {
                    if (!empty($where['username'])) {
                        $username[] = $where['username'];
                    }
                }
            }
            $where['username'] = ['$in' => $username];
        }
        if (!empty($param['pkg_name']) || !empty($param['pkg_en_name']) || !empty($param['pkg_type'])) { //注册来源查询
            $listPkg = PkgModel::getPkgIdByname($param);
            $where['pkg_id'] = ['$in' => array_column($listPkg, 'pkg_id')];
        }
        return $where;
    }

    /**
     * 获取投注明细分页
     * @param  array  $param
     * @param  array  $fields
     * @param  array  $sort
     * @param  int  $size
     * @return array
     */
    public function bettingPaginate(
        array $param = [],
        string $fields = "*",
        int $size = 20,
        array $sort = ['finish_game_time' => -1]
    ): array {
        $where = $this->getReportWhereParam($param);
        $opt_type = $param['opt_type']??0;
        $opt_type <= 1 && $where['opt_type'] = ['$in' =>
            $this->getBettingOptType()];
        //游戏结算-投注明细
        $list = $this->paginate($where, $fields, [], $sort, $size);
        $total = $this->getTotalStat($where, null, ['item_count', 'valid_bet', 'all_bet']);
        $list = array_merge($list, $total);
        return $list;
    }


    /**
     * 获取彩金报表分页
     * @param  array  $param
     * @param  array  $fields
     * @param  array  $sort
     * @param  int  $size
     * @return array
     */
    public function prizPaginate(
        array $param = [],
        string $fields = "*",
        int $size = 20,
        array $sort = ['finish_game_time' => -1]
    ): array {
        $where = $this->getReportWhereParam($param);
        $where['opt_type'] = self::OPT_TYPE_CAIJIN;//彩金
        $list = $this->paginate($where, $fields, [], $sort, $size);
        $total = $this->getTotalStat($where, null, ['item_count']);
        $list = array_merge($list, $total);
        return $list;
    }

    /**
     * 获取活动优惠报表分页
     * @param  array  $param
     * @param  array  $fields
     * @param  array  $sort
     * @param  int  $size
     * @return array
     */
    public function activePaginate(
        array $param = [],
        string $fields = "*",
        int $size = 20,
        array $sort = ['finish_game_time' => -1]
    ): array {
        $where = $this->getReportWhereParam($param);
        $where['deal_type'] = self::GOLD_TYPE_ACTIVITY;//活动优惠
        if (!empty($param['active_type_id']) || !empty($param['active_name'])) {  //查找活动id
            $active_name = $param['active_name'] ?? '';
            $category = $param['active_type_id'] ?? 0;
            $whereActive = [
                'agent_id' => $param['agent_id'],
            ];
            if (!empty($active_name)) {
                $whereActive['name'] = $active_name;
            }
            if (!empty($category)) {
                $whereActive['category'] = $category;
            }
            $activeIds = ActiveModel::findAllData($whereActive, 'id');
            $activeIds = array_column($activeIds, 'id');
            //if (!empty($activeIds)) {
            $where['active_id'] = ['$in' => $activeIds];
            //}
        }

        $list = $this->paginate($where, $fields, [], $sort, $size);
        $total = $this->getTotalStat($where, null, ['item_count']);
        $list = array_merge($list, $total);
        return $list;
    }


    /**
     * 获取余额宝明细记录分页
     * @param  array  $param
     * @param  array  $fields
     * @param  array  $sort
     * @param  int  $size
     * @return array
     */
    public function balancePaginate(
        array $param = [],
        string $fields = "*",
        int $size = 20,
        array $sort = ['finish_game_time' => -1]
    ): array {
        $where = $this->getReportWhereParam($param);
        $where['opt_type'] = ['$in' => [self::OPT_TYPE_YEB_OUT,self::OPT_TYPE_YEB_IN]];//余额宝
        $list = $this->paginate($where, $fields, [], $sort, $size);
        $total = $this->getTotalStat($where, null, ['item_count','income']);
        $list = array_merge($list, $total);
        return $list;
    }

    /**
     * 获取某段时间内的投注信息
     * @param $agentId
     * @param $start
     * @param $end
     * @return array
     */
    public function getBetting($agentId, $start, $end)
    {
        $where = [
            'agent_id'         => $agentId,
            'opt_type'         => ['$in' => $this->getBettingOptType()],
            'finish_game_time' => [
                '$gte' => $start,
                '$lte' => $end,
            ],
        ];
        $group = null; //汇总一条记录
        $field = [
            'valid_bet',
            'nums', //单量
            'persons',  //投注人数
            'item_count',
            'taxation',
        ];
        $PayIncomeDb = $this->getStatInfo($where, $group, $field);
        return $PayIncomeDb = $PayIncomeDb['data'][0] ?? [];
    }

    /**
     * 获取不包含人工存入的时间区段存款取款总额和人数
     * @param $agentId
     * @param $start
     * @param $end
     */
    public function getTotal($agentId, $start, $end)
    {
        $where = [
            'agent_id'         => $agentId,
            'deal_type'        => [
                '$in' => [
                    self::GOLD_TYPE_RECHARGE,//不包含人工存入的时间区段存款取款总额
                    self::GOLD_TYPE_WITHDRAWALS,
                ],
            ],
            'finish_game_time' => [
                '$gte' => $start,
                '$lte' => $end,
            ],
        ];
        $group = null; //汇总一条记录
        $field = [
            'sum_total_deposit',
            'sum_total_withdraw',
            'total_deposit_persons',
            'total_withdraw_persons',
        ];
        $PayIncomeDbTotal = $this->getStatInfo($where, $group, $field);
        return $PayIncomeDbTotal = $PayIncomeDbTotal['data'][0] ?? [];
    }

    public function getGameStatInfo(
        array $where = [],
        array $fields = [],
        int $size = 20,
        array $sort = ['finish_game_time' => -1]
    ): array {
        $where['opt_type'] = ['$in' => $this->getBettingOptType()]; //游戏结算-投注明细
        if (empty($where['game_category_id'])) {
            $where['game_category_id'] = ['$gt' => 0];
        }
        if (empty($where['game_second_cate_id'])) {
            $where['game_second_cate_id'] = ['$gt' => 0];
        }
        $group = [
            'game_category_id'    => '$game_category_id',
            'game_second_cate_id' => '$game_second_cate_id',
        ];
        //列表数据组装
        $list = $this->getStatInfo($where, $group, $fields, $sort, $size);
        //总计部分
        $total = $this->getTotalStat($where, $group,
            ['taxation', 'nums', 'item_count', 'valid_bet', 'all_bet', 'persons']);
        $total['total_taxation'] = round($total['total_taxation'], 2);
        $total['total_valid_bet'] = round($total['total_valid_bet'], 2);
        $total['total_item_count'] = round($total['total_item_count'], 2);
        $total['total_all_bet'] = round($total['total_all_bet'], 2);
        $list = array_merge($list, $total);
        $list['total_nums_rate'] = '100%'; //占单比
        return $list;
    }

    /**
     * 获取总报表-代理报表--代理模式下的代理账户 记录分页
     * @param  array  $param
     * @param  array  $fields
     * @param  array  $sort
     * @param  int  $size
     * @return array
     */
    public function reportAgentPaginate(
        array $param = [],
        array $fields = [],
        int $size = 20,
        array $sort = ['finish_game_time' => -1]
    ): array {
        $where = $this->getReportWhereParam($param);
        $where['opt_type'] = ['$in' => $this->getBettingOptType()]; //游戏结算-投注明细
        $where['pusername'] = ['$exists'=>true];
        $group = [
            'pusername' => [
                '$cond' => [
                    'if' => ['$eq' => ['$pusername','']],
                    'then' => '$username',
                    'else' => '$pusername',
                ]
            ], //按照代理账号分组
        ];
        $list = $this->getStatInfo($where, $group, $fields, $sort, $size);
        $total = $this->getTotalStat($where, $group, ['nums', 'item_count', 'all_bet', 'valid_bet', 'taxation']);
        $list = array_merge($list, $total);
        //优惠金额计算
        $activeList = $this->getActiveDiscount($where, $group);
        $list['total_active_count'] = $activeList['total_item_count'] ?? 0; //活动优惠总计
        $activeListData = [];
        foreach ($activeList['data'] as &$v) {
            $activeListData[$v['pusername']] = $v['item_count'];
        }
        $list['activeListData'] = $activeListData;
        $list['total_profit'] = $list['total_item_count'] - $list['total_active_count']; //总计-净利
        return $list;
    }


    /**
     * 获取总报表-代理报表--会员报表-- 某个代理账户下所有会员相关信息 记录分页
     * @param  array  $param
     * @param  array  $fields
     * @param  array  $sort
     * @param  int  $size
     * @return array
     */
    public function reportUserPaginate(
        array $param = [],
        array $fields = [],
        int $size = 20,
        array $sort = ['finish_game_time' => -1]
    ): array {
        $where = $this->getReportWhereParam($param);
        $pusername = $param['pusername']??'';
        $username = $where['username']['$in']??[];
        $usernames = array_merge($username,[$pusername]);
        $where['$and'] = [
            ['$or' =>[['pusername' => $where['pusername']],
                ['username'=>['$in'=>$usernames]]]],
        ];
        unset($where['pusername'],$where['username']);
        $where['opt_type'] = ['$in' => $this->getBettingOptType()]; //游戏结算-投注明细
        $group = [
            'username' => '$username', //按照账号分组
        ];
        $list = $this->getStatInfo($where, $group, $fields, $sort, $size);
        $total = $this->getTotalStat($where, $group, ['nums', 'item_count', 'all_bet', 'valid_bet', 'taxation']);
        $list = array_merge($list, $total);
        //优惠金额计算
        $activeList = $this->getActiveDiscount($where, $group);
        $list['total_active_count'] = $activeList['total_item_count'] ?? 0; //活动优惠总计
        $activeListData = [];
        foreach ($activeList['data'] as &$v) {
            $activeListData[$v['username']] = $v['item_count'];
        }
        $list['activeListData'] = $activeListData;
        $list['total_profit'] = $list['total_item_count'] - $list['total_active_count']; //总计-净利
        return $list;
    }

    public function getGroupData($agentid, $startTime, $endTime, $type)
    {
        $match = [
            'agent_id' => (int) $agentid, 'finish_game_day' => ['$gte' => (int) $startTime, '$lte' => (int) $endTime],
            'opt_type' => ['$in' => $this->getBettingOptType()],
            $type      => ['$exists' => true],
        ];
        $group = [
            '_id'        => ['finish_game_day' => '$finish_game_day', $type => '$'.$type],
            'all_bet'    => ['$sum' => '$all_bet'],
            'valid_bet'  => ['$sum' => '$valid_bet'],
            'item_count' => ['$sum' => '$item_count'],
            'taxation'   => ['$sum' => '$taxation'],
            'counts'     => ['$sum' => 1],
            'persons'    => ['$addToSet' => '$username'],
        ];
        $project = [
            '_id'     => 1, 'all_bet' => 1, 'valid_bet' => 1, 'item_count' => 1, 'taxation' => 1, 'counts' => 1,
            'persons' => ['$size' => '$persons'],
        ];
        $res = $this->aggregate([
            ['$match' => $match], ['$group' => $group], ['$project' => $project],
            ['$sort' => ['_id.finish_game_day' => 1]],
        ]);

        return $res;
    }

    public function getActiveTotal(int $agentid, int $start, int $end)
    {
        $where = [
            'agent_id'         => $agentid,
            'deal_type'        => self::GOLD_TYPE_ACTIVITY,
            'finish_game_time' => [
                '$gte' => $start,
                '$lte' => $end,
            ],
        ];
        $field = [
            'item_count',
            'count_username',
        ];
        $PayIncomeDbTotal = $this->getStatInfo($where, null, $field);
        return $PayIncomeDbTotal['data'][0] ?? [];
    }


    public function getBettingOptType(): array
    {
        return [
            self::OPT_TYPE_GAME_SETTLE,//游戏结算
            self:: OPT_TYPE_GAME_FISH,//捕鱼游戏结算
        ];
    }
}