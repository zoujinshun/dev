<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/24
 * Time: 22:59
 */

namespace app\controller\notify;


use common\Helper;
use common\Code;
use common\Keys;
use think\Controller;
use app\library\facade\service\PayNotify as payNotifyService;
use think\facade\Log;
class Chengyitongpay extends Controller
{
    private $redis;
    private $query_url = "https://gatecx.chengyitpay.com/api/pay/query";

    public function __construct()
    {
        parent::__construct();
        $this -> redis = redis();
    }

    public function index(){
        Log::info('Wheel start');

        $param = $this -> request -> param();
        Log::info($param);
        if(empty($param) || !isset($param['reqdata'])){
            return 'fail';
        }

        $order_key = Keys::getOrderKey($param['ordernumber']);

        $order_info = $this -> redis -> get($order_key);

        if(!$order_info) {

            $order = payNotifyService::getOrder($param['ordernumber']);

            if (empty($order) || $order['order_status'] == 1 || $order['gold_status'] == 1) {
                return 'fail';
            }

            $merch = payNotifyService::findMerch($order['merch_agent_id']);

            if (empty($merch)) {
                return 'fail';
            }

            $order_info = array_merge($order, $merch);
        }else{
            $this -> redis -> expire($order_key,0);
        }

        $reqdata = Helper::pri_decrypt($param['reqdata'],$order_info['private_key']);

        if(!$reqdata){
            return 'fail';
        }

        $sign = $reqdata['sign'];

        $sign_str = "partner={$reqdata['partner']}".
            "&ordernumber={$reqdata['ordernumber']}".
            "&orderstatus={$reqdata['orderstatus']}".
            "&paymoney={$reqdata['paymoney']}";

        Log::info($sign_str);

        $signature = md5($sign_str.$order_info['md5_key']);

        Log::info($signature);

        if($signature !== $sign){

            Log::info('验签失败');

            return 'fail';

        }
        Log::info('验签成功');

        $data['p1_mchtid'] = $order_info['merch_no'];
        $data['p2_signtype'] = 2;
        $data['p3_orderno'] = $order_info['order_no'];
        $data['p4_version'] = 'v2.9';

        ksort($datas);

        $data_str = urldecode(http_build_query($datas));

        $data['sign'] = md5($data_str . $order_info['md5_key']);

        $encrypt_data = Helper::pub_encrypt(json_encode($data),$order_info['public_key']);

        $query_data = ['mchtid'=>$order_info['merch_no'],'reqdata'=>$encrypt_data];

        $res = Helper::post($query_data,$this -> query_url);

        $res = json_decode($res,true);

        if($res['rspCode'] == '1'){
            $query_datas = Helper::pri_decrypt($res['data'],$order_info['private_key']);
            if($query_datas['r1_mchtid'] != $reqdata['partner'] ||
                $query_datas['r3_orderno'] != $reqdata['ordernumber'] ||
                $query_datas['r4_amount'] != $reqdata['paymoney'])
            {
                return 'fail';
            }
        }else{
            Log::info('订单查询信息不符');
            return 'fail';
        }

        if($param['orderstatus'] == 1){

            $amount = $reqdata['paymoney'];
            $out_trade_no = $reqdata['sysnumber'] == '' ? $reqdata['ordernumber'] : $reqdata['sysnumber'];

            $order_data['pay_status'] = 1;
            $order_data['out_trade_no'] = $out_trade_no;
            $order_data['real_amount'] = $amount;
            $order_data['payed_amount'] = $amount + $order_info['deduce_amount'];
            $order_data['notify_time'] = time();

            $res = payNotifyService::changeOrderStatus($order_info['order_no'],$order_data);

            if(!$res){
                Log::info('订单状态修改失败');
                return 'fail';
            }

            Log::info('订单状态修改成功');

            $optType = payNotifyService::getOptType($order_info['payment_id']);

            $extraData = [
                'order_no' => $reqdata['ordernumber'],
                'amount' => $amount,
                'pay_amount' => $amount,
                'normal_bet' => $order_info['valid_bet'],
                'active_amount' => $order_info['deduce_amount'],
                'deduce_amount' => $order_info['deduce_amount'],
                'deduce_bet' => $order_info['deduce_bet'],
                'valid_bet' => $order_info['deduce_bet'] + $order_info['valid_bet'],
                'payment_id' => $order_info['payment_id'],
            ];

            $gold = Helper::postGold($order_info['username'],$amount+$order_info['deduce_amount'],$reqdata['ordernumber'],$out_trade_no,$optType,'',$extraData);

            if($gold['code'] != Code::SUCCESS){
                Log::info('修改余额失败');
                return 'fail';
            }

            $order_data['gold_status'] = 1;
            $order_data['order_status'] = 1;

            $res = payNotifyService::changeOrderStatus($order_info['order_no'],$order_data);

            if(!$res){
                Log::info('订单状态修改失败1');
                return 'fail';
            }

            payNotifyService::changeLimitAmount($order_info,$amount);
            Log::info('成功');
            echo 'ok';

        }else{

            $order_data['pay_status'] = 2;
            $order_data['gold_status'] = 0;
            $order_data['order_status'] = 0;
            $order_data['notify_time'] = time();

            $res = payNotifyService::changeOrderStatus($order_info['order_no'],$order_data);

            if(!$res){
                Log::info('订单状态修改失败');
                return 'fail';
            }else{
                echo 'ok';
            }
        }
    }
}