<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/26
 * Time: 16:34
 */

namespace app\controller\notify;


use common\Helper;
use common\Code;
use think\Controller;
use app\library\facade\service\PayNotify as payNotifyService;
use think\facade\Log;
use common\Keys;

class Jinzuanpay extends Controller
{
    private $redis;
    private $query_url = 'https://api.jzpay.vip/jzpay_exapi/v1/order/queryOrder';

    public function __construct()
    {
        parent::__construct();
        $this -> redis = redis();
    }

    public function index(){

//        $param = $this -> request -> param();
//        Log::info($param);
//        if(empty($param) || !isset($param['sign'])){
//            return 'fail';
//        }

        $param_get = $this -> request -> get();

        $param_post = $this -> request -> post();

        $param = array_column($param_post,$param_get);

        $sign = $param_get['signature'];

        unset($param['signature']);

        $order_key = Keys::getOrderKey($param_post['jOrderId']);

        $order_info = $this -> redis -> get($order_key);

        if(!$order_info) {

            $order = payNotifyService::getOrder($param_post['jOrderId']);
            if(empty($order) || $order['order_status'] == 1 || $order['gold_status'] == 1){
                return 'fail';
            }

            $merch = payNotifyService::findMerch($order['merch_agent_id']);

            if(empty($merch)){
                return 'fail';
            }

            $order_info = array_merge($order,$merch);
        }else{
            $this -> redis -> expire($order_key,0);
        }

        $data = [];
        foreach($param as $key=>$item){
            if($item != ''){
                $data[$key] = $item;
            }
        }

        ksort($data);

        $sign_str = urldecode(http_build_query($data));

        Log::info($sign_str);

        $signature = strtoupper(hash_hmac('sha256',$sign_str,$order_info['md5_key'],false));

        Log::info($signature);

        if($signature !== $sign){
            Log::info('验签失败');
            return 'fail';
        }

        Log::info('验签成功');

        $datas_url['merchantId'] = $param_get['merchantId '];
        $datas_url['timestamp'] = Helper::getTimestamp();
        $datas_url['signatureMethod'] = 'HmacSHA256';
        $datas_url['signatureVersion'] = '1';
        $datas_body['orderId'] = $param_post['jOrderId'];

        $datas = array_merge($datas_url,$datas_body);

        $query_str = urldecode(http_build_query($datas));

        $signature = strtoupper(hash_hmac('sha256',$query_str,$order_info['md5_key'],false));

        $datas_url['signature'] = $signature;

        $query_url = $this -> query_url . "?" .http_build_query($datas_url);

        $query_info = Helper::post($datas_body,$query_url,['content-type:application/x-www-form-urlencoded']);

        if($query_info['code'] != 0 || $query_info['data']['jOrderId'] != $param_post['jOrderId']){
            return 'fail';
        }

        if($param_post['status'] == 2){

            $amount = $param['actualAmount'];

            $order_data['pay_status'] = 1;
            $order_data['out_trade_no'] = '';
            $order_data['real_amount'] = $amount;
            $order_data['payed_amount'] = $amount + $order_info['deduce_amount'];
            $order_data['notify_time'] = time();
            $order_data['notify_month'] = date('Ym');
            $order_data['notify_day'] = date('Ymd');
            $order_data['notify_hour'] = date('YmH');

            $res = payNotifyService::changeOrderStatus($order_info['order_no'],$order_data);

            if(!$res){
                Log::info('订单状态修改失败');
                return 'fail';
            }

            Log::info('订单状态修改成功');

            $optType = payNotifyService::getOptType($order_info['payment_id']);

            $extraData = [
                'order_no' => $param['jOrderId'],
                'amount' => $amount,
                'pay_amount' => $amount,
                'normal_bet' => $order_info['valid_bet'],
                'active_amount' => $order_info['deduce_amount'],
                'deduce_amount' => $order_info['deduce_amount'],
                'deduce_bet' => $order_info['deduce_bet'],
                'valid_bet' => $order_info['deduce_bet'] + $order_info['valid_bet'],
                'payment_id' => $order_info['payment_id'],
            ];

            $gold = Helper::postGold($order_info['username'],$amount+$order_info['deduce_amount'],$param['jOrderId'],$param['jOrderId'],$optType,'',$extraData);

            if($gold['code'] != Code::SUCCESS){
                Log::info('修改余额失败');
                return 'fail';
            }
            $order_data['gold_status'] = 1;
            $order_data['order_status'] = 1;

            $res = payNotifyService::changeOrderStatus($order_info['order_no'],$order_data);

            if(!$res){
                Log::info('订单状态修改失败');
                return 'fail';
            }
            Log::info('成功');

            payNotifyService::changeLimitAmount($order_info,$amount);

            echo json_encode(['code'=>0,'message'=>'ok']);
        }
        return 'fail';
    }
}