<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/20
 * Time: 20:48
 */

namespace app\controller\notify;


use common\Helper;
use common\Code;
use common\Keys;
use think\Controller;
use app\library\facade\service\PayNotify as payNotifyService;
use think\facade\Log;


class Quanshipay extends Controller
{
    private $redis;
    private $query_url = "http://159.138.21.255:8006/payp/interface/pay/selorder.php";

    public function __construct()
    {
        parent::__construct();
        $this -> redis = redis();
    }

    public function index(){

        $param = $this -> request -> param();
        Log::info($param);
        if(empty($param) || !isset($param['sign'])){
            return 'fail';
        }

        $sign = $param['sign'];

        $order_key = Keys::getOrderKey($param['site_orderid']);

        $order_info = $this -> redis -> get($order_key);

        if(!$order_info){
            $order = payNotifyService::getOrder($param['site_orderid']);
            if(empty($order) || $order['order_status'] == 1 || $order['gold_status'] == 1){
                return 'fail';
            }

            $merch = payNotifyService::findMerch($order['merch_agent_id']);

            if(empty($merch)){
                return 'fail';
            }

            $order_info = array_merge($order,$merch);
        }else{
            $this -> redis -> expire($order_key,0);
        }

        $sign_str = "{$param['siteid']}". "|{$param['paytypeid']}". "|{$param['mainmerchpaytypeid']}".
            "|{$param['trade_orderid']}". "|{$param['site_orderid']}". "|{$param['paymoney']}".
            "|{$param['over_datetime']}". "|{$param['status']}|";

        Log::info($sign_str);

        $signature = sha1($sign_str.$order_info['md5_key']);

        Log::info($signature);

        if($signature !== $sign){
            Log::info('验签失败');
            return 'fail';
        }
        Log::info('验签成功');

        $datas['siteid'] = $order_info['merch_no'];
        $datas['trade_orderid'] = $param['trade_orderid'];
        $datas['site_orderid'] = $order_info['order_no'];
        $datas['nowinttime'] = time();

        $sign_str = "{$param['siteid']}". "|{$param['trade_orderid']}". "|{$param['site_orderid']}".
            "|{$param['nowinttime']}|";

        $signature = sha1($sign_str."&key=".$order_info['md5_key']);

        $datas['sha1key'] = $signature;

        $res = Helper::post($datas,$this -> query_url);

        Log::info($res);

        if($res['code'] != '200'){
            Log::info('查询订单失败');
            return 'fail';
        }

        if($res['data']['siteid'] != $param['siteid'] ||
            $res['data']['paymoney'] != $param['paymoney'] ||
            $res['data']['status'] != $param['status']){
            Log::info('查询订单信息不符');
            return 'fail';
        }

        if($param['status'] == "SUCCESS"){

            $amount = $param['paymoney'] / 100;

            $order_data['pay_status'] = 1;
            $order_data['out_trade_no'] = $param['trade_orderid'];
            $order_data['real_amount'] = $amount;
            $order_data['payed_amount'] = $amount + $order_info['deduce_amount'];
            $order_data['notify_time'] = time();
            $order_data['notify_month'] = date('Ym');
            $order_data['notify_day'] = date('Ymd');
            $order_data['notify_hour'] = date('YmH');

            $res = payNotifyService::changeOrderStatus($order_info['order_no'],$order_data);

            if(!$res){
                Log::info('订单状态修改失败');
                return 'fail';
            }

            Log::info('订单状态修改成功');

            $optType = payNotifyService::getOptType($order_info['payment_id']);

            $extraData = [
                'order_no' => $param['site_orderid'],
                'amount' => $amount,
                'pay_amount' => $amount,
                'normal_bet' => $order_info['valid_bet'],
                'active_amount' => $order_info['deduce_amount'],
                'deduce_amount' => $order_info['deduce_amount'],
                'deduce_bet' => $order_info['deduce_bet'],
                'valid_bet' => $order_info['deduce_bet'] + $order_info['valid_bet'],
                'payment_id' => $order_info['payment_id'],
            ];

            $gold = Helper::postGold($order_info['username'],$amount+$order_info['deduce_amount'],$param['site_orderid'],$param['trade_orderid'],$optType,'',$extraData);

            if($gold['code'] != Code::SUCCESS){
                Log::info('修改余额失败');
                return 'fail';
            }

            $order_data['gold_status'] = 1;
            $order_data['order_status'] = 1;

            $res = payNotifyService::changeOrderStatus($order_info['order_no'],$order_data);

            if(!$res){
                Log::info('订单状态修改失败1');
                return 'fail';
            }

            Log::info('成功');
            payNotifyService::changeLimitAmount($order_info,$amount);
            echo 'success';

        }else if($param['status'] == "FAIL"){

            $order_data['pay_status'] = 2;
            $order_data['gold_status'] = 0;
            $order_data['order_status'] = 0;
            $order_data['notify_time'] = time();
            $order_data['notify_month'] = date('Ym');
            $order_data['notify_day'] = date('Ymd');
            $order_data['notify_hour'] = date('YmH');

            $res = payNotifyService::changeOrderStatus($order_info['order_no'],$order_data);

            if(!$res){
                Log::info('订单状态修改失败');
                return 'fail';
            }else{
                echo 'success';
            }
        }else{
            return 'fail';
        }
    }
}