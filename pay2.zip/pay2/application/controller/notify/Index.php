<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/25
 * Time: 11:06
 */

namespace app\controller\payNotify;


use think\Controller;

class Index extends Controller
{
    public function index(){
        return $this ->json([],405,'Request Error');
    }
}