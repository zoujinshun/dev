<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/20
 * Time: 15:55
 */

namespace app\controller\notify;


use common\Helper;
use common\Code;
use common\Keys;
use think\Controller;
use app\library\facade\service\PayNotify as payNotifyService;
use think\facade\Log;

class Wangpay extends Controller
{
    private $redis;
    private $query_url = "http://gate.motel147.com/Services/LwPay/MobilePayResult.aspx";

    public function __construct()
    {
        parent::__construct();
        $this -> redis = redis();
    }

    public function index(){
        Log::info('Wang start');

        $param = $this -> request -> param();
        Log::info($param);
        if(empty($param) || !isset($param['hmac'])){
            return 'fail';
        }

        $sign = $param['hmac'];

        $order_key = Keys::getOrderKey($param['r6_Order']);

        $order_info = $this -> redis -> get($order_key);

        if(!$order_info) {

            $order = payNotifyService::getOrder($param['r6_Order']);

            if (empty($order) || $order['order_status'] == 1 || $order['gold_status'] == 1) {
                return 'fail';
            }

            $merch = payNotifyService::findMerch($order['merch_agent_id']);

            if (empty($merch)) {
                return 'fail';
            }

            $order_info = array_merge($order, $merch);
        }else{
            $this -> redis -> expire($order_key,0);
        }

        $sign_str = '';

        foreach($param as $key => $item){
            if($key != 'hmac'){
                if($item == null){
                    $sign_str .= '';
                }else{
                    $sign_str .= $item;
                }
            }
        }

        Log::info($sign_str);

        $md5_key = iconv("GB2312","UTF-8",$order_info['md5_key']);
        $sign_str = iconv("GB2312","UTF-8",$sign_str);

        $b = 64; // byte length for md5
        if (strlen($md5_key) > $b) {
            $md5_key = pack("H*",md5($md5_key));
        }
        $md5_key = str_pad($md5_key, $b, chr(0x00));
        $ipad = str_pad('', $b, chr(0x36));
        $opad = str_pad('', $b, chr(0x5c));
        $k_ipad = $md5_key ^ $ipad ;
        $k_opad = $md5_key ^ $opad;

        $signature = md5($k_opad . pack("H*",md5($k_ipad . $sign_str)));

        Log::info($signature);

        if($signature !== $sign){

            Log::info('验签失败');

            return 'fail';

        }
        Log::info('验签成功');

        if($param['r1_Code'] == 1){

            $amount = $param['r3_Amt'];

            $order_data['pay_status'] = 1;
            $order_data['out_trade_no'] = $param['r2_TrxId'];
            $order_data['real_amount'] = $amount;
            $order_data['payed_amount'] = $amount + $order_info['deduce_amount'];

            $res = payNotifyService::changeOrderStatus($order_info['order_no'],$order_data);

            if(!$res){
                Log::info('订单状态修改失败');
                return 'fail';
            }

            Log::info('订单状态修改成功');

            $optType = payNotifyService::getOptType($order_info['payment_id']);

            $extraData = [
                'order_no' => $param['r6_Order'],
                'amount' => $amount,
                'pay_amount' => $amount,
                'normal_bet' => $order_info['valid_bet'],
                'active_amount' => $order_info['deduce_amount'],
                'deduce_amount' => $order_info['deduce_amount'],
                'deduce_bet' => $order_info['deduce_bet'],
                'valid_bet' => $order_info['deduce_bet'] + $order_info['valid_bet'],
                'payment_id' => $order_info['payment_id'],
            ];

            $gold = Helper::postGold($order_info['username'],$amount+$order_info['deduce_amount'],$optType,'',$extraData);

            if($gold['code'] != Code::SUCCESS){
                Log::info('修改余额失败');
                return 'fail';
            }

            $order_data['gold_status'] = 1;
            $order_data['order_status'] = 1;

            $res = payNotifyService::changeOrderStatus($order_info['order_no'],$order_data);

            if(!$res){
                Log::info('订单状态修改失败1');
                return 'fail';
            }

            Log::info('成功');
            payNotifyService::changeLimitAmount($order_info,$amount);
            echo 'success';

        }else{

            $order_data['pay_status'] = 2;
            $order_data['gold_status'] = 0;
            $order_data['order_status'] = 0;

            $res = payNotifyService::changeOrderStatus($order_info['order_no'],$order_data);

            if(!$res){
                Log::info('订单状态修改失败');
                return 'fail';
            }else{
                echo 'success';
            }
        }
    }
}