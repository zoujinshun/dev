<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/26
 * Time: 16:34
 */

namespace app\controller\notify;

use think\Controller;
use app\library\facade\service\PayNotify as payNotifyService;
use think\facade\Log;
use common\Keys;

class Applepay extends Controller
{
    private $redis;

    public function __construct()
    {
        parent::__construct();
        $this -> redis = redis();
    }

    public function index(){

        $param = $this -> request -> param();
        Log::info($param);
        if(empty($param) || !isset($param['sign'])){
            return 'fail';
        }

        $sign = $param['sign'];

        $order_key = Keys::getOrderKey($param['aa_orderId']);

        $order_info = $this -> redis -> get($order_key);

        if(!$order_info) {

            $order_info = payNotifyService::getOrder($param['aa_orderId']);
            if(empty($order) || $order['order_status'] == 2 || $order['pay_status'] != 1){
                return 'fail';
            }

            $this -> redis -> set($order_key,$order_info);
        }

        $merch = payNotifyService::findMerch($order['merch_agent_id']);

        if(empty($merch)){
            return 'fail';
        }

        $data = [];
        foreach($param as $key=>$item){
            if($item != '' && $key != 'sign'){
                $data[$key] = $item;
            }
        }

        ksort($data);

        $sign_str = urldecode(http_build_query($data));
        Log::info($sign_str);
        $signature = strtoupper(sha1($sign_str . '&key=' .$merch['md5_key']));
        Log::info($signature);
        if($signature !== $sign){
            Log::info('验签失败');
            return 'fail';
        }

        Log::info('验签成功');

        $order_info['amount'] = (float)($param['aa_amount'] / 100);
        $order_info['out_trade_no'] = $param['aa_tranNo'];

        $res = payNotifyService::changeOrderStatus($order_info);

        if(!$res){
            Log::info('订单状态修改失败');
            return 'fail';
        }

        Log::info('订单状态修改成功');

        Log::info('成功');

        payNotifyService::changeLimitAmount($order_info);

        $order_info['order_status'] = 2;
        $order_info['pay_status'] = 2;

        $this -> redis -> set($order_key,json_encode($order_info));

        echo 'success';
    }
}