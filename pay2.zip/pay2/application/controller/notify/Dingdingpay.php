<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/24
 * Time: 22:59
 */

namespace app\controller\notify;


use common\Helper;
use common\Code;
use common\Keys;
use think\Controller;
use app\library\facade\service\PayNotify as payNotifyService;
use think\facade\Log;

class Dingdingpay extends Controller
{
    private $redis;
    private $query_url = "http://query.ddpay2019.com/query/pay";

    public function __construct()
    {
        parent::__construct();
        $this -> redis = redis();
    }

    public function index()
    {

        $param = $this->request->param();

        Log::info($param);

        if (empty($param) || !isset($param['sign'])) {
            return 'fail';
        }

        $sign = $param['sign'];

        $order_key = Keys::getOrderKey($param['requestNo']);

        $order_info = $this->redis->get($order_key);

        if (!$order_info) {

            $order = payNotifyService::getOrder($param['requestNo']);
            if (empty($order) || $order['order_status'] == 1 || $order['gold_status'] == 1) {
                return 'fail';
            }

            $merch = payNotifyService::findMerch($order['merch_agent_id']);

            if (empty($merch)) {
                return 'fail';
            }

            $order_info = array_merge($order, $merch);
        } else {
            $this->redis->expire($order_key, 0);
        }

        $data = [];
        foreach ($param as $key => $item) {
            if ($item != '' && $key != 'sign') {
                $data[$key] = $item;
            }
        }

        ksort($data);

        $sign_str = urldecode(http_build_query($data));

        Log::info($sign_str);

        $signature = md5($sign_str . "&key=" . $order_info['md5_key']);

        Log::info($signature);

        if ($signature !== $sign) {
            Log::info('验签失败');
            return 'fail';
        }
        Log::info('验签成功');

        $datas['userId'] = $order_info['merch_no'];
        $datas['requestNo'] = $param['requestNo'];
        $datas['orderNo'] = $param['orderNo'];

        ksort($datas);

        $query_sign_str = urldecode(http_build_query($datas));

        $signature = md5($query_sign_str . "&key=" . $order_info['md5_key']);

        $datas['sign'] = $signature;

        $res = Helper::post($datas, $this->query_url);
        Log::info($res);
        if ($res['userId'] != $param['userId'] || $res['status'] != $param['status'] ||
        $res['requestNo'] != $param['requestNo']){
            Log::info('查询订单，信息不一致');
            return 'fail';
        }

        if ($param['status'] == 3) {

            $amount = $param['payAmount'] / 100;

            $order_data['pay_status'] = 1;
            $order_data['out_trade_no'] = $param['orderNo'];
            $order_data['real_amount'] = $amount;
            $order_data['payed_amount'] = $amount + $order_info['deduce_amount'];
            $order_data['notify_time'] = time();
            $order_data['notify_month'] = date('Ym');
            $order_data['notify_day'] = date('Ymd');
            $order_data['notify_hour'] = date('YmH');

            $res = payNotifyService::changeOrderStatus($order_info['order_no'], $order_data);

            if (!$res) {
                Log::info('订单状态修改失败');
                return 'fail';
            }

            Log::info('订单状态修改成功');

            $optType = payNotifyService::getOptType($order_info['payment_id']);

            $extraData = [
                'order_no' => $param['requestNo'],
                'amount' => $amount,
                'pay_amount' => $amount,
                'normal_bet' => $order_info['valid_bet'],
                'active_amount' => $order_info['deduce_amount'],
                'deduce_amount' => $order_info['deduce_amount'],
                'deduce_bet' => $order_info['deduce_bet'],
                'valid_bet' => $order_info['deduce_bet'] + $order_info['valid_bet'],
                'payment_id' => $order_info['payment_id'],
            ];

            $gold = Helper::postGold($order_info['username'], $amount + $order_info['deduce_amount'],$param['requestNo'],$param['orderNo'], $optType, '', $extraData);

            if ($gold['code'] != Code::SUCCESS) {

                Log::info('修改余额失败');
                return 'fail';

            }

            Log::info('修改余额成功');

            $order_data['gold_status'] = 1;
            $order_data['order_status'] = 1;

            $res = payNotifyService::changeOrderStatus($order_info['order_no'], $order_data);
            if (!$res) {
                Log::info('订单状态修改失败1');
                return 'fail';
            }

            Log::info('成功');

            payNotifyService::changeLimitAmount($order_info,$amount);

            echo '000000';

        }else if($param['status'] == 4){

            $order_data['pay_status'] = 2;
            $order_data['gold_status'] = 0;
            $order_data['order_status'] = 0;
            $order_data['notify_time'] = time();
            $order_data['notify_month'] = date('Ym');
            $order_data['notify_day'] = date('Ymd');
            $order_data['notify_hour'] = date('YmH');

            $res = payNotifyService::changeOrderStatus($order_info['order_no'],$order_data);

            if(!$res){
                Log::info('订单状态修改失败');
                return 'fail';
            }else{
                echo '000000';
            }
        }else{
            return 'fail';
        }
    }
}