<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/23
 * Time: 22:05
 */

namespace app\controller;

use common\Code;
use think\App;
use think\Controller;
use app\library\facade\service\WithdrawService;
use common\Helper;
use common\Keys;

class Withdraw extends Controller
{
    private $redis;
    public function __construct(App $app = null)
    {
        parent::__construct($app);
        $this -> redis = redis(['database' => 4]);
    }

    public function index(){

        $order_no = $this -> request -> param('order_no','');
        $agent_id = $this -> request -> param('agent_id',0);
        $merch_agent_id = $this -> request -> param('merch_agent_id',0);
        $username = $this -> request -> param('username','');

        if(!$order_no || !$agent_id || !$merch_agent_id || !$username){
            return $this -> json([],Code::PARAM_ERROR,'订单号、出款商户、渠道id、会员id不能为空');
        }

        $order_info = WithdrawService::getOrderinfo($order_no,$agent_id,$username,$merch_agent_id);

        if(empty($order_info)){
            return $this -> json([],Code::FAIL,'未查询到订单号,请确认后重试');
        }

        $merch_agent_id = WithdrawService::getMerchInfo($merch_agent_id,$agent_id);

        if(empty($merch_agent_id)){
            return $this -> json([],Code::FAIL,'未查询到出款商户,请稍后再试');
        }

        $withdraw = array_merge($order_info,$merch_agent_id);

        $class = "app\\library\\facade\\service\\withdraw\\" . ucfirst($withdraw['merch_code']);

        $host = Helper::getHost();

        $result = $class::withdraw($withdraw , $host);

        if($result === true){

            $key = Keys::getWithdrawKey($order_no);

            $this->redis->set($key, json_encode($withdraw));

            $this->redis->expire($key, 30 * 60);

            return $this -> json([],Code::SUCCESS,'订单提交成功');
        }else{
            return $this -> json([],Code::FAIL,'出款订单提交失败,请稍后重试');
        }
    }
}