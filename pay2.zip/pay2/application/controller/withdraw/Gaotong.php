<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/21
 * Time: 16:34
 */

namespace app\controller\withdraw;

use think\Controller;
use app\library\facade\service\WithdrawNotify;
use think\facade\Log;
use common\Keys;

class Gaotong extends Controller
{
    private $redis;

    public function __construct()
    {
        parent::__construct();
        $this -> redis = redis(['database'=>4]);
    }

    public function index()
    {

        $param = $this->request->param();
        Log::info($param);
        if (empty($param) || !isset($param['sign'])) {
            return 'fail';
        }

        $sign = $param['sign'];

        $order_key = Keys::getWithdrawKey($param['orderno']);

        $order_info = $this->redis->get($order_key);

        if (!$order_info) {

            $order = WithdrawNotify::getOrder($param['orderno']);
            if (empty($order) || $order['status'] != 2) {
                return 'fail';
            }

            $merch = WithdrawNotify::findMerch($order['merch_agent_id']);

            if (empty($merch)) {
                return 'fail';
            }

            $order_info = array_merge($order, $merch);
        } else {
            $this->redis->expire($order_key, 0);
        }

        $data = [];
        foreach ($param as $key => $item) {
            if ($item != '' && $key != 'sign') {
                $data[$key] = $item;
            }
        }

        ksort($data);

        $sign_str = urldecode(http_build_query($data));
        Log::info($sign_str);
        $signature = md5($sign_str . '&key=' . $order_info['md5_key']);
        Log::info($signature);
        if ($signature !== $sign) {
            Log::info('验签失败');
            return 'fail';
        }

        Log::info('验签成功');

        $order_data['status'] = 3;
        $order_data['cach_time'] = time();
        $order_data['cach_month'] = date('Ym', time());
        $order_data['cach_day'] = date('Ymd', time());
        $order_data['cach_hour'] = date('YmdH', time());

        $res = WithdrawNotify::changeOrderStatus($order_info['order_no'], $order_data);

        if (!$res) {
            Log::info('订单状态修改失败');
            return 'fail';
        }

        Log::info('订单状态修改成功');

        WithdrawNotify::insertPayincome($order_info);

        echo 'success';
    }
}