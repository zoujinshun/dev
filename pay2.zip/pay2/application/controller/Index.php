<?php


namespace app\controller;


use think\Controller;

class Index extends Controller
{

    public function index(){

        return $this ->json([],405,'Request Error');
//        $param = $this -> request -> param();
//        $private_key = "-----BEGIN RSA PRIVATE KEY-----
//MIICXwIBAAKBgQDJuBGPjLGTIPICHiA5neiqkVd6PBAgh2EPnK5ves5skEW+s7+e
//M6z0gYE4Mvnh/AvW2fJhjW8p+LSYBnAnj2qDRqQc7g8khNQqugFjD79BurQcw41x
//pdarxVW6gM/6XVSJOoyqZVNj3niZtn/ry2iI4zlMjs1Cqd5mX5t2w6dqyQIDAQAB
//AoGBAMXPXlEhzAUWmpvfBQTbSAzzyA/TFJGBkHnp0Nj7Wa/2bp6K0A6IaEPBN4Fv
//48FrFAUV5u0o7+j9vcMTFSqGJhBkpkxRraSw21DuDx2JCf6RabVS3gdwdIDG4yy3
//XDPOaw6Hg4iVFENnE7V/tClyAxmYs8s2T1ov6nlUVU1VLpPxAkEA9qsao+VdnHYz
//jSEfmIuNe6i4fYQ0sq34+swX5Tc7fyzBrZwYYVG2+OKcn7h/VffeTRPjdg00M7cj
//JRejB73U5QJBANFZpVp/yuvCyCNV7SETPbgYKdjWlpHsw3XGg8lHRdaWZvaVLukg
//lqb6h+d6SfM0ivF8zWLIebJ0hPJ6GdsF5BUCQQD12gRrZqiu0YEAIQuE11Lk9X0s
//XSDJFm0aS2FlrG84ijtf9jy2guODnRnOd+0ymiKPYEtN1ks5YEc/KRftF1+hAkEA
//gUHoZkgg8hABok+baaCHqvLAY7Gapd6ZkE5RcCUhaazTRcw2epo0akSlRLaskg0O
///Ksh5KwC97wZmdzpueGZQQJBAMM3UYAd6UD0P5Py5/DRHKAg4VDVLwC0LtyoxmBl
//dSh9Hl9Wy6BPdv9dpEZH58WdhRYpEvtAFk99v8aRk0M+cEA=
//-----END RSA PRIVATE KEY-----";
//        $signature = $this -> getSignature($param,false,false,'|');
//        $sign = $this -> sign($signature,$private_key,'RSA','base64',OPENSSL_ALGO_SHA256);
//        echo $sign;die;
//    }
//
//    protected function getSignature($params , $sort=true , $is_key=true , $link='default',$encode = false)
//    {
//
//        if($sort){
//            ksort($params);
//        }
//
//        $signature = '';
//
//        if($is_key){
//            if($link == 'default'){
//                $signature .= http_build_query($params);
//                if(!$encode){
//                    $signature = urldecode($signature);
//                }
//            }else{
//                foreach($params as $key=>$value){
//                    $signature .= $key . '=' . $value . $link;
//                }
//                $signature = trim($signature,$link);
//            }
//        }else{
//            foreach($params as $key=>$value){
//                $signature .= $value . $link;
//            }
//            $signature = trim($signature,$link);
//        }
//        return $signature;
//    }
//
//    protected function sign($signature,$key,$method = 'md5',$encrypt='base64',$option = ''){
//        switch ($method){
//            case "MD5":
//                $sign = strtoupper(md5($signature));
//                break;
//            case 'RSA':
//                $private_key = openssl_get_privatekey($key);
//                if($option !== ''){
//                    openssl_sign($signature,$sign,$private_key,$option);
//                }else{
//                    openssl_sign($signature,$sign,$private_key);
//                }
//                openssl_free_key($private_key);
//                if($encrypt == 'base64'){
//                    $sign = base64_encode($sign);
//                }else{
//                    $sign = bin2hex($sign);
//                }
//                break;
//            case 'sha1':
//                $sign = sha1($signature);
//                break;
//            default:
//                $sign = md5($signature);
//                break;
//        }
//        return $sign;
    }
}