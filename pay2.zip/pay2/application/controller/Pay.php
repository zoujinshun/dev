<?php

namespace app\controller;

use common\Helper;
use common\Keys;
use think\App;
use think\Controller;
use common\Code;
use app\library\facade\service\{PayService,Common};
use think\facade\Config;
use think\facade\Log;

/**
 * 首页接口
 */
class Pay  extends Controller
{

    private $bank_info;
    private $payment_info;
    private $bank_pay;
    private $key;
    private $redis;

    public function __construct(App $app = null)
    {
        parent::__construct($app);
        $this->bank_info = Config::get('pay_info.bank_info');
        $this->payment_info = Config::get('pay_info.payment_info');
        $this->bank_pay = Config::get('pay_info.bank_pay');
        $this->key = Config::get('pay_info.key');
        $this->redis = redis();
    }

    public function index()
    {
        $username = $this->request->param('username', '');
        $amount = $this->request->param('amount', 0.00);
        $paytype = $this->request->param('paytype', 0);
        $payment_id = $this->request->param('payment_id', 0);
        $payment_type = $this->request->param('payment_type', '');

        $sign_str = "username={$username}&amount={$amount}&paytype={$paytype}&payment_type={$payment_type}&payment_id={$payment_id}";
        $sign = md5($sign_str . "&key=" . $this -> key);
        return $this->json([], Code::SUCCESS, $sign);
    }

    /*
     * 统一支付接口
     * @param username 会员id
     * @param amount 支付金额 单位：元
     * @param pay_type 支付方式 2-微信充值,4-银行充值,15-支付宝充值,11-百度钱包,10-点卡充值,8-QQ钱包,12-京东支付
     * @param bank_code 银行代码
     * @param card_no 银行卡号
     * @param card_id 身份证号
     * @param phone_number
     * @return $pay_data
     *
     * */

    public function paySubmit()
    {
        $username = $this->request->param('username', '');
        $amount = $this->request->param('amount', 0.00);
        $paytype = $this->request->param('paytype', 0);
        $payment_id = $this->request->param('payment_id', 0);
        $payment_type = $this->request->param('payment_type', '');
        $sign = $this->request->param('sign', '');

        Log::info($this->request->param());

        if (!$sign) {
            return $this->json([], Code::FAIL, '签名不能为空');
        }

        if (!$username || !$amount || !$payment_id || $amount <= 0 || $payment_type == '' || !$paytype) {
            return $this->json([], Code::FAIL, '必传参数不能为空');
        }

        $paytypes = array_keys($this->payment_info);

        if (!in_array($paytype, $paytypes)) {
            return $this->json([], Code::FAIL, '支付方式代码错误');
        }

        $sign_str = "username={$username}&amount={$amount}&paytype={$paytype}&payment_type={$payment_type}&payment_id={$payment_id}";

        $signature = md5($sign_str . "&key={$this->key}");

//        if ($signature !== $sign) {
//            return $this->json([], Code::FAIL, '验签失败');
//        }

        $pay_amount = explode('.',$amount);

        if(count($pay_amount) > 1){
            $len = strlen($pay_amount[1]);
            if($len > 2){
                $amount = $pay_amount[0] . '.' . substr($pay_amount[1],0,2);
            }else if($len < 2){
                $amount .= $pay_amount[1] . '0';
            }

        }else{
            $amount .= '.00';
        }

//        $user = payService::getUserInfo($username);
//
//        if (empty($user) || !isset($user['platform_type']) || !isset($user['level_setting_id'])) {
//            return $this->json([], Code::FAIL, '获取用户信息失败,请确认后重试');
//        }

        $level_setting_id = 1;

        $platform_type = 12345;

        $key = Keys::getLimitKey($username);

        $limit = $this->redis->get($key);

        if ($limit) {
            $this->redis->set($key, time(), 5);
            return $this->json([], Code::FAIL, '交易频繁，请5秒后申请支付');
        }

        $pay_setting = payService::getPaySetting($platform_type);

        if (empty($pay_setting)) {
            return $this->json([], Code::FAIL, '充值上下限未设置,请联系客服人员');
        }

        if ($pay_setting['charge_online_min'] > $amount || $pay_setting['charge_online_max'] < $amount) {
            return $this->json([], Code::FAIL, '充值金额不符合充值上下限,请确认后重试');
        }

        $payments = payService::chosePayment($paytype, $amount, $platform_type, $level_setting_id,$payment_id,$payment_type);

        if (empty($payments)) {
            return $this->json([], Code::FAIL, '暂无支付通道,请确认支付金额以及会员层级信息');
        }

        $deduce_amount = ($amount * $pay_setting['charge_online_rate']) / 100;
        $valid_bet = (float)($amount * $pay_setting['charge_online_betrate']);
        $deduce_bet = (float)($deduce_amount * $pay_setting['charge_online_betrate']);

        $host = Helper::getHost();

        foreach ($payments as $payment) {

            $class = "app\\library\\facade\\service\\pay\\" . ucfirst($payment['merch_code']);

            $key = ['md5_key'=>$payment['md5_key'],'public_key' => $payment['public_key'],'private_key' => $payment['private_key']];

            $result = $class::pay($paytype, $amount, $payment['merch_no'], $key,$host,$payment_type,$username);

            if (empty($result) || $result['code'] != Code::SUCCESS) {
                continue;
            }

            $order_data['order_no'] = $result['order_no'];
            $order_data['platform_type'] = $platform_type;
            $order_data['username'] = $username;
            $order_data['amount'] = (float)$amount;
            $order_data['payment_id'] = (int)$payment['payment_id'];
            $order_data['merch_agent_id'] = (int)$payment['merch_agent_id'];
            $order_data['channel_type'] = $payment['channel_type'];
            $order_data['config_valid_bet'] = $valid_bet;
            $order_data['deduce_amount'] = $deduce_amount;
            $order_data['deduce_bet'] = $deduce_bet;

            $res = Common::create_order($order_data);

            if ($res) {
                $data = ['pay_url' => $result['pay_url'], 'type' => $result['type']];

                return $this->json($data, Code::SUCCESS, 'Success');
            }
        }
        return $this->json([], Code::FAIL, '暂无通道可用');
    }
}


//            Log::info($result);
//
//            $order_key = Keys::getOrderKey($result['order_no']);
//            $payment_info = [
//                'agent_id' => $user['platform_type'],
//                'merch_agent_id' => $payment['merch_agent_id'],
//                'payment_id' => $payment['payment_id'],
//                'md5_key' => $payment['md5_key'],
//                'public_key' => $payment['public_key'],
//                'private_key' => $payment['private_key'],
//                'username' => $user['username'],
//                'merch_no' => $payment['merch_no'],
//                'amount' => $amount,
//                'deduce_amount' => $deduce_amount,
//                'vaild_bet' => $amount * $pay_setting['charge_online_betrate'],
//                'deduce_bet' => $deduce_amount * $pay_setting['charge_online_betrate'],
//                'channel_type' => $payment_type
//            ];
//            $this->redis->set($order_key, json_encode($payment_info));
//            $this->redis->expire($order_key, 30 * 60);



