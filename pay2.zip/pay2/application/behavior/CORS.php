<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/17
 * Time: 14:28
 */
namespace app\behavior;
class CORS
{
    public function appInit(){
//        $domain = request()->header('origin');
//        header('Access-Control-Allow-Credentials:true');
//        header('Access-Control-Allow-Origin'.$domain);
//        header("Access-Control-Allow-Headers: token, Origin, X-Requested-With, Content-Type, Accept, Authorization");
//        header('Access-Control-Allow-Methods: POST,GET,PUT,DELETE');

        if(request()->isOptions()){
            exit();
        }
    }

}