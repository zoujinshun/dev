<?php

namespace app\library;

use app\model\Admin;
use app\model\AgentPkg;
use app\model\AuthGroup;
use app\model\AuthGroupAccess;
use app\model\Pkg;
use common\Random;
use common\Tree;
use think\facade\Config;
use think\facade\Cookie;
use think\facade\Log;
use think\facade\Request;
use think\facade\Session;

class Auth extends \common\Auth
{

    protected $_error = '';
    protected $requestUri = '';
    protected $breadcrumb = [];
    protected $logined = false; //登录状态

    public function __construct()
    {
        parent::__construct();
    }

    public function __get($name)
    {
        return Session::get('admin.' . $name);
    }

    /**
     * 管理员登录
     *
     * @param   string $username 用户名
     * @param   string $password 密码
     * @param   int $keeptime 有效时长
     * @return  boolean
     */
    public function login($username, $password, $keeptime = 0)
    {
        $admin = Admin::get(['username' => $username]);
        if (!$admin) {
            $this->setError('Username is incorrect');
            return false;
        }
        if ($admin['status'] == 'hidden') {
            $this->setError('Admin is forbidden');
            return false;
        }
        if (Config::get('fastadmin.login_failure_retry') && $admin->loginfailure >= 10 && time() - $admin->updatetime < 86400) {
            $this->setError('Please try again after 1 day');
            return false;
        }
        if ($admin->password != md5(md5($password) . $admin->salt)) {
            $admin->loginfailure++;
            $admin->save();
            $this->setError('Password is incorrect');
            return false;
        }
        $admin->loginfailure = 0;
        $admin->logintime = time();
        $admin->token = Random::uuid();
        $admin->save();
        $sadmin = $admin->toArray();
        //登录用户所属代理组id或超级管理员组id
        $sadmin['agent_group_id'] = $this->getAgentGroupId($this->getGroupId($admin->id)) ;
        $sadmin['is_super'] =  $this->isSuperAdmin($admin->id);
        $sadmin['pkg_id']   = AgentPkg::where("agent_id",$admin->agent_id)->value("pkg_id");
        Session::set("admin", $sadmin);
        $this->keeplogin($keeptime);
        return true;
    }

    /**
     * 注销登录
     */
    public function logout()
    {
        $admin = Admin::get(intval($this->id));
        if (!$admin) {
            return true;
        }
        $admin->token = '';
        $admin->save();
        $this->logined = false; //重置登录状态
        Session::delete("admin");
        Cookie::delete("keeplogin");
        return true;
    }

    /**
     * 自动登录
     * @return boolean
     */
    public function autologin()
    {
        $keeplogin = Cookie::get('keeplogin');
        if (!$keeplogin) {
            return false;
        }
        list($id, $keeptime, $expiretime, $key) = explode('|', $keeplogin);
        if ($id && $keeptime && $expiretime && $key && $expiretime > time()) {
            $admin = Admin::get($id);
            if (!$admin || !$admin->token) {
                return false;
            }
            //token有变更
            if ($key != md5(md5($id) . md5($keeptime) . md5($expiretime) . $admin->token)) {
                return false;
            }
            Session::set("admin", $admin->toArray());
            //刷新自动登录的时效
            $this->keeplogin($keeptime);
            return true;
        } else {
            return false;
        }
    }

    /**
     * 刷新保持登录的Cookie
     *
     * @param   int $keeptime
     * @return  boolean
     */
    protected function keeplogin($keeptime = 0)
    {
        if ($keeptime) {
            $expiretime = time() + $keeptime;
            $key = md5(md5($this->id) . md5($keeptime) . md5($expiretime) . $this->token);
            $data = [$this->id, $keeptime, $expiretime, $key];
            Cookie::set('keeplogin', implode('|', $data), 86400 * 30);
            return true;
        }
        return false;
    }

    public function check($name, $uid = '', $relation = 'or', $mode = 'url')
    {
        return parent::check($name, $this->id, $relation, $mode);
    }

    /**
     * 检测当前控制器和方法是否匹配传递的数组
     *
     * @param array $arr 需要验证权限的数组
     * @return bool
     */
    public function match($arr = [])
    {
        $request = Request::instance();
        $arr = is_array($arr) ? $arr : explode(',', $arr);
        if (!$arr) {
            return FALSE;
        }

        $arr = array_map('strtolower', $arr);
        // 是否存在
        if (in_array(strtolower($request->action()), $arr) || in_array('*', $arr)) {
            return TRUE;
        }

        // 没找到匹配
        return FALSE;
    }

    public function isSuperAdmin($uid = null)
    {
        if(!$uid){
            if(Session::get("admin.is_super")){
                return true;
            }
            $uid = $this->id;
            $group_id = Session::get("admin.agent_group_id");
        }else{
            $group_id = $this->getAgentGroupId($this->getGroupId($uid));
        }
        if($uid == 1){
            return true;
        }
        $group_type = AuthGroup::where('id',$group_id)->value("group_type");
        return $group_type == AuthGroup::GROUP_TYPE_ADMIN && in_array('*', $this->getRuleIds());
    }
    /**
     * 检测是否登录
     *
     * @return boolean
     */
    public function isLogin()
    {
        if ($this->logined) {
            return true;
        }

        $admin = Session::get('admin');
        if (!$admin) {
            return false;
        }
        //判断是否同一时间同一账号只能在一个地方登录
        if (Config::get('fastadmin.login_unique')) {
            $my = Admin::get($admin['id']);
            if (!$my || $my['token'] != $admin['token']) {
                return false;
            }
        }
        $this->logined = true;
        return true;
    }

    /**
     * 获取当前请求的URI
     * @return string
     */
    public function getRequestUri()
    {
        return $this->requestUri;
    }

    /**
     * 设置当前请求的URI
     * @param string $uri
     */
    public function setRequestUri($uri)
    {
        $this->requestUri = $uri;
    }

    public function getGroups($uid = null)
    {
        $uid = is_null($uid) ? $this->id : $uid;
        return parent::getGroups($uid);
    }

    public function getRuleList($uid = null)
    {
        $uid = is_null($uid) ? $this->id : $uid;
        return parent::getRuleList($uid);
    }

    public function getUserInfo($uid = null)
    {
        $uid = is_null($uid) ? $this->id : $uid;

        return $uid != $this->id ? Admin::get(intval($uid)) : Session::get('admin');
    }

    public function getRuleIds($uid = null)
    {
        $uid = is_null($uid) ? $this->id : $uid;
        return parent::getRuleIds($uid);
    }

    /**
     * 获取管理员所属于的分组ID
     * @param int $uid
     * @return array
     */
    public function getGroupIds($uid = null)
    {
        $groups = $this->getGroups($uid);
        $groupIds = [];
        foreach ($groups as $K => $v) {
            $groupIds[] = (int)$v['group_id'];
        }
        return $groupIds;
    }

    /**
     * 获得面包屑导航
     * @param string $path
     * @return array
     */
    public function getBreadCrumb($path = '')
    {
        if ($this->breadcrumb || !$path)
            return $this->breadcrumb;
        $path_rule_id = 0;
        foreach ($this->rules as $rule) {
            $path_rule_id = $rule['name'] == $path ? $rule['id'] : $path_rule_id;
        }
        if ($path_rule_id) {
            $this->breadcrumb = Tree::instance()->init($this->rules)->getParents($path_rule_id, true);
            foreach ($this->breadcrumb as $k => &$v) {
                $v['url'] = url($v['name']);
                $v['title'] = __($v['title']);
            }
        }
        return $this->breadcrumb;
    }


    /**
     * 设置错误信息
     *
     * @param string $error 错误信息
     * @return Auth
     */
    public function setError($error)
    {
        $this->_error = $error;
        return $this;
    }

    /**
     * 获取错误信息
     * @return string
     */
    public function getError()
    {
        return $this->_error ? __($this->_error) : '';
    }

    /**
     * @desc 获取当前账号组的所属代理组id
     * @param $groupid  子账号组id或者代理id或者管理员组id
     * @return bool|mixed
     */
    public function getAgentGroupId($groupid)
    {
        if(!$groupid){
            Log::error(__METHOD__."参数错误 {$groupid}");
            return false;
        }
        while(1){
            $group = AuthGroup::where('id',$groupid)->field("id,pid,group_type")->find();
            if(!$group){
                Log::error(__METHOD__."分组记录 not found {$groupid}");
                return false;
            }
            if($group['group_type'] == AuthGroup::GROUP_TYPE_ADMIN){
                return $group->id;
            }
            if($group['group_type'] == AuthGroup::GROUP_TYPE_AGENT){
                return $group->id;
            }
            if($group['group_type'] == AuthGroup::GROUP_TYPE_INTERNAL){
                $groupid =  $group->pid;
            }else{
                Log::error(__METHOD__." group_type 异常 {$groupid}");
                return false;
            }
        }
        return false;
    }
    /**
     * @desc 获取当前账号组的所属代理组id
     * @param $groupid
     * @return bool|mixed
     */
    public function getAgentGroup($groupid=null)
    {
        if(!$groupid){
            $groupid = $this->getGroupId($this->id);
        }
        $agentGroupId = $this->getAgentGroupId($groupid);
        $list = AuthGroup::all($agentGroupId);
        return $list;
    }

    /**
     * @desc 规定每个账号只能有一个组，即可以获取账号组id,-1表示异常组，
     */
    public function getGroupId($uid){
//        $group_ids = $this->getGroupIds($uid);
//        $group_id = !empty($group_ids)?array_pop($group_ids):-1;
        $group_id = AuthGroupAccess::where("uid",$uid)->value("group_id");
        return $group_id;
    }

    /**
     * 取出当前管理员直属下级的分组
     *
     * @param boolean $withself 是否包含当前所在的分组
     * @return array
     */
    public function getChildGroupIds($withself = false, $group_type = false, $groupId = false)
    {
        if(!$groupId){
            $groupId = $this->getGroupId($this->id);
        }
        $where = array(
            'pid' => ['eq', $groupId]
        );
        if($group_type !== false){
            $where['group_type'] = ['eq', $group_type];
        }
        $groupIds = AuthGroup::where($where)->column('id');
        if ($withself && $groupIds) {
            array_push($groupIds, $groupId);
            $childrenGroupIds = $groupIds;
        }else{
            $childrenGroupIds = $groupIds;
        }
        return $childrenGroupIds;
    }

    /**
     * @desc 获取当前用户所属的代理用户名
     */
    public function getAgentName($uid=null)
    {
        if(!$uid){
            $uid = $this->id;
        }
        $agentGroupId = $this->getAgentGroupId($this->getGroupId($uid));
        $agentUid = AuthGroupAccess::where('group_id',$agentGroupId)
            ->whereIn("is_agent",[AuthGroup::IS_AGENT_ADMIN,AuthGroup::IS_AGENT_Y])
            ->value('uid');
        $username = Admin::where('id',$agentUid)->value('username');
        return $username;
    }

    /**
     * @desc 获取当前代理或子账号的代理id
     */
    public function getAdminAgentId($uid=null)
    {
        if(!$uid){
            $uid = $this->id;
        }
        $agentGroupId = $this->getAgentGroupId($this->getGroupId($uid));
        $agentUid = AuthGroupAccess::where('group_id',$agentGroupId)
            ->whereIn("is_agent",[AuthGroup::IS_AGENT_ADMIN,AuthGroup::IS_AGENT_Y])
            ->value('uid');
        $agentId = Admin::where('id',$agentUid)->value('agent_id');
        return $agentId;
    }


    /**
     * @desc 获取本代理的上级代理信息，超级管理员不是代理，
     * @param $uid int 用户id
     */
    public function getParentAgentInfo($uid)
    {
        $groupId = $this->getGroupId($uid);
        if(!$groupId){
            return [];
        }
        $agentGroupId = $this->getAgentGroupId($groupId);
        $parentAgentGroupId = AuthGroup::where("id",$agentGroupId)->value("pid");
        $parentAgentId = AuthGroupAccess::where('group_id',$parentAgentGroupId)
            ->whereIn("is_agent",[AuthGroup::IS_AGENT_ADMIN,AuthGroup::IS_AGENT_Y])
            ->value('uid');
        $agentInfo = Admin::where("id",$parentAgentId)->find();
        return $agentInfo?$agentInfo->toArray():[];
    }
    /**
     * 取出当前管理员所拥有权限的管理员
     * @param boolean $withself 是否包含自身
     * @return array
     */
    public function getChildrenAdminIds($withself = false,$group_type=false,$group_id=null)
    {
        $childrenAdminIds = [];
        if (!$this->isSuperAdmin()) {
            $groupIds = $this->getChildrenGroupIds(false,$group_type,$group_id);
            $authGroupList = \app\model\AuthGroupAccess::
            field('uid,group_id')
                ->where('group_id', 'in', $groupIds)
                ->select();

            foreach ($authGroupList as $k => $v) {
                $childrenAdminIds[] = $v['uid'];
            }
        } else {
            if($group_id ==null)
            {
                if($group_type !== false){
                    $groupIds = AuthGroup::where("group_type",$group_type)->column("id");
                    $authGroupList = \app\model\AuthGroupAccess::
                    field('uid,group_id')
                        ->where('group_id', 'in', $groupIds)
                        ->select();

                    foreach ($authGroupList as $k => $v) {
                        $childrenAdminIds[] = $v['uid'];
                    }
                }else{
                    //超级管理员拥有所有人的权限
                    $childrenAdminIds = Admin::column('id');
                }
            }else{
                $groupIds = $this->getChildrenGroupIds(false,$group_type,$group_id);
                $authGroupList = \app\model\AuthGroupAccess::
                field('uid,group_id')
                    ->where('group_id', 'in', $groupIds)
                    ->select();

                foreach ($authGroupList as $k => $v) {
                    $childrenAdminIds[] = $v['uid'];
                }
            }
        }
        if($group_id)
        {
            $agentGroupId = $this->getAgentGroupId($group_id);
        }else{
            $agentGroupId = $this->getAgentGroupId($this->getGroupId($this->id));
        }
        $selfUid = AuthGroupAccess::where("group_id",$agentGroupId)->value("uid");
        if ($withself) {
            if (!in_array($selfUid, $childrenAdminIds)) {
                $childrenAdminIds[] = $selfUid;
            }
        } else {
            $childrenAdminIds = array_diff($childrenAdminIds, [$selfUid]);
        }

        return $childrenAdminIds;
    }
    /**
     * 取出当前管理员所拥有权限的分组
     * @param boolean $withself 是否包含当前所在的分组
     * @return array
     */
    public function getChildrenGroupIds($withself = false,$group_type=false,$group_id=null)
    {
        //取出当前管理员所有的分组,可能子账号登陆，需要获取的是代理的组
        $groups = $this->getAgentGroup($group_id);
        $groupIds = [];
        foreach ($groups as $k => $v) {
            $groupIds[] = $v['id'];
        }
        // 取出所有分组
        if($group_type === false){
            $groupList = \app\model\AuthGroup::where(['status' => 'normal'])->select();
        }else{
            $groupList = \app\model\AuthGroup::where(['group_type'=>$group_type,'status' => 'normal'])->select();
        }

        $objList = [];
        foreach ($groups as $K => $v) {
            if ($v['rules'] === '*') {
                $objList = $groupList;
                break;
            }
            if($group_type === false){  // 取出包含自己的所有子节点
                $childrenList = Tree::instance()->init($groupList)->getChildren($v['id'], true);
                $obj = Tree::instance()->init($childrenList)->getTreeArray($v['pid']);
                $objList = array_merge($objList, Tree::instance()->getTreeList($obj));
            }else{  // 取出包含自己的直属子节点
                if($group_type == AuthGroup::GROUP_TYPE_INTERNAL){
                    $childrenList = Tree::instance()->init($groupList)->getChildren($v['id'], true);
                    $obj = Tree::instance()->init($childrenList)->getTreeArray($v['id']);
                    $objList = array_merge($objList, Tree::instance()->getTreeList($obj));
                }else{//如果取代理子节点，只能取直属代理
                    $childrenList = Tree::instance()->init($groupList)->getChild($v['id']);
                    $objList = array_merge($objList, $childrenList);
                }

            }
        }
        $childrenGroupIds = [];
        foreach ($objList as $k => $v) {
            $childrenGroupIds[] = $v['id'];
        }

        if (!$withself) {
            $childrenGroupIds = array_diff($childrenGroupIds, $groupIds);
        }else{//xiexingqiao add
            $childrenGroupIds = array_unique(array_merge($childrenGroupIds, $groupIds));
        }

        return $childrenGroupIds;
    }
}
