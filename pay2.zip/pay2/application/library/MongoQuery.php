<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/5/22
 * Time: 15:54
 */

namespace app\library;


use \MongoDB\BSON\Binary;
use \MongoDB\BSON\Decimal128;
use \MongoDB\BSON\Type;
use \MongoDB\Model\BSONDocument;
use think\Exception;
use think\facade\Log;

trait MongoQuery
{
    public function insertData($data, $getLastInsID = false)
    {
        $collection = mongo($this->database)->{$this->table};
        $data = $this->getTypeData($data);
        $insertOneResult = $collection->insertOne($data);
        return $getLastInsID ? $insertOneResult->getInsertedId() : $insertOneResult->getInsertedCount();
    }

    public function findAllData($where = [], $fields = '*', $sort = [], $offset = null, $limit = null)
    {
        $collection = mongo($this->database)->{$this->table};
        $option = [];
        if ($fields !== '*' && is_string($fields)) {
            $fieldsArr = explode(',', $fields);
            foreach ($fieldsArr as $field) {
                $projections[$field] = 1;
            }
            $option['projection'] = $projections;
        } elseif (is_array($fields)) {
            $option['projection'] = $fields;
        }
        !isset($option['projection']['_id']) && $option['projection']['_id'] = 0;
        if ($offset !== null) {
            $option['skip'] = (int) $offset;
        }
        if ($limit !== null) {
            $option['limit'] = (int) $limit;
        }
        if (!empty($sort)) {
            $option['sort'] = $sort;
        }
        $cursor = $collection->find($where, $option);
        $result = [];
        foreach ($cursor as $document) {
            $document = (array)$document;
            foreach ($document as &$data)
            {
                if($data instanceof  \MongoDB\BSON\ObjectId){
                    $data = (string)$data;
                }
                if($data instanceof  \MongoDB\Model\BSONArray){

                    foreach ($data as $index =>$value)
                    {
                        if($value instanceof  \MongoDB\Model\BSONDocument ){
                            $arr[$index] = (array)$value;
                        }else{
                            $arr[$index] = $value;
                        }
                    }
                    $data = $arr??[];
                }else if($data instanceof  \MongoDB\Model\BSONDocument){
                    foreach ($data as $index=>&$value)
                    {
                        $arr[$index] = $value;
                    }
                    $data = $arr??[];
                }
                elseif(is_object($data)){
                    $data = (array)$data;
                }elseif(is_array($data)){

                    //二维数据
                    if((count($data) !== count($data)-1)){
                        foreach ($data as &$value)
                        {
                            $value = (array)$value;
                        }
                    }

                }else{

                }

            }
            $result[] = (array) $document;

        };
        return $result;
    }

    /**
     * @desc 支持分页相关操作
     * @param $where
     * @param  string  $fields
     * @param  array  $group
     * @param  array  $sort
     * @param  int  $count
     * @return array
     */
    public function paginate($where, $fields = '*', $group = [], $sort = [], $count = 20)
    {
        $page = request()->param('page', 1);
        $offset = ($page - 1) * $count;
        $data = $this->findAllData($where, $fields, $sort, $offset, $count);
        $total = $this->countsComplext($where, $group);
        $result = [
            'total'        => (int) $total,
            'per_page'     => $count,
            'current_page' => (int) $page,
            'last_page'    => intval(ceil($total / $page)),
            'data'         => $data,
        ];
        return $result;
    }

    /**
     * @desc 查询单行数据
     * @param $data
     * @return mixed
     */

    public function findData($where = [], $fields = '*', $sort = [])
    {
        $collection = mongo($this->database)->{$this->table};
        $option = [];
        if ($fields !== '*' && is_string($fields)) {
            $fieldsArr = explode(',', $fields);
            foreach ($fieldsArr as $field) {
                $projections[$field] = 1;
            }
            $option['projection'] = $projections;
        } elseif (is_array($fields)) {
            $option['projection'] = $fields;
        }
        !isset($option['projection']['_id']) && $option['projection']['_id'] = 0;
        if ($sort) {
            $option['sort'] = $sort;
        }
        $document = $collection->findOne($where, $option);
        $document = (array)$document;
        foreach ($document as &$data)
        {
            if($data instanceof  \MongoDB\BSON\ObjectId){
                $data = (string)$data;
            }
            if($data instanceof  \MongoDB\Model\BSONArray){

                foreach ($data as $index =>$value)
                {
                    if($value instanceof  \MongoDB\Model\BSONDocument ){
                        $arr[$index] = (array)$value;
                    }else{
                        $arr[$index] = $value;
                    }
                }
                $data = $arr??[];
            }else if($data instanceof  \MongoDB\Model\BSONDocument){
                foreach ($data as $index=>&$value)
                {
                    $arr[$index] = $value;
                }
                $data = $arr??[];
            }
            elseif(is_object($data)){
                $data = (array)$data;
            }elseif(is_array($data)){

                //二维数据
                if((count($data) !== count($data)-1)){
                    foreach ($data as &$value)
                    {
                        $value = (array)$value;
                    }
                }

            }else{

            }

        }
        return (array)$document;
    }

    private function getResult($dataSet)
    {
        if (!$dataSet) {
            return $dataSet;
        }
        foreach ($dataSet as $key => &$set) {
            if ($set instanceof \MongoDB\Model\BSONArray) {
                $set = (array) $set;
            } elseif ($set instanceof BSONDocument) {
                $set = $this->getResult($set);
            } elseif ($set instanceof Type) {
                $set = (string) $set;
            } elseif (is_array($set)) {
                $set = $this->getResult($set);
            }
        }
        $dataSet = (array) json_decode(json_encode($dataSet), true);
        foreach ($dataSet as &$valueTmp) {
            $type = gettype($valueTmp);
            if (preg_match("/double/", $type)) {
                $valueTmp = (double) sprintf("%.2f", (double) $valueTmp);
            }
        }
        return $dataSet;
    }



    /**
     * @desc 批量更新数据,只支持set更新
     * @param $data
     * @return mixed
     */
    public function updateAllData($where, $data)
    {
        $collection = mongo($this->database)->{$this->table};
        $data = $this->getTypeData($data);
        $updateResult = $collection->updateMany($where, ['$set' => $data]);
        return $updateResult->getMatchedCount();
    }

    /**
     * @desc 更新数据，支持下面两种选项
     * options  ['upsert' => true]
     * @param $where
     * @param $data
     * @param  array  $options
     * @return mixed
     */
    public function updateData($where, $data = [], $options = [])
    {
        $collection = mongo($this->database)->{$this->table};
        $incs = $push = $sets = $pull = $pop = $pullAll = $addToSet = [];
        foreach ($data as $key => $item) {
            preg_match("/(\w*)\[(.*)\]/", $key, $matches);
            if (count($matches) == 3) {
                $rkey = $matches[1];
                $mathSign = $matches[2];
                if ($mathSign == '+') {
                    $incs[$rkey] = $item;
                } elseif ($mathSign == '-') {
                    $incs[$rkey] = $item > 0 ? -1 * $item : abs($item);
                } elseif ($mathSign == 'push') {
                    $push[$rkey] = $item;
                } elseif ($mathSign == 'pull') {
                    $pull[$rkey] = $item;
                } elseif ($mathSign == 'pop') {
                    $pop[$rkey] = $item;
                } elseif ($mathSign == 'pullAll') {
                    $pullAll[$rkey] = $item;
                } elseif ($mathSign == 'addToSet') {
                    $addToSet[$rkey] = $item;
                } else {
                    $updatedata['$'.$mathSign][$rkey] = $item;
                }

            } else {
                $sets[$key] = $item;
            }
        }
        if ($sets) {
            $updatedata['$set'] = $sets;
        }
        if ($incs) {
            $updatedata['$inc'] = $incs;
        }
        if ($push) {
            $updatedata['$push'] = $push;
        }
        if ($pull) {
            $updatedata['$pull'] = $pull;
        }
        if ($pullAll) {
            $updatedata['$pullAll'] = $pullAll;
        }
        if ($pop) {
            $updatedata['$pop'] = $pop;
        }
        if ($addToSet) {
            $updatedata['$addToSet'] = $addToSet;
        }
        foreach ($updatedata as &$data) {
            $data = $this->getTypeData($data);
        }
        $updateResult = $collection->updateOne(
            $where,
            $updatedata,
            $options
        );
        return $updateResult->getMatchedCount();
    }

    public function updateDataRaw($where, $data, $options = [])
    {
        $collection = mongo($this->database)->{$this->table};
        $updateResult = $collection->updateMany(
            $where,
            $data,
            $options
        );
        return $updateResult->getMatchedCount();
    }

    /**
     * @desc 简单场景下自增数据，影响一行
     * @param $data
     * @return mixed
     */
    public function incrementData($where, $data, $options = [])
    {
        $collection = mongo($this->database)->{$this->table};
        $updateResult = $collection->updateOne(
            $where,
            ['$inc' => $data],
            $options
        );
        return $updateResult->getMatchedCount();
    }

    /**
     * @desc 批量插入数据
     * @param $data
     * @return mixed
     */
    public function insertAllData($data)
    {
        $collection = mongo($this->database)->{$this->table};
        $insertOneResult = $collection->insertMany($data);
        return $insertOneResult->getInsertedCount();
    }

    /**
     * @desc 删除数据
     * @param $where
     * @return mixed
     */
    public function deleteData($where)
    {
        $collection = mongo($this->database)->{$this->table};
        $deleteResult = $collection->deleteMany($where);
        return $deleteResult->getDeletedCount();
    }

    /**
     * @desc 聚合操作
     * @param $pipeline
     * @return array
     */
    public function aggregate($pipeline)
    {
        $collection = mongo($this->database)->{$this->table};
        $cursor = $collection->aggregate($pipeline);
        $result = [];
        foreach ($cursor as $document) {
            $result[] = (array) $document;
        }
        return (array) $result;
    }

    public function getTypeData($data)
    {
        if (!property_exists($this, 'dataType')) {
            Log::alert("db:{$this->database} table:{$this->table} ".'property dataType not exists');
            return $data;
        }
        foreach ($data as $key => &$val) {
            if (is_array($val)) {
                //一维数组
                if(count($val) == count($val,COUNT_RECURSIVE)){
                    if(array_keys($val) === range(0,count($val)-1)){ //数字索引数组,
                        $type = $this->dataType[$key.'[]'] ?? gettype($val[0]);
                        $i = 0;$maxCount = count($val);
                        while($i < $maxCount){
                            if (preg_match("/int/", $type)) {
                                $val[$i] = (int) $val[$i];
                            } elseif (preg_match("/string/", $type)) {
                                $val[$i] = (string) $val[$i];
                            } elseif (preg_match("/(double|float)/", $type)) {
                                $val[$i] = (double) sprintf("%.2f", (double) $val[$i]);
                            } elseif (preg_match("/bool/", $type)) {
                                $val[$i] = (boolean) $val[$i];
                            }
                            $i++;
                        }
                    }else{//字符串 key
                        foreach ($val as $subKey=>$subValue)
                        {
                            $type = $this->dataType[$key.".$subKey"] ??gettype($subValue);
                            if (preg_match("/int/", $type)) {
                                $val[$subKey] = (int) $val[$subKey];
                            } elseif (preg_match("/string/", $type)) {
                                $val[$subKey] = (string) $val[$subKey];
                            } elseif (preg_match("/(double|float)/", $type)) {
                                $val[$subKey] = (double) sprintf("%.2f", (double) $val[$subKey]);
                            } elseif (preg_match("/bool/", $type)) {
                                $val[$subKey] = (boolean) $val[$subKey];
                            }

                        }
                    }
                }else{
                    //多维数组，目前支持到二维数组
                    foreach ($val as $index=>$item){
                        foreach ($item as $subKey=> $subValue )
                        {
                            $type = $this->dataType[$key."[].$subKey"] ??gettype($subValue);
                            if (preg_match("/int/", $type)) {
                                $val[$index][$subKey] = (int) $val[$index][$subKey];
                            } elseif (preg_match("/string/", $type)) {
                                $val[$index][$subKey] = (string) $val[$index][$subKey];
                            } elseif (preg_match("/(double|float)/", $type)) {
                                $val[$index][$subKey] = (double) sprintf("%.2f", (double) $val[$index][$subKey]);
                            } elseif (preg_match("/bool/", $type)) {
                                $val[$index][$subKey] = (boolean) $val[$index][$subKey];
                            }
                        }
                    }
                }
            }else{
                $defaultType = gettype($val);
                $type = $this->dataType[$key] ?? $defaultType;
                if (preg_match("/int/", $type)) {
                    $val = (int) $val;
                } elseif (preg_match("/string/", $type)) {
                    $val = (string) $val;
                } elseif (preg_match("/double/", $type)) {
                    $val = (double) sprintf("%.2f", (double) $val);
                } elseif (preg_match("/bool/", $type)) {
                    $val = (boolean) $val;
                }
            }

        }
        return $data;
    }

    /**
     * @desc 支持简单计数，shard
     * @param $where
     * @param  array  $options
     * @return mixed
     */
    public function counts($where, $options = [])
    {
        $collection = mongo($this->database)->{$this->table};
        $count = $collection->countDocuments($where, $options);
        return $count;
    }

    /**
     * 需要group场景下的计数
     * @param $where
     * @param  array  $group
     * @return integer
     */
    public function countsComplext($where, $group = [])
    {
        $pipeline = [];
        if (!empty($where)) {
            $pipeline[] = ['$match' => $where];
        }
        if (!empty($group)) {
            $pipeline[] = ['$group' => $group];
        }
        $pipeline[] = ['$group' => ['_id' => null, 'count' => ['$sum' => 1]]];
        $total = $this->aggregate($pipeline);
        $total = $total[0]['count'] ?? 0;
        return $total;
    }


    /**
     * 查找所有数据
     * @param  array  $where
     * @param  array  $group
     * @param  array  $fields
     * @param  array  $sort
     * @param  null  $count
     * @param  int  $page
     * @return array
     */
    public function findAll(
        array $where = [],
        $group = [],
        array $fields = [],
        array $sort = [],
        $count = null,
        int $page = 1,
        array $whereGroup = []
    ): array {
        $pipeline = $this->getPipeline($where, $group, $fields, $sort, $count, $page, $whereGroup);
        $data = $this->aggregate($pipeline);
        foreach ($data as &$v) {
            if (is_array($group)) {
                foreach ($group as $key => $value) {
                    if (isset($v['_id'][$key])) {
                        $v[$key] = $v['_id'][$key];
                    } else {
                        $v[$key] = '';
                    }
                }
            }
            if (isset($v['_id']) || $v['_id'] == null) {
                unset($v['_id']);
            }
        }
        //强制数据保留俩位小数
        foreach ($data as &$valueTmp) {
            $type = gettype($valueTmp);
            if (preg_match("/double/", $type)) {
                $valueTmp = (double) sprintf("%.2f", (double) $valueTmp);
            }
        }
        return $data;
    }

    /**
     * 分组统计相关
     * @param  array  $where
     * @param  array  $groupBy
     * @param  string  $field  默认未所有，字符串则逗号分隔
     * @param  int  $count
     * @return array
     */
    public function getStatInfo($where = [], $group = [], $fields = [], $sort = [], $count = null, $whereGroup = [])
    {
        if (is_string($fields)) {
            $fields = explode(',', $fields);
        }
        $page = request()->param('page', 1);
        $data = $this->findAll($where, $group, $fields, $sort, $count, $page, $whereGroup);
        $result = [];
        if ($count) {
            $total = $this->getCountsComplext($where, $group, $fields, $sort,
                0, $page, $whereGroup);
            $result = [
                'total'        => (int) $total,
                'per_page'     => $count,
                'current_page' => (int) $page,
                'last_page'    => intval(ceil($total / $count)),
            ];
        }
        $result['data'] = $data;
        return $result;
    }

    /**
     * 获取总计数量
     * @param  array  $where
     * @param  array  $group
     * @param  array  $fields
     * @param  array  $sort
     * @param  null  $count
     * @param  int  $page
     * @param  array  $whereGroup
     * @return int
     */
    public function getCountsComplext(
        array $where = [],
        $group = [],
        array $fields = [],
        array $sort = [],
        $count = null,
        int $page = 1,
        array $whereGroup = []
    ) {
        $pipeline = $this->getPipeline($where, $group, $fields, $sort, $count, $page, $whereGroup);
        $pipeline[] = ['$group' => ['_id' => null, 'count' => ['$sum' => 1]]];
        $total = $this->aggregate($pipeline);
        return $total = $total[0]['count'] ?? 0;
    }


    public function getPipeline(
        array $where = [],
        $group = [],
        array $fields = [],
        array $sort = [],
        $count = null,
        $page = 1,
        array $whereGroup = []
    ) {
        $groups = $this->getGroup($group, $fields);
        $pipeline = [];
        $project = [];
        foreach (array_keys($groups) as $field) {
            $project[$field] = 1;
            if (strpos($field, 'count_') !== false) {
                $project[$field] = ['$size' => "$".$field];
            }
            if ($field == 'persons') {
                $project[$field] = ['$size' => '$persons'];
            }
        }
        if (!empty($where)) {
            $pipeline[] = ['$match' => $where];
        }
        $pipeline[] = ['$group' => $groups];
        if (!empty($project)) {
            $pipeline[] = ['$project' => $project];
        }
        if (!empty($whereGroup)) {
            $pipeline[] = ['$match' => $whereGroup];
        }
        if (!empty($sort)) {
            $pipeline[] = ['$sort' => $sort];
        }
        if ($count) {
            $offset = ($page - 1) * $count;
            $pipeline[] = ['$limit' => (int) $count * $page];
            $pipeline[] = ['$skip' => (int) $offset];
        }
        return $pipeline;
    }

    /**
     * 获取总计数据
     * @param  array  $param
     * @param  array  $fields
     * @return array
     */
    public function getTotalStat(array $where = [], $group = [], array $fields = []): array
    {
        $groups = $this->getGroup($group, $fields);
        $project = [];
        foreach (array_keys($groups) as $field) {
            $project[$field] = 1;
            if (strpos($field, 'count_') !== false) {
                $project[$field] = ['$size' => "$".$field];
            }
            if ($field == 'persons') {
                $project[$field] = ['$size' => '$persons'];
            }
        }
        $pipeline = [];
        if (!empty($where)) {
            $pipeline[] = ['$match' => $where];
        }
        $pipeline[] = ['$group' => $groups];
        if (!empty($project)) {
            $pipeline[] = ['$project' => $project];
        }
        if ($group !== null) {
            $groupsFields = ['_id' => null];
            foreach (array_keys($groups) as $field) {
                if (strpos($field, '_id') === false) {
                    $groupsFields[$field] = ['$sum' => "$".$field];
                }
            }
            $pipeline[] = ['$group' => $groupsFields];
        }
        $data = $this->aggregate($pipeline);
        foreach ($data as &$v) {
            if (is_array($group)) {
                foreach ($group as $key => $value) {
                    if (isset($v['_id'][$key])) {
                        $v[$key] = $v['_id'][$key];
                    } else {
                        $v[$key] = '';
                    }
                }
            }
            if (isset($v['_id']) || $v['_id'] == null) {
                unset($v['_id']);
            }
        }
        $data = $data[0] ?? [];
        $total = [];
        foreach ($fields as $v) {
            //保留2为小数
            $tmp = $data[$v] ?? 0;
            $type = gettype($tmp);
            if (preg_match("/double/", $type)) {
                $data[$v] = (double) sprintf("%.2f", (double) $tmp);
            }
            //end
            $total["total_".$v] = $tmp; //总计前面加前缀
        }
        unset($data);
        return $total;
    }
}