<?php


namespace app\library\facade\service;


use think\Facade;
/**
 * Class PayNotify
 * @package app\library\facade\service
 * @mixin \app\service\PayNotify
 */
class PayNotify extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\PayNotify::class;
    }
}