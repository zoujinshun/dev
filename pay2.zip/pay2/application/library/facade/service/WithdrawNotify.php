<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/21
 * Time: 16:45
 */

namespace app\library\facade\service;


use think\Facade;
/**
 * Class WithdrawNotify
 * @package app\library\facade\service
 * @mixin \app\service\WithdrawNotify
 */
class WithdrawNotify extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\WithdrawNotify::class;
    }
}