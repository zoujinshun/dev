<?php


namespace app\library\facade\service;


use think\Facade;
/**
 * Class PayService
 * @package app\library\facade\service
 * @mixin \app\service\PayService
 */
class PayService extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\PayService::class;
    }
}