<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/19
 * Time: 14:53
 */

namespace app\library\facade\service\pay;


use think\Facade;
/**
 * Class SuiPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\SuiPay
 */
class SuiPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\SuiPay::class;
    }
}