<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/17
 * Time: 17:09
 */

namespace app\library\facade\service\pay;

use think\Facade;
/**
 * Class ShengtaiPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\ShengtaiPay
 */
class ShengtaiPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\ShengtaiPay::class;
    }
}