<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/9
 * Time: 19:36
 */

namespace app\library\facade\service\pay;


use think\Facade;
/**
 * Class JinPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\JinPay
 */
class JinPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\JinPay::class;
    }
}