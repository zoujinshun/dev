<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/20
 * Time: 16:29
 */

namespace app\library\facade\service\pay;

use think\Facade;

/**
 * Class BujiaPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\BujiaPay
 */
class BujiaPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\BujiaPay::class;
    }
}