<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/20
 * Time: 20:42
 */

namespace app\library\facade\service\pay;


use think\Facade;
/**
 * Class RongyaoPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\RongyaoPay
 */
class RongyaoPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\RongyaoPay::class;
    }
}