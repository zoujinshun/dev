<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/9
 * Time: 19:36
 */

namespace app\library\facade\service\pay;


use think\Facade;
/**
 * Class JinzuanPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\JinzuanPay
 */
class JinzuanPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\JinzuanPay::class;
    }
}