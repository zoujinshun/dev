<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/20
 * Time: 16:29
 */

namespace app\library\facade\service\pay;

use think\Facade;

/**
 * Class CaiPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\CaiPay
 */
class CaiPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\CaiPay::class;
    }
}