<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/17
 * Time: 17:09
 */

namespace app\library\facade\service\pay;

use think\Facade;
/**
 * Class ShanyunPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\ShanyunPay
 */
class ShanyunPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\ShanyunPay::class;
    }
}