<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/20
 * Time: 21:34
 */

namespace app\library\facade\service\pay;

use think\Facade;
/**
 * Class ChangePay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\ChangePay
 */
class ChengmengPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\ChengmengPay::class;
    }
}