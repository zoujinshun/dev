<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/26
 * Time: 16:13
 */

namespace app\library\facade\service\pay;

use think\Facade;

/**
 * Class XingyunPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\XingyunPay
 */
class XingyunPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\XingyunPay::class;
    }
}