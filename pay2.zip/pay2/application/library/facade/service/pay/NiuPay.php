<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/16
 * Time: 11:11
 */

namespace app\library\facade\service\pay;

use think\Facade;

/**
 * Class NiuPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\NiuPay
 */
class NiuPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\NiuPay::class;
    }
}