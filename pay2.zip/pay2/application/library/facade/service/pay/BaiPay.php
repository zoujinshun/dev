<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/3
 * Time: 15:00
 */

namespace app\library\facade\service\pay;

use think\Facade;

/**
 * Class BaiPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\BaiPay
 */
class BaiPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\BaiPay::class;
    }
}