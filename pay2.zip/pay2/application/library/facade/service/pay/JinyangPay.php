<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/9
 * Time: 19:36
 */

namespace app\library\facade\service\pay;


use think\Facade;
/**
 * Class JinyangPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\JinyangPay
 */
class JinyangPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\JinyangPay::class;
    }
}