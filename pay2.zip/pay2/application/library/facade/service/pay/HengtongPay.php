<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/16
 * Time: 19:28
 */

namespace app\library\facade\service\pay;


use think\Facade;

/**
 * Class HengtongPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\HengtongPay
 */
class HengtongPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\HengtongPay::class;
    }
}