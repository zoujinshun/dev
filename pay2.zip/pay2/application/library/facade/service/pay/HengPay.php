<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/9
 * Time: 17:25
 */

namespace app\library\facade\service\pay;


use think\Facade;
/**
 * Class HengPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\HengPay
 */
class HengPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\HengPay::class;
    }
}