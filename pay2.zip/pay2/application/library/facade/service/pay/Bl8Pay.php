<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/20
 * Time: 16:29
 */

namespace app\library\facade\service\pay;

use think\Facade;

/**
 * Class Bl8Pay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\Bl8Pay
 */
class Bl8Pay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\Bl8Pay::class;
    }
}