<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/17
 * Time: 14:18
 */

namespace app\library\facade\service\pay;

use think\Facade;

/**
 * Class BbgPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\BbgPay
 */
class BbgPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\BbgPay::class;
    }
}