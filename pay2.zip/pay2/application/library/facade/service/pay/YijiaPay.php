<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/26
 * Time: 16:13
 */

namespace app\library\facade\service\pay;

use think\Facade;

/**
 * Class YijiaPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\YijiaPay
 */
class YijiaPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\YijiaPay::class;
    }
}