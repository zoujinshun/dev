<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/19
 * Time: 14:53
 */

namespace app\library\facade\service\pay;


use think\Facade;
/**
 * Class SzPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\SzPay
 */
class SzPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\SzPay::class;
    }
}