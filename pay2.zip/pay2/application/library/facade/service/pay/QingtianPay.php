<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/2
 * Time: 21:00
 */

namespace app\library\facade\service\pay;


use think\Facade;
/**
 * Class QingtianPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\QingtianPay
 */
class QingtianPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\QingtianPay::class;
    }
}