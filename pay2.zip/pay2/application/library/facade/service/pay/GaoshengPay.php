<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/4
 * Time: 11:17
 */

namespace app\library\facade\service\pay;


use think\Facade;
/**
 * Class GaoshengPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\GaoshengPay
 */
class GaoshengPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\GaoshengPay::class;
    }
}