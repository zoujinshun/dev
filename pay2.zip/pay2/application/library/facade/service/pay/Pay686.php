<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/2
 * Time: 21:00
 */

namespace app\library\facade\service\pay;


use think\Facade;
/**
 * Class Pay686
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\Pay686
 */
class Pay686 extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\Pay686::class;
    }
}