<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/20
 * Time: 14:51
 */

namespace app\library\facade\service\pay;

use think\Facade;

/**
 * Class WangPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\WangPay
 */
class WangPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\WangPay::class;
    }
}