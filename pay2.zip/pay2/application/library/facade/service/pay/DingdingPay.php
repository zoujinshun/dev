<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/3
 * Time: 16:38
 */

namespace app\library\facade\service\pay;


use think\Facade;
/**
 * Class DingdingPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\DingdingPay
 */
class DingdingPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\DingdingPay::class;
    }
}