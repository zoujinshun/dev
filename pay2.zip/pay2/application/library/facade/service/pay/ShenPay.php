<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/17
 * Time: 11:30
 */

namespace app\library\facade\service\pay;

use think\Facade;

/**
 * Class ShenPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\ShenPay
 */
class ShenPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\ShenPay::class;
    }
}