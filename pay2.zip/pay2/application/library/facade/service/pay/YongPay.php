<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/19
 * Time: 11:26
 */

namespace app\library\facade\service\pay;

use think\Facade;

/**
 * Class YongPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\YongPay
 */
class YongPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\YongPay::class;
    }
}