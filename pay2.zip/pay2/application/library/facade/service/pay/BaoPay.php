<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/22
 * Time: 14:45
 */

namespace app\library\facade\service\pay;


use think\Facade;
/**
 * Class BaoPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\BaoPay
 */
class BaoPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\BaoPay::class;
    }
}