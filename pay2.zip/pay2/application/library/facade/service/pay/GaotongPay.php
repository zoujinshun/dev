<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/17
 * Time: 15:00
 */

namespace app\library\facade\service\pay;

use think\Facade;
/**
 * Class GaotongPay
 * @package app\library\facade\pay\service
 * @mixin \app\service\pay\GaotongPay
 */
class GaotongPay extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\pay\GaotongPay::class;
    }
}