<?php
/**
 * Created by PhpStorm.
 * User: xiexingqiao
 * Date: 2019/4/29
 * Time: 20:36
 */

namespace app\library\facade\service;


use think\Facade;

class  Withdraw  extends Facade
{ 
    protected static function getFacadeClass()
    {
        return  \app\service\Withdraw::class;
    }
}