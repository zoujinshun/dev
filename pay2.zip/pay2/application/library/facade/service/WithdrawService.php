<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/21
 * Time: 11:30
 */

namespace app\library\facade\service;


use think\Facade;
/**
 * Class WithdrawService
 * @package app\library\facade\service
 * @mixin \app\service\Withdraw
 */
class WithdrawService extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\Withdraw::class;
    }
}