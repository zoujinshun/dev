<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/24
 * Time: 17:34
 */

namespace app\library\facade\service\withdraw;

use think\Facade;

/**
 * Class Gaotong
 * @package app\library\facade\withdraw\service
 * @mixin \app\service\withdraw\Gaotong
 */
class Gaotong extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\withdraw\Gaotong::class;
    }
}