<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/26
 * Time: 11:47
 */

namespace app\library\facade\service;


use think\Facade;
/**
 * Class Common
 * @package app\library\facade\service
 * @mixin \app\service\CommonService
 */
class Common extends Facade
{
    protected static function getFacadeClass()
    {
        return \app\service\CommonService::class;
    }
}