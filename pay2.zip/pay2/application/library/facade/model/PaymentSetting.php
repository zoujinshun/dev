<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/22
 * Time: 9:56
 */

namespace app\library\facade\model;

use think\Facade;
/**
 * Class PaymentSetting
 * @package app\library\facade\model
 * @mixin \app\model\PaymentSetting
 */
class PaymentSetting extends Facade
{
    protected static function getFacadeClass()
    {
        return  \app\model\PaymentSetting::class;
    }
}