<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/22
 * Time: 19:15
 */

namespace app\library\facade\model;


use think\Facade;
/**
 * Class Order
 * @package app\library\facade\model
 * @mixin \app\model\Order

 */
class Order extends Facade
{
    protected static function getFacadeClass()
    {
        return  \app\model\Order::class;
    }
}