<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/21
 * Time: 11:21
 */

namespace app\library\facade\model;


use think\Facade;
/**
 * Class WithdrawOrder
 * @package app\library\facade\model
 * @mixin \app\model\WithdrawOrder

 */
class WithdrawOrder extends Facade
{
    protected static function getFacadeClass()
    {
        return  \app\model\WithdrawOrder::class;
    }
}