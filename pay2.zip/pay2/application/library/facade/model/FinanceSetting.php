<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/22
 * Time: 9:53
 */

namespace app\library\facade\model;


use think\Facade;
/**
 * Class FinanceSetting
 * @package app\library\facade\model
 * @mixin \app\model\FinanceSetting

 */
class FinanceSetting extends Facade
{
    protected static function getFacadeClass()
    {
        return  \app\model\FinanceSetting::class;
    }

}