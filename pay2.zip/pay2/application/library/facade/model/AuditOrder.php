<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/21
 * Time: 11:43
 */

namespace app\library\facade\model;


use think\Facade;
/**
 * Class AuditOrder
 * @package app\library\facade\model
 * @mixin \app\model\AuditOrder

 */
class AuditOrder extends Facade
{
    protected static function getFacadeClass()
    {
        return  \app\model\AuditOrder::class;
    }
}