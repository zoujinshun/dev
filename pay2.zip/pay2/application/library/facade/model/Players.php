<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/20
 * Time: 17:56
 */

namespace app\library\facade\model;


use think\Facade;
/**
 * Class Players
 * @package app\library\facade\model
 * @mixin \app\model\Players

 */
class Players extends Facade
{
    protected static function getFacadeClass()
    {
        return  \app\model\Players::class;
    }
}