<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/20
 * Time: 17:38
 */

namespace app\library\facade\model;


use think\Facade;
/**
 * Class MerchAgentSetting
 * @package app\library\facade\model
 * @mixin \app\model\MerchAgentSetting

 */
class MerchAgentSetting extends Facade
{
    protected static function getFacadeClass()
    {
        return  \app\model\MerchAgentSetting::class;
    }

}