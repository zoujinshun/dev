<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/21
 * Time: 17:49
 */

namespace app\library\facade\model;


use think\Facade;
/**
 * Class PayIncomeDb
 * @package app\library\facade\model
 * @mixin \app\model\PayIncomeDb
 */
class PayIncomeDb extends Facade
{
    protected static function getFacadeClass()
    {
        return  \app\model\PayIncomeDb::class;
    }
}