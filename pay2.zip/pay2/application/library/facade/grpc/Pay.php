<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/11/27
 * Time: 14:48
 */

namespace app\library\facade\grpc;


use think\Facade;
/**
 * Class Pay
 * @package app\library\facade\grpc
 * @mixin \app\grpc\Pay

 */
class Pay extends Facade
{
    protected static function getFacadeClass()
    {
        return  \app\grpc\Pay::class;
    }
}