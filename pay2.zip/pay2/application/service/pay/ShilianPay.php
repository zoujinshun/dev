<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/2
 * Time: 21:00
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Config;

class ShilianPay extends CommonService
{
    private $notify_url = '/notify/shilianpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = ['15'=>['wap'=>'alipay','scan'=>'aliqr']];
    private $pay_url = 'http://pay.pcfpay.cn/pay/unifiedorder';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['mch_id'] = $merch_no;
        $param['trade_type'] = $this->payment[$paytype][$payment_type];
        $param['nonce'] = $this -> getStr();
        $param['timestamp'] = time();
        $param['subject'] = '购买眼镜';
        $param['detail'] = '海俪恩太阳眼镜';
        $param['out_trade_no'] = $order_no;
        $param['total_fee'] = $amount * 100;
        $param['spbill_create_ip'] = '192.168.2.98';
        $param['timeout'] = 30;
        $param['sign_type'] = 'MD5';
        $param['notify_url'] = $host . $this -> notify_url;

        ksort($param);

        $sign_str = urldecode(http_build_query($param));

        $sign = strtoupper(md5($sign_str .'&key='. $key['md5_key']));

        $param['sign'] = $sign;

        $res = Helper::post(json_encode($param),$this -> pay_url,['Content-Type: application/json; charset=utf-8']);

        $res = json_decode($res,true);

        if($res['payState'] == 'fail'){
            return [];
        }

        if($res['payState'] == 'success'){

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $res['url'];
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;
            return $result;
        }

        return [];

    }
}