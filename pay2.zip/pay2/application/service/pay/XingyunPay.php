<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/3
 * Time: 16:37
 */

namespace app\service\pay;


use app\service\CommonService;
use common\Code;
use common\Helper;
use common\Keys;
use think\facade\Config;
class XingyunPay extends CommonService
{
    private $notify_url = '/notify/xingyunpay';
    private $return_url = 'http://www.baidu.com';
    private $platform = ['2'=>'WECHAT','15'=>'ALIPAY'];
    private $payment = [
        '2' => ['scan'=>'QRCODE'],
        '15' => ['scan' => 'QRCODE']
    ];
    private $pay_url = 'http://api.xyseven.com:8443/api/order/create';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['app_id'] = $merch_no;
        $param['platform'] = $this -> platform[$paytype];
        $param['method'] = $this->payment[$paytype][$payment_type];
        $param['amount'] = $amount;
        $param['out_trade_no'] = $order_no;
        $param['remark'] = 'cup';
        $param['notify_url'] = $host . $this -> notify_url;
        $param['return_url'] = $this -> return_url;

        ksort($param);

        $sign_str = $this -> getSignature($param,true,true);

        $sign = md5($sign_str."&key=".$key['md5_key']);

        $param['sign'] = $sign;

        $res = Helper::post($param,$this -> pay_url);
        var_dump($res);die;
        $res = json_decode($res,true);

        if($res['status'] == '200'){

            $pay_data = $res['data'];
            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $pay_data['cashier_url'];
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;
            return $result;
        }

        return [];

    }
}