<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/3
 * Time: 16:37
 */

namespace app\service\pay;


use app\service\CommonService;
use common\Code;
use common\Helper;
use common\Keys;
use think\facade\Config;
class JinzuanPay extends CommonService
{
    private $notify_url = '/notify/jinzuanpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2'=>['scan'=>'WechatPay'],
        '15'=>['scan'=>'AliPay'],
    ];
    private $pay_url = 'https://api.jzpay.vip/jzpay_exapi/v1/order/createOrder';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param_url['merchantId'] = $merch_no;
        $param_url['timestamp'] = Helper::getTimestamp();
        $param_url['signatureMethod'] = 'HmacSHA256';
        $param_url['signatureVersion'] = 1;

        $param_body['jUserId'] = $this -> getStr();
        $param_body['jUserIp'] = Helper::getIP();
        $param_body['jOrderId'] = $order_no;
        $param_body['orderType'] = 1;
        $param_body['payWay'] = $this -> return_url;
        $param_body['amount'] = strpos($amount,'.') !== false ? $amount : $amount . '.00';
        $param_body['currency'] = "CNY";
        $param_body['notifyUrl'] = $host . $this -> notify_url;

        $param = array_merge($param_url,$param_body);

        ksort($param);

        $sign_str = urldecode(http_build_query($param));

        $sign = strtoupper(hash_hmac('sha256',$sign_str,$key['md5_key'],false));

        $param_url['signature'] = $sign;

        $pay_url = $this -> pay_url .'?' . http_build_query($param_url);

        $res = Helper::post($param_body,$pay_url,['content-type:application/x-www-form-urlencoded']);

        $res = json_decode($res,true);

        if($res['code'] == 0){

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $res['data']['paymentUrl'];
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;
            return $result;
        }

        return [];

    }
}