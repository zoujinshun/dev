<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/22
 * Time: 14:46
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;

class BolePay extends CommonService
{
    private $notify_url = '/notify/bolepay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2'=>['wap'=>2,'scan'=>8002],
        '3'=>['quick'=>3,'wap'=>3,'scan'=>4],
        '12'=>['wap'=>8012,'scan'=>8011],
        '15'=>['wap'=>101,'scan'=>102],
    ];

    private $pay_url = 'http://47.56.189.243:39802/createorder';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['merchantid'] = $merch_no;
        $param['merchantorder'] = $order_no;
        $param['rmb'] = $amount * 100;
        $param['callback'] = $host . $this -> notify_url;
        $param['roleid'] = $this -> getStr();
        $param['extend'] = '';
        $param['paytype'] = $this->payment[$paytype][$payment_type];
        $param['time'] = Helper::getTimestamp();

        Log::info($param);

        ksort($param);

        $sign_str = urldecode(http_build_query($param));

        $sign = md5($sign_str."&key=".$key['md5_key']);

        $param['sign'] = $sign;

        $res = Helper::post($param,$this -> pay_url);

        $res = json_decode($res,true);

        if($res['code'] == '0'){

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = urldecode($res['url']);
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;
            return $result;
        }
        return [];

    }


}