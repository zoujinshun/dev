<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/17
 * Time: 14:18
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;
class BbgPay extends CommonService
{
    private $notify_url = '/notify/bbgpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2'=>['wechat','gm_wechat','JX_wechat','JBG_wechat'],
        '15'=> ['alipay','wd_alipay','gm_alipay','SN_alipay','JL_alipay','JBG_alipay']
    ];

    private $pay_url = 'http://110.42.64.155:60006/';
//    private $jd_url = 'http://42.51.43.214:6666/';

    public function pay($paytype,$amount,$merch_no,$md5_key,$host){

        $param['userid'] = $merch_no;
        $param['amount'] = $amount * 100;
        $param['callbackurl'] = $host . $this -> notify_url;
        $param['remark'] = 'cup';

        if(!isset($this->payment[$paytype])){
            return [];
        }

        foreach($this->payment[$paytype] as $item){

            $order_no = $this -> getOrderNo();
            $param['orderid'] = $order_no;
            $param['ordertype'] = $item;

            $data = $param;

            Log::info($data);

            $sign_str = strtolower("{$param['userid']}". "{$param['orderid']}". "{$param['ordertype']}". "{$param['amount']}". "{$param['callbackurl']}");

            $sign = md5($sign_str . $md5_key);

            $data['sign'] = $sign;

//            if(strpos($item,"gm") !== false || strpos($item,"jd") !== false){
//                $pay_url = $this -> jd_url;
//            }else{
//                $pay_url = $this ->  pay_url;
//            }

            $res = Helper::post($data,$this -> pay_url);

            $res = json_decode($res,true);

            if($res['success'] == 'true'){

                $result['code'] = Code::SUCCESS;
                $result['pay_url'] = $res['url'];
                $result['order_no'] = $order_no;
                $result['type'] = $key;
                return $result;
            }
        }
        return [];
    }
}