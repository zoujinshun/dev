<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/19
 * Time: 10:50
 */

namespace app\service\pay;


use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;

class YongPay extends CommonService
{
    private $notify_url = '/notify/yongpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = ['2'=>['wap'=>'922'], '15'=>['wap'=>'921']];
    private $pay_url = 'http://dd3.wb888.xyz/Pay_Index.html';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();

        $param['pay_memberid'] = $merch_no;
        $param['pay_applydate'] = date('Y-m-d H:i:s',time());
        $param['pay_notifyurl'] = $host . $this -> notify_url;
        $param['pay_amount'] = $amount;
        $param['pay_callbackurl'] = $this -> return_url;
        $param['pay_bankcode'] = $this->payment[$paytype][$payment_type];
        $param['pay_orderid'] = $order_no;

        $data = $param;

        Log::info($data);

        ksort($data);

        $sign_str = urldecode(http_build_query($data));

        $sign = strtoupper(md5($sign_str ."&key=". $key['md5_key']));

        $data['pay_md5sign'] = $sign;

        $data['pay_productname'] = 'noodle';

        $html = $this  -> setHtml($this->pay_url,$data);
        $dir = dirname(dirname(dirname(__DIR__))) . '/public/html/' . $order_no . '.html';
        $pay_url = $host. '/html/' . $order_no . '.html';
        file_put_contents($dir,$html);
        $result['code'] = Code::SUCCESS;
        $result['pay_url'] = $pay_url;
        $result['order_no'] = $order_no;
        $result['type'] = $payment_type;
        return $result;

    }
}