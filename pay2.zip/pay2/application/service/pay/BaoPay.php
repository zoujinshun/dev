<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/26
 * Time: 10:57
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;

class BaoPay extends CommonService
{
    private $notify_url = '/notify/baopay';
    private $return_url = 'http://www.baidu.com';
    private $payment = ['2'=>['scan'=>'WEIXIN'], '15'=>['scan'=>'ALIPAY']];
    private $pay_url = 'http://api.blpay1.com/PayBank.aspx';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $param['partner'] = $merch_no;
        $param['paymoney'] = $amount;
        $param['callbackurl'] = $host . $this -> notify_url;
        $param['banktype'] = $this->payment[$paytype][$payment_type];
        $param['ordernumber'] = $this -> getOrderNo();

        $sign_str = "partner={$param['partner']}".
            "&banktype={$param['banktype']}".
            "&paymoney={$param['paymoney']}".
            "&ordernumber={$param['ordernumber']}".
            "&callbackurl={$param['callbackurl']}";

        $sign = md5($sign_str . $key['md5_key']);

        $param['sign'] = $sign;

        Log::info($param);

        $res = Helper::post($param,$this -> pay_url);

        Log::info($res);

        $res = json_decode($res,true);

        if($res['success'] == 'true'){

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $res['url'];
            $result['order_no'] = $param['ordernumber'];
            $result['type'] = $payment_type;
            return $result;
        }

        return [];

    }

}