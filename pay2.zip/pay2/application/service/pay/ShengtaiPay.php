<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/20
 * Time: 20:23
 */

namespace app\service\pay;


use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;
class ShengtaiPay extends CommonService
{
    private $notify_url = '/notify/shengtaipay';
    private $return_url = 'http://www.baidu.com';
    private $payment = ['2'=>['scan'=>2], '15'=>['scan'=>3],'3'=>['scan'=>7]];
    private $pay_url = 'http://api.mssts.com/pay.html';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['notify_url'] = $host . $this -> notify_url;
        $param['return_url'] = $this -> return_url;
        $param['pay_type'] = $this->payment[$paytype][$payment_type];
        $param['merchant_code'] = $merch_no;
        $param['order_no'] = $order_no;
        $param['order_amount'] = strpos($amount,'.') === false ? $amount . ".00" : $amount;
        $param['order_time'] = date('Y-m-d H:i:s',time());

        Log::info($param);

        ksort($param);

        $sign_str = urldecode(http_build_query($param));

        $sign = md5($sign_str ."&key=". $key['md5_key']);

        $param['sign'] = $sign;

        $html = $this -> setHtml($this -> pay_url,$param);

        $dir = dirname(dirname(dirname(__DIR__))) . '/public/html/' . $order_no . '.html';
        $pay_url = $host. '/html/' . $order_no . '.html';
        file_put_contents($dir,$html);
        $result['code'] = Code::SUCCESS;
        $result['pay_url'] = $pay_url;
        $result['order_no'] = $order_no;
        $result['type'] = $payment_type;
        return $result;

//        $res = json_decode($res,true);
//
//        if($res['code'] == 200){
//
//            $result['code'] = Code::SUCCESS;
//            if($key == 'wap'){
//                $result['pay_url'] = $res['data']['payinfo'];
//            }else{
//                $result['pay_url'] = $res['data']['payimgurl'];
//            }

//        }
//
//        return [];

    }
}