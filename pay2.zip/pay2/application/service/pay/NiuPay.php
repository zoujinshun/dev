<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/2
 * Time: 21:00
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Config;

class NiuPay extends CommonService
{
    private $notify_url = '/notify/niupay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '15' => ['wap' => 'ZFB_WAP', 'scan' => 'aliqr'],
        '2' => ['wap' => 'WX_WAP', 'scan' => 'wxqr']
    ];
    private $pay_url = 'https://niuapi.ikoko.cc/v1/ordercreate';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username='')
    {

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this->getOrderNo();
        $param['login_id'] = $merch_no;
        $param['create_time'] = Helper::getTimestamp();
        $param['create_ip'] = $this -> getIP();
        $param['nonce'] = rand(111111,999999);
        $param['sign_type'] = 'MD5';
        $param['pay_type'] = $this->payment[$paytype][$payment_type];
        $param['order_type'] = 1;
        $param['order_sn'] = $order_no;
        $param['amount'] = strpos($amount,'.') !== false ? $amount : $amount . ".00";
        $param['send_currency'] = 'cny';
        $param['recv_currency'] = 'cny';
        $param['notify_url'] = $host . $this -> notify_url;

        ksort($param);

        $sign_str = urldecode(http_build_query($param));

        $sign = md5($sign_str . '&api_secret=' . $key['md5_key']);

        $param['sign'] = $sign;

        $res = Helper::post($param, $this->pay_url);

        $res = json_decode($res, true);

        if ($res['code'] == '0') {

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $res['http_url'];
            $result['order_no'] = $order_no;
            $result['type'] = $key;
            return $result;
        }

        return [];

    }
}