<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/17
 * Time: 17:09
 */

namespace app\service\pay;


use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;

class ShanyunPay extends CommonService
{
    private $notify_url = '/notify/shanyunpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = ['2'=>['wap'=>2], '15'=>['wap'=>1],'3'=>['wap'=>4,'scan'=>3]]; //,'3'=>[3,4]
    private $pay_url = 'http://pay.ydmpay.com/pay';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['uid'] = $merch_no;
        $param['price'] = strpos($amount,'.') !== false ? $amount : $amount . ".00";
        $param['notify_url'] = $host . $this -> notify_url;
        $param['return_url'] = $this -> return_url;
        $param['orderuid'] = $this -> getStr(6);
        $param['goodsname'] = 'cup';
        $param['istype'] = $this->payment[$paytype][$payment_type];
        $param['orderid'] = $order_no;
        $param['token'] = $key['md5_key'];

        Log::info($param);

        ksort($param);

        $sign_str = '';

        foreach($param as $v){
            $sign_str .= $v . 'sy';
        }

        $sign_str = substr($sign_str,0,strlen($sign_str)-2);

        $sign = md5($sign_str);

        $param['key'] = $sign;

        unset($param['token']);

        $res = Helper::post($param,$this -> pay_url);

        $dir = dirname(dirname(dirname(__DIR__))) . '/public/html/' . $order_no . '.html';
        $pay_url = $host. '/html/' . $order_no . '.html';
        file_put_contents($dir,$res);

        $result['code'] = Code::SUCCESS;
        $result['pay_url'] = $pay_url;
        $result['order_no'] = $order_no;
        $result['type'] = $payment_type;

        return $result;

    }
}