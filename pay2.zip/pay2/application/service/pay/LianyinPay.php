<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/26
 * Time: 10:57
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;

class LianyinPay extends CommonService
{
    private $notify_url = '/notify/lianyinpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = ['3'=>['quick'=>'1009','scan'=>'1009']];

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();

        $param['customer'] = $merch_no;
        $param['amount'] = strpos($amount,'.') !== false ? $amount : $amount . ".00";
        $param['orderid'] = $order_no;
        $param['asynbackurl'] = $host . $this -> notify_url;
        $param['request_time'] = date('YmdHis',time());

        $sign_str = "customer={$param['customer']}";

        if($payment_type == 'scan'){
            $param['banktype'] = $this->payment[$paytype][$payment_type];
            $sign_str .= "&banktype={$param['banktype']}";
            $pay_url = "http://gateway.lianyin88.com/GateWay/Index";
        }else{
            $pay_url = "http://gateway.lianyin88.com/FastPay/Index";
        }

        $sign_str .= "&amount={$param['amount']}".
            "&orderid={$param['orderid']}".
            "&asynbackurl={$param['asynbackurl']}".
            "&request_time={$param['request_time']}";

        $sign = md5($sign_str .'&key='. $key['md5_key']);

        $param['sign'] = $sign;

        Log::info($param);

        $res = Helper::post($param,$pay_url);

        Log::info($res);

        $res = json_decode($res,true);

        if($res['success'] == 'true'){

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $res['url'];
            $result['order_no'] = $param['ordernumber'];
            $result['type'] = $payment_type;
            return $result;
        }

        return [];

    }

}