<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/22
 * Time: 14:46
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;

class BetPay extends CommonService
{
    private $notify_url = '/notify/betpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2'=>['wap'=>8003,'scan'=>8002],
        '3'=>['quick'=>8001,'wap'=>8001,'scan'=>8014],
        '12'=>['wap'=>8012,'scan'=>8011],
        '15'=>['wap'=>8007,'scan'=>8006],
    ];
    private $appId = '3bf6813ffcfa4878bcfe3366072012df';
    private $pay_url = 'http://api.51betpay.net/api/pay/create_order';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['mchId'] = $merch_no;
        $param['appId'] = $this -> appId;
        $param['currency'] = 'cny';
        $param['amount'] = $amount * 100;
        $param['returnUrl'] = $this->return_url;
        $param['notifyUrl'] = $host . $this->notify_url;
        $param['subject'] = 'cup';
        $param['body'] = 'cup';
        $param['productId'] = $this->payment[$paytype][$payment_type];
        $param['mchOrderNo'] = $order_no;
        $param['extra'] = 'cup';

        Log::info($param);
        ksort($param);

        $sign_str = $this -> getSignature($param,true,true);

        $sign = strtoupper(md5($sign_str."&key=".$key['md5_key']));

        $param['sign'] = $sign;

        $res = Helper::post($param,$this -> pay_url);

        $res = json_decode($res,true);

        if($res['retCode'] == 'SUCCESS'){

            $method = $res['payParams']['payMethod'];
            if($method == 'formJump'){
                $html = $res['payParams']['payUrl'];
                $dir = dirname(dirname(dirname(__DIR__))) . '/public/html/' . $order_no . '.html';
                $pay_url = $host. '/html/' . $order_no . '.html';
                file_put_contents($dir,$html);
                $result['code'] = Code::SUCCESS;
                $result['pay_url'] = $pay_url;
                $result['order_no'] = $order_no;
                $result['type'] = $payment_type;
            }else{
                $result['code'] = Code::SUCCESS;
                $result['pay_url'] = $res['payParams']['codeUrl'];
                $result['order_no'] = $order_no;
                $result['type'] = $payment_type;
            }
            return $result;
        }
        return [];

    }


}