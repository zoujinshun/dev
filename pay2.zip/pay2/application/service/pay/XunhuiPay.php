<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/9
 * Time: 16:47
 */

namespace app\service\pay;
use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;

class XunhuiPay extends CommonService
{
    private $notify_url = '/notify/xunhuipay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2' => ['wap'=>'80001','scan'=>'60001'],
        '15' => ['wap'=>'80002','scan'=>'60002']
    ];
    private $pay_url = 'http://api.kuaile8899.com:8088/pay/apply.shtml';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['merchantId'] = $merch_no;
        $param['payType'] = $this->payment[$paytype][$payment_type];
        $param['orderNo'] = $order_no;
        $param['amount'] = $amount * 100;
        $param['applyTime'] = date('YmdHis');
        $param['productTitle'] = 'table';
        $param['productDesc'] = 'desk table';
        $param['notifyUrl'] = $host . $this -> notify_url;
        $param['callbackUrl'] = $this -> return_url;
        $param['extraParam'] = '';

        Log::info($param);

        $sign_str = urldecode(http_build_query($param));

        $sign = strtoupper(md5($sign_str."&merchantKey=".$key['md5_key']));

        $param['signInfo'] = $sign;

        $res = Helper::post($param,$this -> pay_url);

        $res = json_decode($res,true);

        if($res['state'] == 'success'){

            if($res['dataType'] == 'html'){
                $dir = dirname(dirname(dirname(__DIR__))) . '/public/html/' . $order_no . '.html';
                $pay_url = $host. '/html/' . $order_no . '.html';
                file_put_contents($dir,$res['payUrl']);
                $result['pay_url'] = $pay_url;
            }else{
                $result['pay_url'] = $res['payUrl'];
            }

            $result['code'] = Code::SUCCESS;
            $result['order_no'] = $order_no;
            $result['type'] = $key;
            return $result;
        }

        return [];

    }
}