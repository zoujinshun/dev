<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/17
 * Time: 15:01
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use common\Keys;
use think\facade\Config;
use think\facade\Log;
class GaotongPay extends CommonService
{
    private $notify_url = '/notify/gaotongpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2'=>['scan'=>'WEIXIN','wap'=>'WEIXINWAP'],
        '15'=>['wap'=>'ALIPAYWAP','scan'=>'ALIPAY'],
        '3' => ['fast'=>'FRONTFASTPAY','wap'=>'UNIONWAPPAY','scan'=>'UNIONPAY'],
        '10' => ['DLYKT'=>'DLYKT','DLWKT'=>'DLWKT','SZHCZK'=>'SZHCZK','LTQGCZK'=>'LTQGCZK',
            'ZGDXFFCZK'=>'ZGDXFFCZK','YCTHK'=>'YCTHK','THCFK'=>'THCFK','JWYKT'=>'JWYKT','THYKT'=>'THYKT']
    ];
    private $domain = "http://tj.gaotongpay.com/";
    private $pay_url = 'http://tj.gaotongpay.com/PayBank.aspx';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['partner'] = $merch_no;
        $param['paymoney'] = $amount;
        $param['callbackurl'] = $host . $this -> notify_url;
        $param['banktype'] = $this->payment[$paytype][$payment_type];
        $param['ordernumber'] = $order_no;

        Log::info($param);
        $sign_str = "partner={$param['partner']}".
            "&banktype={$param['banktype']}".
            "&paymoney={$param['paymoney']}".
            "&ordernumber={$param['ordernumber']}".
            "&callbackurl={$param['callbackurl']}";

        $sign = md5($sign_str . $key['md5_key']);

        $param['sign'] = $sign;

        if($paytype == 3 && $key == 'fast'){
            $param['memberid'] = $this -> getStr(8);
        }

        $res = Helper::post($param,$this -> pay_url);

        if(strpos($res,'a href="') !== false){
            $str = Helper::getStr('a href="','"></a>',$res);
            $res = $this -> domain . $str;
        }

        if(strpos($res,"action='") !== false){
            $res = str_replace("action='","action='http://tj.gaotongpay.com",$res);
        }

        $dir = dirname(dirname(dirname(__DIR__))) . '/public/html/' . $order_no . '.html';
        $pay_url = $host. '/html/' . $order_no . '.html';
        file_put_contents($dir,$res);

        $result['code'] = Code::SUCCESS;
        $result['pay_url'] = $pay_url;
        $result['order_no'] = $order_no;
        $result['type'] = $key;
        return $result;
    }
}