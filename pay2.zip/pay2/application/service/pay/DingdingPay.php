<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/3
 * Time: 16:37
 */

namespace app\service\pay;


use app\service\CommonService;
use common\Code;
use common\Helper;
use common\Keys;
use think\facade\Config;
class DingdingPay extends CommonService
{
    private $notify_url = '/notify/dingdingpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2'=>['wap'=>'wxPayH5 ','scan'=>'wxPaySM'],
        '3' => ['quick'=>'unionPayKJ','scan'=>'unionPaySM'],
        '12' => ['scan' => 'jdPaySM'],
        '15'=>['wap'=>'aliPayH5','scan'=>'aliPaySM'],
    ];
    private $pay_url = 'http://api.ddpay2019.com/api/pay';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['version'] = 'v1.0';
        $param['type'] = $this->payment[$paytype][$payment_type];
        $param['userId'] = $merch_no;
        $param['requestNo'] = $order_no;
        $param['amount'] = $amount * 100;
        $param['callBackURL'] = $host . $this -> notify_url;
        $param['redirectUrl'] = $this -> return_url;

        ksort($param);

        $sign_str = urldecode(http_build_query($param));

        $sign = md5($sign_str."key=".$key['md5_key']);

        $param['attachData'] = '';
        $param['sign'] = $sign;

        $res = Helper::post(json_encode($param,320),$this -> pay_url);

        $res = json_decode($res,true);

        if($res['status'] == 1){

            if($res['payUrl'] ==  ''){
                $dir = dirname(dirname(dirname(__DIR__))) . '/public/html/' . $order_no . '.html';
                $pay_url = $host. '/html/' . $order_no . '.html';
                file_put_contents($dir,$res['payHTML']);
            }else{
                $pay_url = $res['payUrl'];
            }
            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $pay_url;
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;
            return $result;
        }

        return [];

    }
}