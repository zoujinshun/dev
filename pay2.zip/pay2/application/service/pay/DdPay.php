<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/3
 * Time: 16:37
 */

namespace app\service\pay;


use app\service\CommonService;
use common\Code;
use common\Helper;
use common\Keys;
use think\facade\Config;
class DdPay extends CommonService
{
    private $notify_url = '/notify/didapay';
    private $return_url = 'http://www.baidu.com';
    private $payment = ['3' => ['scan'=>912], '12' => ['scan' => 911]];
    private $pay_url = 'https://ddbay.ddongbay.com/index/pay/gateway';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['user_id'] = $merch_no;
        $param['return_url'] = $this -> return_url;
        $param['notify_url'] = $host . $this -> notify_url;
        $param['subject'] = 'cup';
        $param['body'] = 'cup';
        $param['remark'] = 'cup';
        $param['pay_amount'] = $amount;
        $param['applydate'] = time();
        $param['product_id'] = $this->payment[$paytype][$payment_type];
        $param['out_trade_no'] = $order_no;

        ksort($param);

        $sign_str = $this -> getSignature($param,true,true);

        $sign = strtoupper(md5($sign_str."&apikey=".$key['md5_key']));

        $param['sign'] = $sign;

        $res = Helper::post($param,$this -> pay_url);

        $res = json_decode($res,true);

        if($res['code'] == '0'){

            $pay_data = $res['data'];
            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $pay_data['pay_extends']['pay_url'];
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;
            return $result;
        }

        return [];

    }
}