<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/26
 * Time: 10:57
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;
class YijiaPay extends CommonService
{

    private $notify_url = '/notify/yijiapay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2'=>['wap'=>'wxwap','scan'=>'wxqrcode'],
        '15'=>['wap'=>'wap','scan'=>'qrcode'],
        '3'=>['scan'=>'ylsm','quick'=>'ysf']
    ];
    private $pay_url = 'http://api.yjpay2019.com/api/addOrder';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['merchant'] = $merch_no;
        $param['amount'] = $amount * 100;
        $param['pay_type'] = $this->payment[$paytype][$payment_type];
        $param['order_no'] = $order_no;
        $param['order_time'] = time();
        $param['subject'] = 'table';
        $param['notify_url'] = $host . $this -> notify_url;
        $param['callback_url'] = $this -> return_url;

        Log::info($param);

        ksort($param);

        $sign_str = urldecode(http_build_query($param));

        $sign = sha1($sign_str ."&key=". $key['md5_key']);

        $param['sign'] = $sign;

        $res = Helper::post($param,$this -> pay_url);

        $res = json_decode($res,true);

        if($res['success'] == 'true' && $res['code'] == '0000'){

            $result['code'] = Code::SUCCESS;
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;

            if(in_array($paytype,[15,2]) && $payment_type == 'scan'){
                $dir = dirname(dirname(dirname(__DIR__))) . '/public/html/pay.html';
                $html_dir = dirname(dirname(dirname(__DIR__))) . '/public/html/' . $order_no . '.html';
                $html = file_get_contents($dir);
                $html = str_replace('100.00',$amount,$html);
                $html = str_replace('订单:1572426795075293509',"订单:{$order_no}",$html);
                if($paytype == 2){
                    $html = str_replace('支付宝',"微信",$html);
                }

                $pay_url = $host. '/html/' . $order_no . '.html';
                file_put_contents($html_dir,$html);

                $result['pay_url'] = $pay_url;
            }else{
                $result['pay_url'] = $res['result']['qrCode'];
            }
            return $result;
        }

        return [];

    }
}