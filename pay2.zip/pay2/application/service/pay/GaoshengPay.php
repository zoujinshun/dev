<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/3
 * Time: 19:58
 */

namespace app\service\pay;


use app\service\CommonService;
use common\Code;
use common\Helper;
use common\Keys;
use think\facade\Config;
use think\facade\Log;

class GaoshengPay extends CommonService
{
    private $notify_url = '/notify/gaoshengpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = ['2'=>['wap'=>'WX_WAP','scan'=>'WX',], '15'=>['wap'=>'ZFB_WAP','scan'=>'ZFB']];
    private $pay_url = 'http://gway.yt888f.com:7060/api/qrCodePay.action';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username='')
    {

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['appId'] = $merch_no;
        $param['nonceStr'] = (string)rand(100000,9999999);
        $param['totalAmount'] = (string)($amount * 100);
        $param['goodsInfo'] = 'food';
        $param['notifyUrl'] = $host . $this -> notify_url;
        $param['returnUrl'] = $this -> return_url;
        $param['requestIp'] = $this -> getIP();
        $param['payType'] = $this->payment[$paytype][$payment_type];
        $param['outTradeNo'] = $order_no;

        Log::info($param);
        ksort($param);

        $sign_str = json_encode($param,320);

        $sign = strtoupper(md5($sign_str . $key['md5_key']));

        $param['sign'] = $sign;

        $params = json_encode($param,320);

        $post = ['reqData'=>$params];

        $res = Helper::post($post, $this->pay_url);

        $res = json_decode($res, true);

        if ($res['resultCode'] == '00') {

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $res['qrCode'];
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;

            return $result;
        }

        return [];
    }

}