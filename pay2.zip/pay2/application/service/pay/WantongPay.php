<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/20
 * Time: 20:17
 */

namespace app\service\pay;


use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;

class WantongPay extends CommonService
{
    private $notify_url = '/notify/wantongpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = ['2'=>['scan'=>'WEIXIN'], '15'=>['scan'=>'ALIPAY']];
    private $pay_url = 'http://gate.motel147.com/Paybank.aspx';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        $param['partner'] = $merch_no;
        $param['paymoney'] = $amount;

        $param['callbackurl'] = $host . $this -> notify_url;

        if(!isset($this->payment[$paytype])){
            return [];
        }

        foreach($this->payment[$paytype] as $key=>$value){

            $order_no = $this -> getOrderNo();
            $param['banktype'] = $value;
            $param['ordernumber'] = $order_no;

            $data = $param;
            Log::info($data);
            $sign_str = "partner={$param['partner']}".
                "&banktype={$param['banktype']}".
                "&paymoney={$param['paymoney']}".
                "&ordernumber={$param['ordernumber']}".
                "&callbackurl={$param['callbackurl']}";

            $sign = md5($sign_str . $md5_key);

            $data['sign'] = $sign;

            $res = Helper::post($data,$this -> pay_url);

            $res = json_decode($res,true);

            if($res['success'] == 'true'){

                $result['code'] = Code::SUCCESS;
                $result['pay_url'] = $res['url'];
                $result['order_no'] = $order_no;
                $result['type'] = $key;
                return $result;
            }
        }
        return [];

    }
}