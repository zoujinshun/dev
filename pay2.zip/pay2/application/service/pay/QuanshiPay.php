<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/20
 * Time: 20:23
 */

namespace app\service\pay;


use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;
class QuanshiPay extends CommonService
{
    private $notify_url = '/notify/quanshipay';
    private $return_url = 'http://www.baidu.com';
    private $payment = ['2'=>['wap'=>21], '15'=>['wap'=>22],'3'=>['scan'=>15]];
    private $pay_url = 'http://159.138.21.255:8006/payp/interface/pay/payinit.php';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['siteid'] = $merch_no;
        $param['paymoney'] = $amount * 100;
        $param['goodsname'] = 'table';
        $param['client_ip'] = $this -> getIP();
        $param['thereport_url'] = $host . $this -> notify_url;
        $param['thejump_url'] = $this -> return_url;
        $param['nowinttime'] = time();
        $param['paytypeid'] = $this->payment[$paytype][$payment_type];
        $param['site_orderid'] = $order_no;

        Log::info($param);

        $sign_str = "{$param['siteid']}". "|{$param['paytypeid']}". "|{$param['site_orderid']}".
            "|{$param['paymoney']}". "|{$param['goodsname']}". "|{$param['client_ip']}".
            "|{$param['thereport_url']}". "|{$param['thejump_url']}". "|{$param['nowinttime']}|";

        $sign = sha1($sign_str . $key['md5_key']);

        $param['sha1key'] = $sign;

        $res = Helper::post($param,$this -> pay_url);

        $res = json_decode($res,true);

        if($res['code'] == 200){

            $result['code'] = Code::SUCCESS;
            if($key == 'wap'){
                $result['pay_url'] = $res['data']['payinfo'];
            }else{
                $result['pay_url'] = $res['data']['payimgurl'];
            }
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;
            return $result;
        }

        return [];

    }
}