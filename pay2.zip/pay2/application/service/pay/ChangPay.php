<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/16
 * Time: 14:09
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;
class ChangPay extends CommonService
{
    //长付
    private $notify_url = '/notify/changpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2'=>['wap'=>'WEIXIN_H5','scan'=>'WEIXIN_NATIVE'],
        '15'=>['wap'=>'ALIPAY_H5','scan'=>'ALIPAY_NATIVE'],
        '3'=>['scan'=>'union_scan']
    ];
    private $pay_url = 'http://3.113.98.255:8085/uniPayApi.action';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }
        $order_no = $this -> getOrderNo();
        $param['p0_Version'] = '1.0';
        $param['p1_MerchantNo'] = $merch_no;
        $param['p2_OrderNo'] = $order_no;
        $param['p3_Amount'] = strpos($amount,'.00') === false ? $amount . ".00" : $amount;
        $param['p4_Cur'] = 1;
        $param['p5_ProductName'] = 'table';
        $param['p6_ProductDesc'] = '100X100';
        $param['p7_Mp'] = 'mobile';
        $param['p8_ReturnUrl'] = $this -> return_url;
        $param['p9_NotifyUrl'] = $host . $this -> notify_url;
        $param['q1_FrpCode'] = $this->payment[$paytype][$payment_type];
        $param['q9_PayerIp'] = $this -> getIP();

        Log::info($param);

        ksort($param);

        $sign_str = '';

        foreach($param as $k => $value){
            $sign_str .= $value;
        }

        $sign = strtoupper(md5($sign_str . $key['md5_key']));

        $param['hmac'] = $sign;

        $res = Helper::post($param,$this->pay_url);

        $res = json_decode($res,true);

        if($res['ra_Code'] == '100'){

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $res['rc_Result'];
            $result['type'] = $payment_type;
            $result['order_no'] = $order_no;
            return $result;
        }

        return [];

    }
}