<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/27
 * Time: 10:33
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;
class BaiPay extends CommonService
{
    private $notify_url = '/notify/baipay';
    private $return_url = 'http://www.baidu.com';
    private $payment = ['2'=>['wap'=>'WXWAP','scan'=>'WEIXIN']];
    private $domain = "http://api.baihuizfapi.com/";
    private $pay_url = 'http://api.baihuizfapi.com/interface/chargebank.aspx';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['partner'] = $merch_no;
        $param['value'] = $amount;
        $param['callbackurl'] = $host . $this -> notify_url;
        $param['hrefbackurl'] = $this -> return_url;
        $param['type'] = $this->payment[$paytype][$payment_type];
        $param['orderid'] = $order_no;

        $sign_str = "partner={$param['partner']}".
            "&type={$param['type']}".
            "&orderid={$param['orderid']}".
            "&callbackurl={$param['callbackurl']}".
            $param['value'];

        $sign = md5($sign_str . $key['md5_key']);

        $param['sign'] = $sign;

        Log::info($param);

        $res = Helper::post($param,$this -> pay_url);

        Log::info($res);

        $url = Helper::getStr(' <a href="','">here</a>',$res);

        if(strpos($url,'Show_Err.aspx') !== false){
            return [];
        }else{
            if(strpos($url,'http')){
                $url = $this -> domain . $url;
            }
            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $url;
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;
            return $result;
        }

    }
}