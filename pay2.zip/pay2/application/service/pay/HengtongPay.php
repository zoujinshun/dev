<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/16
 * Time: 17:52
 */

namespace app\service\pay;

namespace app\service\pay;
use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;
class HengtongPay extends CommonService
{
    private $notify_url = '/notify/hengtongpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2'=>['wap'=>1002,'scan'=>1000],
        '3'=>['fast'=>0,'scan'=>1009],
        '12'=>['wap'=>1008,'scan'=>1007],
        '15'=>['wap'=>1004,'scan'=>1003],
    ];
    private $pay_url = 'https://gateway.htpays.com/GateWay/Index';
    private $fast_url = 'https://gateway.htpays.com/FastPay/Index';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username='')
    {

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this->getOrderNo();
        $param['customer'] = $merch_no;
        $param['amount'] = $amount;
        $param['asynbackurl'] = $host . $this->notify_url;
        $param['request_time'] = date('YmdHis',time());
        $param['orderid'] = $order_no;

        $sign_str = "customer={$param['customer']}";

        if($paytype == '3' && $payment_type == 'fast'){
            $pay_url = $this -> fast_url;
        }else{
            $pay_url = $this -> pay_url;
            $param['banktype'] = $this->payment[$paytype][$payment_type];
            $sign_str .= "&banktype={$param['banktype']}";
        }

        Log::info($param);
        $sign_str .= "&amount={$param['amount']}".
            "&orderid={$param['orderid']}".
            "&asynbackurl={$param['asynbackurl']}".
            "&request_time={$param['request_time']}".
            "&key={$key['md5_key']}";

        $sign = md5($sign_str);

        $param['sign'] = $sign;

        $res = Helper::post($param, $pay_url);

        if(strpos($res,'{"') !== false){
            $res = json_decode($res, true);
            if ($res['code'] == '0') {

                $result['code'] = Code::SUCCESS;
                $result['pay_url'] = $res['payURL'];
                $result['order_no'] = $order_no;
                $result['type'] = $key;
                return $result;
            }
        }else{
            if(strpos($res,"/FastPay/HandlePay") !== false){
                $res = str_replace('/FastPay/HandlePay',"https://gateway.htpays.com/FastPay/HandlePay",$res);
            }

            $dir = dirname(dirname(dirname(__DIR__))) . '/public/html/' . $order_no . '.html';
            $pay_url = $host. '/html/' . $order_no . '.html';
            file_put_contents($dir,$res);
            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $pay_url;
            $result['order_no'] = $order_no;
            $result['type'] = $key;
            return $result;

        }

        return [];
    }
}