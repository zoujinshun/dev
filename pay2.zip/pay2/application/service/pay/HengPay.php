<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/9
 * Time: 16:47
 */

namespace app\service\pay;
use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;

class HengPay extends CommonService
{
    private $notify_url = '/notify/hengpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = ['2' => ['wap'=>'80001','scan'=>'60001'], '15' => ['wap'=>'80002','scan'=>'60002']];
    private $pay_url = 'http://api.kuaile8899.com:8088/pay/apply.shtml';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['appID'] = $merch_no;
        $param['randomNo'] = rand(100000,999999);
        $param['totalAmount'] = $amount * 100;
        $param['productTitle'] = 'cup';
        $param['notifyUrl'] = $host . $this->notify_url;
        $param['tradeIP'] = $this -> getIP();
        $param['tradeCode'] = $this->payment[$paytype][$payment_type];
        $param['outTradeNo'] = $order_no;

         Log::info($param);
        ksort($param);

        $sign_str = Helper::getPaySignature($param,true,false,'|');

        $sign = strtoupper(md5($sign_str."|".$key['md5_key']));

        $param['sign'] = $sign;

        $data_str = urldecode(json_encode($param,320));

        $post_data = ['ApplyParams'=>$data_str];

        $res = Helper::post($post_data,$this -> pay_url);

        $res = json_decode($res,true);

        if($res['stateCode'] == '0000' && strlen($res['payURL']) > 10){

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $res['payURL'];
            $result['order_no'] = $order_no;
            $result['type'] = $key;
            return $result;
        }

        return [];

    }
}