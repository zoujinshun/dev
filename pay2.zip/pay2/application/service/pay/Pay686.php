<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/2
 * Time: 21:00
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Config;

class Pay686 extends CommonService
{
    private $notify_url = '/notify/pay686';
    private $return_url = 'http://www.baidu.com';
    private $payment = ['15'=>['wap'=>'alipay','scan'=>'aliqr']];
    private $pay_url = 'http://120.77.165.254/index.php/686cz/trade/pay';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['notifyUrl'] = $host . $this -> notify_url;
        $param['goodsClauses'] = 'cup';
        $param['tradeAmount'] = $amount;
        $param['code'] = $merch_no;
        $param['payCode'] = $this->payment[$paytype][$payment_type];
        $param['outOrderNo'] = $order_no;

        ksort($param);

        $sign_str = urldecode(http_build_query($param));

        $sign = md5($sign_str .'&key='. $key['md5_key']);

        $param['sign'] = $sign;

        $res = Helper::post($param,$this -> pay_url);

        $res = json_decode($res,true);

        if($res['payState'] == 'fail'){
            return [];
        }

        if($res['payState'] == 'success'){

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $res['url'];
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;
            return $result;
        }

        return [];

    }
}