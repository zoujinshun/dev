<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/22
 * Time: 14:46
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;

class HowmuchPay extends CommonService
{
    private $notify_url = '/notify/howmuchpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2'=>['scan'=>1],
        '3'=>['scan'=>5],
        '15'=>['wap'=>6,'scan'=>2],
    ];

    private $pay_url = 'http://47.56.189.243:39802/createorder';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['pay_memberid'] = $merch_no;
        $param['pay_orderid'] = $order_no;
        $param['price'] = $amount;
        $param['addtime'] = time();
        $param['class'] = $this->payment[$paytype][$payment_type];
        $param['pay_notifyurl'] = $host . $this -> notify_url;
        $param['pay_callbackurl'] = $this -> return_url;

        Log::info($param);

        ksort($param);

        $sign_str = urldecode(http_build_query($param));

        $sign = strtoupper(md5($sign_str."&key=".$key['md5_key']));

        $param['md5sign'] = $sign;

        $res = Helper::post($param,$this -> pay_url);

        $res = json_decode($res,true);

        if($res['status'] == 'success'){

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = urldecode($res['data']['pay_url']);
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;
            return $result;
        }
        return [];

    }


}