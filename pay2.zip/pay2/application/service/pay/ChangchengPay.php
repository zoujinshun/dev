<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/17
 * Time: 17:09
 */

namespace app\service\pay;


use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;

class ChangchengPay extends CommonService
{
    private $notify_url = '/notify/changchengpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = ['2'=>['wap'=>1], '15'=>['wap'=>13]];
    private $pay_url = 'http://www.changchengpay88.com/pay/json';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['uid'] = $merch_no;
        $param['price'] = strpos($amount,'.') !== false ? $amount : $amount . ".00";
        $param['paytype'] = $this->payment[$paytype][$payment_type];
        $param['notify_url'] = $host . $this -> notify_url;
        $param['return_url'] = $this -> return_url;
        $param['user_order_no'] = $order_no;
        $param['tm'] = date('Y-m-d H:i:s',time());
        $param['token'] = $key['md5_key'];

        Log::info($param);

        ksort($param);

        $sign_str = $param['uid'] . $param['price'] .
            $param['paytype'] . $param['notify_url'] .
            $param['return_url'] . $param['user_order_no'];

        $sign = md5($sign_str.$key['md5_key']);

        $param['sign'] = $sign;

        $res = Helper::post(json_encode($param,320),$this -> pay_url,['content-type:application/json;charset=utf-8']);

        $res = json_decode($res,true);

        if($res['Code'] == 1){
            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $res['QRCodeLink'];
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;
        }

        return [];

    }
}