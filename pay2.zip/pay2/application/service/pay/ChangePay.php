<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/16
 * Time: 14:09
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;
class ChangePay extends CommonService
{
    //畅付
    private $notify_url = '/notify/changepay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2'=>['wap'=>'wx_wap','scan'=>'wx_scan'],
        '15'=>['wap'=>'ali_wap','scan'=>'ali_scan'],
        '3'=>['scan'=>'union_scan']
    ];
    private $pay_url = 'https://y-sdk.ixwyti.com';
    private $wx_wap = '/api/v1/wx_h5.api';
    private $wx_scan = '/api/v1/wx_qrcode.api';
    private $ali_scan = '/api/v1/ali_qrcode.api';
    private $ali_wap = '/api/v1/ali_h5.api';
    private $union_scan = '/api/v1/yunsf.api';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }
        $order_no = $this -> getOrderNo();
        $param['sign_type'] = 'md5';
        $param['mch_id'] = $merch_no;
        $param['amt'] = $amount * 1000;
        $param['remark'] = 'cup';
        $param['created_at'] = time();
        $param['client_ip'] = Helper::getIP();
        $param['notify_url'] = $host . $this -> notify_url;
        $param['device'] = 'mobile';
        $param['mch_key'] = $key['md5_key'];
        $param['mch_order'] = $order_no;

        Log::info($param);

        ksort($param);

        $sign_str = urldecode(http_build_query($param));

        $sign = md5($sign_str);

        $param['sign'] = $sign;

        unset($param['mch_key']);

        $payment = $this->payment[$paytype][$payment_type];

        $pay_url = $this -> pay_url . $this -> $payment;

        $res = Helper::post($param,$pay_url);

        $res = json_decode($res,true);

        if($res['code'] == '1'){

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $res['data']['jump_url'];
            $result['type'] = $payment_type;
            $result['order_no'] = $order_no;
            return $result;
        }

        return [];

    }
}