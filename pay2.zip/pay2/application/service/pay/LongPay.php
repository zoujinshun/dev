<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/2
 * Time: 21:00
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Config;

class LongPay extends CommonService
{
    private $notify_url = '/notify/longpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '15' => ['wap' => 'ZFB_WAP', 'scan' => 'ZFB'],
        '2' => ['wap' => 'WX_WAP', 'scan' => 'WX']
    ];
    private $pay_url = 'http://pay.longfapay.com:88/api/pay';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username='')
    {

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this->getOrderNo();
        $param['merchNo'] = $merch_no;
        $param['randomNo'] = (string)rand(111111, 999999);
        $param['amount'] = (string)($amount * 100);
        $param['goodsName'] = 'cup';
        $param['notifyUrl'] = $host . $this->notify_url;
        $param['notifyViewUrl'] = $this->return_url;
        $param['netwayType'] = $this->payment[$paytype][$payment_type];
        $param['orderNo'] = $order_no;

        ksort($param);

        $sign_str = urldecode(json_encode($param, 320));

        $sign = strtoupper(md5($sign_str . $key['md5_key']));

        $param['sign'] = $sign;

        $json = json_encode($param, 320);

        $encrypt_data = Helper::pub_encrypt($json, Helper::handleKey($key['public_key'],'public'));

        if (!$encrypt_data) {
            return [];
        }

        $params = [
            'data' => $encrypt_data,
            'merchNo' => $merch_no,
            'version' => 'v3.6.0.0'
        ];

        $res = Helper::post($params, $this->pay_url);

        $res = json_decode($res, true);

        if ($res['stateCode'] == '00') {

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $res['qrcodeUrl'];
            $result['order_no'] = $order_no;
            $result['type'] = $key;
            return $result;
        }

        return [];

    }
}