<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/20
 * Time: 14:51
 */

namespace app\service\pay;


use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;

class WangPay extends CommonService
{
    private $notify_url = '/notify/wangpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2'=>['wap'=>'wxwap','scan'=>'wxcode'],
        '15'=>['wap'=>'alipaywap','scan'=>'alipay'],
        '3' => ['quick'=>'OnLineKJ','wap'=>'shortcutwap','scan'=>'unionpay'],
        '8' => ['wap'=>'qqpaywap'],
        '14' => ['scan'=>'qqpay'],
        '12' => ['wap'=>'jdwap ','scan'=>'jdpay'],
        '11' => ['wap'=>'bdpaywap','scan'=>'bdpay']
    ];
    private $pay_url = 'http://tmall.tmalloppo.com/GateWay/ReceiveBank.aspx';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['p0_Cmd'] = "Buy";
        $param['p1_MerId'] = $merch_no;
        $param['p3_Amt'] = strpos($amount,".") === false ? $amount . ".00" : $amount;
        $param['p4_Cur'] = 'CNY';
        $param['p5_Pid'] = 'cup';
        $param['p6_Pcat'] = 'life kind';
        $param['p7_Pdesc'] = 'life kind';
        $param['p8_Url'] = $host . $this -> notify_url;
        $param['p9_SAF'] = 0;
        $param['pa_MP'] = '';
        $param['pr_NeedResponse'] = 1;
        $param['p2_Order'] = $order_no;
        $param['pd_FrpId'] = $this->payment[$paytype][$payment_type];

        ksort($param);

        $sign_str = '';

        foreach($param as $item){
            if($item == null){
                $sign_str .= '';
            }else{
                $sign_str .= $item;
            }
        }

        $md5_key = iconv("GB2312","UTF-8",$key['md5_key']);
        $sign_str = iconv("GB2312","UTF-8",$sign_str);

        $b = 64; // byte length for md5
        if (strlen($md5_key) > $b) {
            $md5_key = pack("H*",md5($md5_key));
        }
        $md5_key = str_pad($md5_key, $b, chr(0x00));
        $ipad = str_pad('', $b, chr(0x36));
        $opad = str_pad('', $b, chr(0x5c));
        $k_ipad = $md5_key ^ $ipad ;
        $k_opad = $md5_key ^ $opad;

        $sign = md5($k_opad . pack("H*",md5($k_ipad . $sign_str)));

        $data['hmac'] = $sign;

        $res = Helper::post($data,$this -> pay_url);

        $res = iconv("GB2312","UTF-8",$res);

        $res = json_decode($res,true);

        if($res['success'] == 'true'){

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $res['url'];
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;
            return $result;
        }

        return [];

    }
}