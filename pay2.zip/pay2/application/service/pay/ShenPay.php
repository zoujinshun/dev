<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/17
 * Time: 10:48
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;
class ShenPay extends CommonService
{
    private $notify_url = '/notify/shengpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2'=>['scan'=>'weixin_scan','wap'=>'h5_wx'],
        '15'=>['scan'=>'alipay_scan','wap'=>'h5_ali']
    ];
    private $pay_url = 'https://api.shenfu888.com/gateway/api/scanpay';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['merchant_code'] = $merch_no;
        $param['notify_url'] = $host . $this -> notify_url;
        $param['client_ip'] = '127.0.0.1';//$this -> getIP();
        $param['order_time'] = date('Y-m-d H:i:s');
        $param['order_amount'] = strpos($amount,'.') === false ? ($amount . '.00') : $amount;
        $param['product_name'] = 'cup';
        $param['interface_version'] = 'V3.1';
        $param['service_type'] = $this->payment[$paytype][$payment_type];
        $param['order_no'] = $order_no;

        if($key == 'wap'){
            $param['interface_version'] = 'V3.0';
        }

        ksort($param);

        $sign_str = urldecode(http_build_query($param));

        $sign = Helper::sign($sign_str,$key['private_key'],"RSA",'base64',OPENSSL_ALGO_MD5);

        $param['sign'] = $sign;

        $param['sign_type'] = "RSA-S";

        $res = Helper::post($param,$this -> pay_url);

        $res = json_decode(json_encode(simplexml_load_string($res, 'SimpleXMLElement', LIBXML_NOCDATA)), true);

        if($res['response']['resp_code'] == 'SUCCESS' && $res['response']['result_code'] == 0){

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = rawurldecode($res['response']['qrcode']);
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;

            return $result;
        }

        return [];

    }
}