<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/19
 * Time: 11:52
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;

class ChengyitongPay extends CommonService
{
    private $notify_url = '/notify/chengyitongpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2'=>['wap'=>'wx_h5_scan','scan'=>'wx_h5_scan'],
        '15'=>['wap'=>'ali_h5_scan','scan'=>'ali_h5_scan']
    ];
    private $pay_url = 'http://gate.chengyitpay.com/api/pay/v2';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['p1_mchtid'] = $merch_no;
        $param['p2_paytype'] = $this->payment[$paytype][$payment_type];
        $param['p3_paymoney'] = $amount;
        $param['p4_orderno'] = $order_no;
        $param['p5_callbackurl'] = $host . $this -> notify_url;
        $param['p6_notifyurl'] = $host . $this -> notify_url;
        $param['p7_version'] = 'v2.9';
        $param['p8_signtype'] = 2;
        $param['p9_attach'] = '';
        $param['p10_appname'] = '';
        $param['p11_isshow'] = 0;
        $param['p12_orderip'] = '192.168.10.1';
        $param['p13_memberid'] = md5($username);

        ksort($param);

        $sign_str = urldecode(http_build_query($param));

        $sign = md5($sign_str.$key['md5_key']);

        $param['sign'] = $sign;

        $data = Helper::pub_encrypt(json_encode($param),$key['public_key']);

        $post_data = ['mchtid'=>$merch_no,'reqdata'=>$data];

        $res = Helper::post($post_data,$this -> pay_url);

        $res = json_decode($res, true);

        if($res['rspCode'] == 1){

            $pay_data = Helper::pri_decrypt($res['data'],$key['private_key']);

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = rawurldecode($pay_data['r6_qrcode']);
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;

            return $result;
        }

        return [];

    }
}