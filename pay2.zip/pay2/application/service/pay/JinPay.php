<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/9
 * Time: 19:37
 */

namespace app\service\pay;


use app\service\CommonService;
use common\Code;
use common\Helper;
use common\Keys;
use think\facade\Config;

class JinPay extends CommonService
{
    private $config = [];

    public function __construct()
    {
        parent::__construct();
        $this -> config = Config::get('pay.JinPay');
    }

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        $param['version'] = '1.0';
        $param['mer_id'] = $merch_no;
        $param['order_id'] = $order_no;
        $param['price'] = $amount * 100;
        $param['notify_url'] = $this->config['return_url'];
        $param['return_url'] = $host .  $this->config['notify_url'];
        $param['randomid'] = rand(100000,999999);

        if(!isset($this->config['payment'][$paytype])){
            return [];
        }

        foreach($this->config['payment'][$paytype] as $key=>$value){

            $param['pay_type'] = $value;

            $data = $param;

            ksort($data);

            $sign_str = "version={$data['version']}".
                "&mer_id={$data['mer_id']}".
                "&order_id={$data['order_id']}".
                "&price={$data['price']}".
                "&notify_url={$data['notify_url']}".
                "&pay_type={$data['pay_type']}".
                "&randomid={$data['randomid']}";

            $sign = md5($sign_str."&key=".$md5_key);

            $data['sign'] = $sign;

            if($paytype == '2'){
                $pay_url = $this -> config['wx_url'];
            }else if($paytype == '15'){
                $pay_url = $this -> config['ali_url'];
            }else{
                $pay_url = $this -> config['pay_url'];
            }

            $res = Helper::post($data,$pay_url);

            $res = json_decode($res,true);

            if($res['retCode'] == 'SUCCESS'){
//                $payment_key = keys::getPaymentKey($pay_id,$agent_id);
//                $this -> redis -> expire($payment_key,0);
                $method = $res['payParams']['payMethod'];
                if($method == 'formJump'){
                    $html = $res['payParams']['payUrl'];
                    $dir = dirname(dirname(dirname(__DIR__))) . '/public/html/' . $order_no . '.html';
                    $host = 'http://' . request() -> host() . (request() -> port() == '80' ? '' : ':'. request() -> port());
                    $pay_url = $host . '/html/' . $order_no . '.html';
                    file_put_contents($dir,$html);
                    $result['code'] = Code::SUCCESS;
                    $result['pay_url'] = $pay_url;
                    $result['type'] = $key;
                }else{
                    $result['code'] = Code::SUCCESS;
                    $result['pay_url'] = $res['payParams']['codeUrl'];
                    $result['type'] = $key;
                }
                return $result;
            }
        }
        return [];

    }
}