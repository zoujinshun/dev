<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/9
 * Time: 16:47
 */

namespace app\service\pay;
use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;

class XxyunPay extends CommonService
{
    private $notify_url = '/notify/xxyunpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2' => ['wap'=>'80001','scan'=>'60001'],
        '15' => ['wap'=>'80002','scan'=>'60002']
    ];
    private $pay_url = 'https://xxxxyun.com/pay/submitOrder';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['mch_id'] = $merch_no;
        $param['pay_type'] = $this->payment[$paytype][$payment_type];
        $param['money'] = $amount * 100;
        $param['time'] = time();
        $param['order_id'] = $order_no;
        $param['return_url'] = $this -> return_url;
        $param['notify_url'] = $host . $this -> notify_url;
        $param['commodity_name'] = 'desk table';
        $param['extra'] = $this -> getStr();
        $param['client_ip'] = '192.168.1.10';

        Log::info($param);

        $sign_str = urldecode(http_build_query($param));

        $sign = strtoupper(md5($sign_str."&key=".$key['md5_key']));

        $param['sign'] = $sign;

        $param['sign_type'] = '1';

        $res = Helper::post($param,$this -> pay_url);

        if(strpos($res,'{"') !== false){

            $res = json_decode($res,true);

            if($res['code'] == 200){

                $result['code'] = Code::SUCCESS;
                $result['order_no'] = $order_no;
                $result['pay_url'] = $res['data'];
                $result['type'] = $key;
                return $result;
            }
        }else{
            $dir = dirname(dirname(dirname(__DIR__))) . '/public/html/' . $order_no . '.html';
            $pay_url = $host. '/html/' . $order_no . '.html';
            file_put_contents($dir,$res);
            $result['code'] = Code::SUCCESS;
            $result['order_no'] = $order_no;
            $result['pay_url'] = $pay_url;
            $result['type'] = $key;
            return $result;
        }

        return [];

    }
}