<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/20
 * Time: 16:29
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
class Caipay extends CommonService
{
    private $notify_url = '/notify/caipay';
    private $return_url = 'http://www.baidu.com';
    private $payment = ['15'=>['wap'=>'aliBankCardQrCode','scan'=>'aliAccountQrCode']];
    private $pay_url = 'http://api.caimengpay.com/api/payOrder/prepay';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $time = substr($order_no,0,strlen($order_no) - 6);

        $param['orderIp'] = '127.0.0.1';
        $param['amount'] = $amount;
        $param['businessType'] = 1;
        $param['notifyUrl'] = $host . $this -> notify_url;
        $param['expireTime'] = 10;
        $param['bankCode'] = 'SPABANK';
        $param['submitTime'] = $time;
        $param['payType'] = $this->payment[$paytype][$payment_type];
        $param['merOrderNo'] = $order_no;

        ksort($param);

        $sign_str = urldecode(http_build_query($param));

        $sign = strtoupper(md5($sign_str . "&key=" . $key['md5_key']));

        $param['sign'] = $sign;

        $param['remarks'] = 'cup';

        $param['returnViewUrl'] = $this -> return_url;

        $data = Helper::pub_encrypt(json_encode($param,320),Helper::handleKey($key['public_key'],'public'));

        if(!$data){
            return [];
        }

        $post_data = ['merId'=>$merch_no,'version'=>'1.1','data'=>$data];

        $res = Helper::post(json_encode($post_data,320),$this -> pay_url,['Content-Type: application/json;']);

        $res = json_decode($res,true);

        if($res['code'] == '200'){

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = rawurldecode($res['data']['payUrl']);
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;

            return $result;
        }

        return [];

    }
}