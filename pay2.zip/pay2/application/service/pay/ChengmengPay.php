<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/20
 * Time: 21:27
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;
class ChengmengPay extends CommonService
{
    private $notify_url = '/notify/chengmengpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2'=>['wap'=>'1007','scan'=>'1004'],
        '15'=>['wap'=>'1006','scan'=>'992']
    ];
    private $pay_url = 'http://www.ec389.com/Bank/index.aspx';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['parter'] = $merch_no;
        $param['value'] = strpos($amount,'.') !== false ? $amount : $amount . ".00";
        $param['callbackurl'] = $host . $this -> notify_url;
        $param['type'] = $this->payment[$paytype][$payment_type];
        $param['orderid'] = $order_no;

        Log::info($param);
        $sign_str = "parter={$param['parter']}".
            "&type={$param['type']}".
            "&value={$param['value']}".
            "&orderid={$param['orderid']}".
            "&callbackurl={$param['callbackurl']}";

        $sign = md5($sign_str . $key['md5_key']);

        $param['sign'] = $sign;

        $dir = dirname(dirname(dirname(__DIR__))) . '/public/html/' . $order_no . '.html';
        $pay_url = $host. '/html/' . $order_no . '.html';

        if($payment_type == 'scan'){
            $res = Helper::post($param,$this -> pay_url);
            if(strpos($res,"error") !== false){
                return [];
            }
            file_put_contents($dir,$res);
        }else{
            $html = '<form name="form_submit" action="' . $this -> pay_url . '" method="post">';

            foreach ($param as $k => $v) {
                $html .= '<input type="hidden" name="'. $k.'" value="'.$v.'"/>';
            }
            $html .= "</form><script> document.forms[0].submit(); </script>";
            file_put_contents($dir,$html);
        }

        $result['code'] = Code::SUCCESS;
        $result['pay_url'] = $pay_url;
        $result['order_no'] = $order_no;
        $result['type'] = $payment_type;
        return $result;
    }
}