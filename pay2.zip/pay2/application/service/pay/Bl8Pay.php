<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/22
 * Time: 14:46
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;

class Bl8Pay extends CommonService
{
    private $notify_url = '/notify/bl8pay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2'=>['wap'=>'wechat'],
        '15'=>['wap'=>'alipay'],
    ];
    private $pay_url = 'http://api.kt2019.cn/bugaapi/index/unifiedorder?format=json';
    private $domain = 'http://api.kt2019.cn';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['appid'] = $merch_no;
        $param['pay_type'] = $this->payment[$paytype][$payment_type];
        $param['amount'] = $amount;
        $param['callback_url'] = $host . $this -> notify_url;
        $param['success_url'] = $this->return_url;
        $param['error_url'] = $this->return_url;
        $param['out_uid'] = $this -> getStr();
        $param['out_trade_no'] = $order_no;
        $param['version'] = 'v1.0';

        Log::info($param);
        ksort($param);

        $sign_str = $this -> getSignature($param,true,true);

        $sign = md5($sign_str."&key=".$key['md5_key']);

        $param['sign'] = $sign;

        $res = Helper::post(json_encode($param,320),$this -> pay_url);

        $res = json_decode($res,true);

        if($res['code'] == '200'){

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $this -> domain . $res['url'];
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;
            return $result;
        }
        return [];

    }


}