<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/26
 * Time: 10:57
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;

class ApplePay extends CommonService
{

    private $notify_url = '/notify/applepay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
            '2'=>['wap'=>'wxwap','scan'=>'wxqrcode'],
            '15'=>['wap'=>'wap','scan'=>'qrcode'],
        ];
    private $pay_url = 'http://api.aapay2019.com/api/addOrder';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $param['aa_merchant'] = $merch_no;
        $param['aa_amount'] = $amount * 100;
        $param['aa_order_time'] = time();
        $param['aa_subject'] = 'cup';
        $param['aa_notify_url'] = $host . $this -> notify_url;
        $param['aa_pay_type'] = $this->payment[$paytype][$payment_type];
        $param['aa_order_no'] = $this -> getOrderNo();

        Log::info($param);

        ksort($param);

        $sign_str = urldecode(http_build_query($param));

        $sign = sha1($sign_str .'&key='. $key['md5_key']);

        $param['sign'] = $sign;

        $res = Helper::post($param,$this -> pay_url);

        Log::info($res);

        $res = json_decode($res,true);

        if($res['code'] == '0000'){

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $res['result']['qrCode'];
            $result['type'] = $payment_type;
            $result['order_no'] = $param['aa_order_no'];
            return $result;
        }

        return [];

    }
}