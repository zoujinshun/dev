<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/22
 * Time: 14:46
 */

namespace app\service\pay;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;

class JmoneyPay extends CommonService
{
    private $notify_url = '/notify/jmoneypay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2'=>['scan'=>1],
        '3'=>['scan'=>5],
        '15'=>['wap'=>6,'scan'=>2],
    ];

    private $pay_url = 'http://api.jmoney.vip/gateway/order/create';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['merchant_no'] = $merch_no;
        $param['return_type'] = 'json';
        $param['type'] = $this->payment[$paytype][$payment_type];
        $param['amount'] = $amount;
        $param['merchant_order_no'] = $order_no;
        $param['remark'] = 'pay';
        $param['return_url'] = $this -> return_url;
        $param['notify_url'] = $host . $this -> notify_url;
        $param['device'] = 'mobile';

        Log::info($param);

        ksort($param);

        $sign_str = urldecode(http_build_query($param));

        $sign = strtoupper(md5($sign_str."&key=".$key['md5_key']));

        $param['sign'] = $sign;

        $res = Helper::post($param,$this -> pay_url);

        $res = json_decode($res,true);

        if($res['code'] == '0'){

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = urldecode($res['data']['pay_url']);
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;
            return $result;
        }
        return [];

    }


}