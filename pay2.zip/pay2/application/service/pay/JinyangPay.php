<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/3
 * Time: 16:37
 */

namespace app\service\pay;


use app\service\CommonService;
use common\Code;
use common\Helper;
use common\Keys;
use think\facade\Config;
class JinYangPay extends CommonService
{
    private $notify_url = '/notify/jinyangpay';
    private $return_url = 'http://www.baidu.com';
    private $payment = [
        '2'=>['wap'=>'wxPayH5 ','scan'=>'wxPaySM'],
        '3' => ['quick'=>'unionPayKJ','scan'=>'unionPaySM'],
        '12' => ['scan' => 'jdPaySM'],
        '15'=>['wap'=>'aliPayH5','scan'=>'aliPaySM'],
    ];
    private $pay_url = 'http://pay.095pay.com/zfapi/order/pay';

    public function pay($paytype,$amount,$merch_no,$key,$host,$payment_type,$username=''){

        if(!isset($this->payment[$paytype]) || !isset($this->payment[$paytype][$payment_type])){
            return [];
        }

        $order_no = $this -> getOrderNo();
        $param['p1_mchtid'] = $merch_no;
        $param['p2_paytype'] = $this->payment[$paytype][$payment_type];
        $param['p3_paymoney'] = strpos($amount,'.') !== false ? $amount : $amount . '.00';
        $param['p4_orderno'] = $order_no;
        $param['p5_callbackurl'] = $host . $this -> notify_url;
        $param['p6_notifyurl'] = $this -> return_url;
        $param['p7_version'] = 'V2.8';
        $param['p8_signtype'] = 1;
        $param['p9_attach'] = '';
        $param['p10_appname'] = '';
        $param['p11_isshow'] = 0;
        $param['p12_orderip'] = '192.168.10.1';
        $param['p13_memberid'] = $this -> getStr();

        ksort($param);

        $sign_str = urldecode(http_build_query($param));

        $sign = md5($sign_str.$key['md5_key']);

        $param['sign'] = $sign;

        $res = Helper::post($param,$this -> pay_url,['content-type:application/x-www-form-urlencoded']);

        $res = json_decode($res,true);

        if($res['rspCode'] == 1){

            $result['code'] = Code::SUCCESS;
            $result['pay_url'] = $res['data']['r6_qrcode'];
            $result['order_no'] = $order_no;
            $result['type'] = $payment_type;
            return $result;
        }

        return [];

    }
}