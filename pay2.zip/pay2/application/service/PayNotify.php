<?php


namespace app\service;


use app\library\facade\model\{Order, MerchAgentSetting, Players};
use common\Keys;
use app\library\facade\grpc\{Pay};
use Grpc_proto\Common_Data\{PayStatus};

class PayNotify extends CommonService
{

    const OPT_TYPE_DEPOSIT_MCH1_WX = 117;//通过商户的wx充值渠道,demo 2
    const OPT_TYPE_DEPOSIT_MCH1_ALI = 118;//通过商户的支付宝充值渠道,demo 15
    const OPT_TYPE_DEPOSIT_MCH1_BANK = 119;//通过商户的网银充值渠道,demo 4
    const OPT_TYPE_DEPOSIT_MCH1_QQ = 120;//通过商户的QQ充值渠道,demo 8
    const OPT_TYPE_DEPOSIT_MCH1_BAIDU_BAG = 121;//通过商户的百度支付充值渠道,demo 11
    const OPT_TYPE_DEPOSIT_MCH1_JD_PAY = 122;//通过商户的京东支付充值渠道,demo 12
    const OPT_TYPE_DEPOSIT_MCH1_UNION = 123;//通过商户的银联支付充值渠道,demo 3
    const OPT_TYPE_DEPOSIT_MCH1_DK = 125;//通过商户的点卡充值支付充值渠道,demo 10
    const OPT_TYPE_DEPOSIT_MCH1_OTHER_SCAN = 126;//通过商户的其他充值支付充值渠道,demo

    public function getOrder($order_no){

        $order = Pay::getOrder($order_no);

        return $order;

    }

    public function getOrderByUsername($username){
        $order = Pay::getOrders($username,[PayStatus::PAY_STATUS_SUCCESS,PayStatus::PAY_STATUS_FORCE],0,1);
        return $order;
    }

    public function findMerch($merch_agent_id){

        $payment = MerchAgentSetting::findMerch($merch_agent_id,'md5_key,private_key,public_key,merch_no');

        return $payment;
    }

    public function getOptType($payment_id){
        switch($payment_id){
            case '2' :
                return self::OPT_TYPE_DEPOSIT_MCH1_WX;
            case '4':
                return self::OPT_TYPE_DEPOSIT_MCH1_BANK;
            case '15':
                return self::OPT_TYPE_DEPOSIT_MCH1_ALI;
            case '8':
                return self::OPT_TYPE_DEPOSIT_MCH1_QQ;
            case '11':
                return self::OPT_TYPE_DEPOSIT_MCH1_BAIDU_BAG;
            case '12':
                return self::OPT_TYPE_DEPOSIT_MCH1_JD_PAY;
            case '3':
                return self::OPT_TYPE_DEPOSIT_MCH1_UNION;
            case '10':
                return self::OPT_TYPE_DEPOSIT_MCH1_DK;
            default:
                return self::OPT_TYPE_DEPOSIT_MCH1_OTHER_SCAN;
        }
    }

    public function changeOrderStatus($order_info){

        $order_data['order_status'] = 1;
        $order_data['pay_status'] = 1;
        $order_data['out_trade_no'] = $order_info['out_trade_no'];
        $order_data['real_amount'] = $order_info['amount'];
        $order_data['payed_amount'] = $order_info['amount'] + (float)$order_info['deduce_amount'];
        $order_data['notify_time'] = time();
        $order_data['payline_id'] = $order_info['payline_id'];

        $isFitstOrder = 0;
        $order_success = $this -> getOrderByUsername($order_info['username']);

        if(!empty($order_success)){
            $isFitstOrder = 1;
        }
        $order_data['is_first_order'] = $isFitstOrder;

        if(isset($order_info['remark']) && $order_info['remark'] != ''){
            $remark = json_decode($order_info,true);
            $front_remark = $remark['front_remark'] ?? '';
            $remark = $remark['remark'] ?? '';
        }

        $audit_data['platform_type'] = $order_info['platform_type'];
        $audit_data['username'] = $order_info['username'];
        $audit_data['withdraw_order'] = '';
        $audit_data['order_no'] = $order_info['order_no'];
        $audit_data['opt_type'] = $this -> getOptType($order_info['payment_id']);
        $audit_data['payed_amount'] = $order_info['amount'] + $order_info['deduce_amount'];
        $audit_data['real_amount'] = $order_info['amount'];
        $audit_data['deduce_amount'] = $order_info['deduce_amount'];
        $audit_data['valid_bet'] = 0;
        $audit_data['deduce_bet'] = $order_info['deduce_bet'];
        $audit_data['config_valid_bet'] = $order_info['config_valid_bet'];
        $audit_data['normal_status'] = 1;
        $audit_data['deduce_status'] = 1;
        $audit_data['normal_fee'] = 0;
        $audit_data['deduce_fee'] = 0;
        $audit_data['balance'] = 0;
        $audit_data['remaining'] = 0;
        $audit_data['start_time'] = time();
        $audit_data['end_time'] = 0;
        $audit_data['create_time'] = time();
        $audit_data['remark'] = $remark ?? '';
        $audit_data['front_remark'] = $front_remark ?? '';
        $audit_data['audit_status'] = 1;

        $res = Pay::updateOrder($order_info['order_no'],$order_data,$audit_data);

        return $res;
    }

    public function changeLimitAmount($order){

        $limit_key = keys::getLimitMoneyKey($order['payment_id'],$order['merch_agent_id'],$order['channel_type'],$order['platform_type']);
        $limits = $this -> redis -> hgetall($limit_key);
        $date = date('Ymd');
        if(!$limits){
            $this -> redis -> hset($limit_key,'limit',json_encode([$date=>$order['amount']]));
            $this -> redis -> hset($limit_key,'total_limit',$amount);
        }else{
            $today_limit = json_decode($limits['limit'],true);
            if(!isset($today_limit[$date])){
                $today_limit[$date] = $order['amount'];
            }else{
                $today_limit[$date] += $order['amount'];
            }
            $this -> redis -> hset($limit_key,'limit',json_encode($today_limit));
            $total_limit = $limits['total_limit'] + $order['amount'];
            $this -> redis -> hset($limit_key,'total_limit',$total_limit);
        }
    }

}