<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/21
 * Time: 11:30
 */

namespace app\service;

use app\library\facade\model\{WithdrawOrder,FinanceSetting,MerchAgentSetting,Players};
class Withdraw
{
    public function getOrderinfo($order_no,$agent_id,$username,$merch_agent_id){

        $user = Players::findUserByUsername($username,'username,platform_id,platform_type,level_setting_id,game_gold');

        if(empty($user)){
            return [];
        }

        $finance_setting = FinanceSetting::findFinanceSetting($user['level_setting_id'],$agent_id,'withdraw_free_num,withdraw_fix_money');

        $field = "order_no,username,order_type,card_no,card_user,card_bank,card_sub_bank,money,administrative_fee,discount_fee,real_money,status,remark,operator";

        $order = WithdrawOrder::findOrder(['order_no'=>$order_no,'agent_id'=>$agent_id,'username'=>$username],$field);

        if(empty($order) || $order['status'] != 5){
            return [];
        }

        $param_withdraw['agent_id'] = $agent_id;
        $param_withdraw['username'] = $username;
        $param_withdraw['create_start_time'] = date('Y-m-d 00:00:00');
        $param_withdraw['create_end_time'] = date('Y-m-d 23:59:59');
        $param_withdraw['status'] = [2,3];

        $withdraw_count = WithdrawOrder::getOrderCount($param_withdraw);

        if($withdraw_count > $finance_setting['withdraw_free_num']){
            $order['fee'] = $finance_setting['withdraw_fix_money'];
        }else{
            $order['fee'] = 0;
        }

        $order['real_money'] = $order['money'] - $order['administrative_fee'] - $order['discount_fee'] - $order['fee'];

        return $order;

    }

    public function getMerchInfo($merch_agent_id,$agent_id){

        $field = 'agent_id,merch_code,md5_key,private_key,public_key,merch_no';

        $merch = MerchAgentSetting::findMerch($merch_agent_id,$field);

        if(empty($merch) || $merch['agent_id'] != $agent_id){
            return [];
        }

        return $merch;
    }

    public function updateWithdraw($order_no,$data){

        $res = WithdrawOrder::updatesOrder(['order_no'=>$order_no],$data);

        return $res;
    }
}