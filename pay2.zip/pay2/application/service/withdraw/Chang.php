<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/21
 * Time: 14:56
 */

namespace app\service\withdraw;

use app\service\CommonService;
use common\Code;
use common\Helper;
use think\facade\Log;
class Chang extends CommonService
{
    private $notify_url = '/withdraw/chang';
    private $return_url = 'http://www.baidu.com';
    private $withdraw_url = 'http://webapi.gaotongpay.com/zfapi/users/paiditem';
//    private $withdraw_url = 'http://webapi.9vpay.com/zfapi/users/paiditem';
    private $bank_code = [
        'ICBC'=>'ICBC','CCB'=>'CCB','ABC'=>'ABC',
        'PSBC'=>'PSBS','BOC'=>'BOC', 'BCM'=>'BOCO',
        'CMB'=>'CMB','CEB'=>'CEB','CIB'=>'CIB',
        'CMBC'=>'CMBC','BOB'=>'BCCB', 'CTIB'=>'CTTIC',
        'GDB'=>'GDB','SPDB'=>'SPDB','PABC'=>'PINGANBANK',
        'HB'=>'HXB','BKSH'=>'SHB', 'CBHB'=>'CBHB',
        'NBCB'=>'NBCB','CZSB'=>'CZB','NJCB'=>'NJCB',
        'HZCB'=>'HZCB'
    ];

    private $des_key = "Y1UFhMRah4u0KEkQaX22wWTg";

    public function withdraw($withdraw,$host){

        if(!isset($this -> bank_code[$withdraw['card_bank']])){
            return false;
        }

        $param['mch_id'] = $withdraw['merch_no'];
        $param['mch_order'] = $withdraw['order_no'];
        $param['client_ip'] = '127.0.0.1';
        $param['amt'] = $withdraw['real_money'];
        $param['remark'] = '';
        $param['notify_url'] = $host . $this -> notify_url;
        $param['bank_id'] = $this -> bank_code[$withdraw['card_bank']];
        $param['bank_card'] = $withdraw['card_no'];
        $param['real_name'] = $withdraw['card_user'];
        $param['bank_open_address'] = $withdraw['order_no'];
        $param['bank_card_type'] = 1;
        $param['sign_type'] = 'md5';
        $param['created_at'] = time();

        $data = $param;

        Log::info($data);

        ksort($data);

        $sign_str = "amount=" . Helper::desencrypt($withdraw['real_money'],$this -> des_key).
            "&bankaccountname=".Helper::desencrypt($withdraw['card_user'],$this -> des_key) .
            "&bankaccountno=".Helper::desencrypt($withdraw['card_no'],$this -> des_key).
            "&bankcode=".Helper::desencrypt($this -> bank_code[$withdraw['merch_no']],$this -> des_key).
            "&branchname=".Helper::desencrypt($withdraw['card_sub_bank'],$this -> des_key).
            "&mctid={$withdraw['merch_no']}".
            "&version=v1.1.1.0";

        $sign = md5($sign_str .'&key='. $withdraw['md5_key']);

        $data['sign'] = $sign;

        $data['notifyurl'] = $host . $this -> notify_url;

        $data['userip'] = $this -> getIP();

        $data = json_encode($data,320);

        $res = Helper::post($data,$this -> withdraw_url);


        $res = json_decode($res,true);

        if($res['code'] == 1){

            return true;
        }
        return false;

    }
}