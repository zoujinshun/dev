<?php


namespace app\service;

use app\library\facade\grpc\Pay;
use app\library\facade\model\{Order};
class CommonService
{

    const SUCCESS = 0;
    const FAIL = -1;

    protected $redis;

    public function __construct()
    {
        $this -> redis = redis();
    }

    /*
     * @function getSignature 获取签名串
     * @param $params 待组合数据
     * @param $sign_type 签名方式 默认md5
     * @param $sort 是否需要排序
     * @param $is_key 数据链接是否需要字段键 默认true
     * @param $link 数据链接方式 默认"default"-key1=value2&key2=value2
     * @param $encode 数据是否需要urlencode 默认false 不需要
     * @return $signature
     * */

    protected function getSignature($params , $sort=true , $is_key=true , $link='default',$encode = false)
    {

        if($sort){
            ksort($params);
        }

        $signature = '';

        if($is_key){
            if($link == 'default'){
                $signature .= http_build_query($params);
                if(!$encode){
                    $signature = urldecode($signature);
                }
            }else{
                foreach($params as $key=>$value){
                    $signature .= $key . '=' . $value . $link;
                }
                $signature = trim($signature,$link);
            }
        }else{
            foreach($params as $key=>$value){
                $signature .= $value . $link;
            }
            $signature = trim($signature,$link);
        }
        return $signature;
    }


    /*
     * @function Sign 签名方法
     * @param $signature 待签名数据
     * @param $key rsa私钥
     * @param $method 签名方法 默认MD5 (md5签名 key在signature中)
     * @param $option rsa签名后缀
     * @param $encrypt rsa签名加密方式
     * @return $sign
     * */
    protected function sign($signature,$key,$method = 'md5',$encrypt='base64',$option = ''){
        switch ($method){
            case "MD5":
                $sign = strtoupper(md5($signature));
                break;
            case 'RSA':
                $private_key = openssl_get_privatekey($key);
                if($option !== ''){
                    openssl_sign($signature,$sign,$private_key,$option);
                }else{
                    openssl_sign($signature,$sign,$private_key);
                }
                openssl_free_key($private_key);
                if($encrypt == 'base64'){
                    $sign = base64_encode($sign);
                }else{
                    $sign = bin2hex($sign);
                }
                break;
            case 'sha1':
                $sign = sha1($signature);
                break;
            default:
                $sign = md5($signature);
                break;
        }
        return $sign;
    }

    /*
     * RSA验签方法
     * @param $signature 待验签数据
     * @param $sign 签名
     * @param $key  密钥
     * @param $key_type 密钥类型 默认公钥
     * @param $encrype 签名的加密方式 默认base64
     *
     * */

    protected function verify($signature,$sign,$key,$key_type='pub',$encrypt='base64',$option = OPENSSL_ALGO_SHA256){

        if($key_type == 'pub'){
            $key = openssl_get_publickey($key);
        }else{
            $key = openssl_get_privatekey($key);
        }

        if($encrypt == 'base64'){
            $sign = base64_decode($sign);
        }else{
            $sign = hex2bin($sign);
        }

        $result = openssl_verify($signature,$sign,$key,$option);

        return $result;
    }

    protected function setHtml($url,$params){

        $str = '<form id="Form1" name="Form1" method="post" action="' . $url . '">';
        foreach ($params as $key => $val) {
            $str = $str . '<input type="hidden" name="' . $key . '" value="' . $val . '">';
        }
        $str = $str . '</form>';
        $str = $str . '<script>';
        $str = $str . 'document.Form1.submit();';
        $str = $str . '</script>';
        return $str;

    }

    public function create_order($order){

        $order['order_name'] = '';
        $order['payline_id'] = '';
        $order['pay_receive_id'] = 0;
        $order['real_amount'] = 0;
        $order['payed_amount'] = 0;
        $order['out_trade_no'] = '';
        $order['notify_time'] = 0;
        $order['is_first_order'] = '';
        $order['remark'] = '';
        $order['optor'] = '';

        $res = Pay::addOrder($order);

        return $res;
    }

    protected function getIP(){
        $reqIp = request()->header('X-REAL-IP');
        if(empty($reqIp)){
            $reqIp = request()->ip();
        }
        if(empty($reqIp)){
            $reqIp = request()->header('host');
        }
        return $reqIp;
    }

    public function getOrderNo()
    {
        $mill_time = microtime();
        $timeInfo = explode(' ', $mill_time);
        $milis_time = sprintf('%d%03d',$timeInfo[1],$timeInfo[0] * 1000);
        return $milis_time . rand(111111,999999);
    }

    public function getStr($length=6){

        $str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

        $salt = '';

        for($i=0;$i<$length;$i++){
            $salt .= $str[mt_rand(0,strlen($str)-1)];
        }

        return $salt;
    }

}