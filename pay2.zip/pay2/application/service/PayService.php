<?php
namespace app\service;

use app\library\facade\model\{Players,PaymentSetting,FinanceSetting};
use common\Keys;
use think\facade\Config;
class PayService
{

    private $redis;
    private $payment_info;
    public function __construct()
    {
        $this -> redis = redis();
        $this -> payment_info = Config::get('pay_info.payment_info');
    }

    public function getUserInfo($username){
        $user = Players::findUserByUsername($username,'username,platform_id,platform_type,level_setting_id');
        return $user;
    }

    public function getPaySetting($agent_id){
        $pay_setting = FinanceSetting ::findFinanceSetting($agent_id,'');
        return $pay_setting;
    }

    public function getOrderNo()
    {
        $mill_time = microtime();
        $timeInfo = explode(' ', $mill_time);
        $milis_time = sprintf('%d%03d',$timeInfo[1],$timeInfo[0] * 1000);
        return $milis_time . rand(111111,999999);
    }

    public function getPayment($paytype,$payment_id,$amount,$agent_id,$level_setting_id){

        $payment_key = Keys::getPaytypeKey($this -> payment_info[$paytype],$agent_id);

        $payments = $this -> redis -> get($payment_key);

        if(!$payments){

            $payments = PaymentSetting :: findAllPayments($agent_id,$paytype);

            if(empty($payments)){
                return [];
            }
            $this -> redis -> set($payment_key,json_encode($payments));
        }else{

            $payments = json_decode($payments,true);
        }

        $result = [];

        foreach($payments as $payment){
            $limit = 0;
            $total_limit = 0;
            $limit_key = keys::getLimitMoneyKey($payment['payment_id'],$payment['merch_agent_id'],$payment['channel_type'],$payment['agent_id']);
            $limits = $this -> redis -> hgetall($limit_key);
            $date = date('Ymd');
            if(empty($limits)){
                $this -> redis -> hset($limit_key,'limit',json_encode([$date=>0]));
                $this -> redis -> hset($limit_key,'total_limit',0);
            }else{
                $today_limit = json_decode($limits['limit'],true);
                if(!isset($today_limit[$date])){
                    $today_limit[$date] = 0;
                }else{
                    $limit = $today_limit[$date];
                }
                $this -> redis -> hset($limit_key,'limit',json_encode($today_limit));
                $total_limit = $limits['total_limit'];
            }
            $level_id = explode(',',$payment['level_ids']);

            if($limit + $amount <= $payment['limit'] && $total_limit + $amount <= $payment['total_limit'] &&
                $payment['min'] <= $amount && $payment['max'] >= $amount && in_array($level_setting_id,$level_id) && $payment_id == $payment['id']){
                $result[] = $payment;
            }
        }
        return $result;
    }

    public function chosePayment($paytype,$amount,$agent_id,$level_setting_id,$payment_id=0,$payment_type){

//        $payment_key = Keys::getPaytypeKey($this -> payment_info[$paytype],$agent_id);
//
//        $payments = $this -> redis -> get($payment_key);
//
//        if(!$payments){

            $payments = PaymentSetting :: findAllPayments($agent_id,$paytype);

            if(empty($payments)){
                return [];
            }
//            $this -> redis -> set($payment_key,json_encode($payments));
//        }else{
//
//            $payments = json_decode($payments,true);
//        }

        $result = [];

        if($payment_id){
            foreach($payments as $p){
                if($p['id'] == $payment_id && $p['channel_type'] == $payment_type){
                    $limit = 0;
                    $total_limit = 0;
                    $limit_key = keys::getLimitMoneyKey($p['payment_id'],$p['merch_agent_id'],$payment_type,$p['agent_id']);
                    $limits = $this -> redis -> hgetall($limit_key);
                    $date = date('Ymd');
                    if(empty($limits)){
                        $this -> redis -> hset($limit_key,'limit',json_encode([$date=>0]));
                        $this -> redis -> hset($limit_key,'total_limit',0);
                    }else{
                        $today_limit = json_decode($limits['limit'],true);
                        if(!isset($today_limit[$date])){
                            $today_limit[$date] = 0;
                        }else{
                            $limit = $today_limit[$date];
                        }
                        $this -> redis -> hset($limit_key,'limit',json_encode($today_limit));
                        $total_limit = $limits['total_limit'];
                    }
                    $level_id = explode(',',$p['level_ids']);

                    if($limit + $amount <= $p['limit'] && $total_limit + $amount <= $p['total_limit'] &&
                        $p['min'] <= $amount && $p['max'] >= $amount && in_array($level_setting_id,$level_id)){
                        $result[] = $p;
                    }
                }
            }
        }

        foreach($payments as $payment){

            if($payment['id'] == $payment_id || $payment['channel_type'] != $payment_type){
                continue;
            }

            $limit = 0;
            $total_limit = 0;
            $limit_key = keys::getLimitMoneyKey($payment['payment_id'],$payment['merch_agent_id'],$payment_type,$payment['agent_id']);
            $limits = $this -> redis -> hgetall($limit_key);
            $date = date('Ymd');
            if(empty($limits)){
                $this -> redis -> hset($limit_key,'limit',json_encode([$date=>0]));
                $this -> redis -> hset($limit_key,'total_limit',0);
            }else{
                $today_limit = json_decode($limits['limit'],true);
                if(!isset($today_limit[$date])){
                    $today_limit[$date] = 0;
                }else{
                    $limit = $today_limit[$date];
                }
                $this -> redis -> hset($limit_key,'limit',json_encode($today_limit));
                $total_limit = $limits['total_limit'];
            }
            $level_id = explode(',',$payment['level_ids']);

            if($limit + $amount <= $payment['limit'] && $total_limit + $amount <= $payment['total_limit'] &&
                $payment['min'] <= $amount && $payment['max'] >= $amount && in_array($level_setting_id,$level_id)){
                $result[] = $payment;
            }
        }
        return $result;
    }
}