<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/10/21
 * Time: 16:42
 */

namespace app\service;

use app\library\facade\model\{PayIncomeDb as PayIncome,MerchAgentSetting};
use app\model\WithdrawOrder;
use app\model\PayIncomeDb;
class WithdrawNotify extends CommonService
{
    public function getOrder($order){

        $field = 'order_no,card_no,card_user,card_bank,card_sub_bank,money,administrative_fee,discount_fee,real_money,status';

        $order = WithdrawOrder::findOrder(['order_no'=>$order],$field);

        return $order;
    }

    public function findMerch($merch_agent_id){

        $payment = MerchAgentSetting::findMerch($merch_agent_id,'md5_key,private_key,public_key,merch_no');

        return $payment;
    }

    public function changeOrderStatus($order_no,$data){

        $res = WithdrawOrder::updatesOrder(['order_no'=>$order_no],$data);

        return $res;
    }

    public function insertPayincome($order_info){

        $remark = json_decode($order_info['remark'],true);

        $data['order_no'] = $order_info['order_no'];
        $data['record_id'] = $order_info['order_no'];
        $data['platform_type'] = $order_info['agent_id'];
        $data['agent_id'] = $order_info['agent_id'];
        $data['platform_id'] = $order_info['platform_id'];
        $data['username'] = $order_info['username'];
        $data['start_game_time'] = time();
        $data['finish_game_time'] = time();
        $data['opt_type'] = PayIncomeDb::OPT_TYPE_WITHDRAW_MANUAL_SUCCESS;
        $data['deal_type'] = ($order_info['order_type'] == 2) ? PayIncomeDb::GOLD_TYPE_WITHDRAWAL_MANUAL : PayIncomeDb::GOLD_TYPE_WITHDRAWALS;
        $data['front_remark'] = $remark['front_remark'] ?? '';
        $data['back_remark'] = $remark['remark'] ?? '';
        $data['cur_count'] = $order_info['game_gold'] ?? 0;
        $data['item_count'] = $order_info['real_money'];
        $data['operator'] = $order_info['operator'];

        PayIncome::insertLog($data);
    }
}