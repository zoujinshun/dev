<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/5/5
 * Time: 10:01
 */
return [
    // 指令名 =》完整的类名
    'genfacade'	=>	'\common\Genfacade',
    'kafka'	=>	'\cron\Kafka',
];