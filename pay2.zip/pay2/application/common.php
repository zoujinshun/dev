<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------
// 公共助手函数
use think\facade\Env;
if (!function_exists('__')) {

    /**
     * 获取语言变量值
     * @param string $name 语言变量名
     * @param array $vars 动态变量值
     * @param string $lang 语言
     * @return mixed
     */
    function __($name, $vars = [], $lang = '')
    {
        if (is_numeric($name) || !$name)
            return $name;
        if (!is_array($vars)) {
            $vars = func_get_args();
            array_shift($vars);
            $lang = '';
        }
        return Lang::get($name, $vars, $lang);
    }

}
// 应用公共文件
if(!function_exists('redis'))
{
    /**
     * @desc 创建redis实例
     * @param null $config
     * @return \Predis\Client
     */
    function redis($config=null,$newInstance=false)
    {
        $baseConfig = [
            'host'       => Env::get("redis.ip", ''),
            'port'       => Env::get("redis.port", ''),
            //'password'   => Env::get("redis.password",''),
            'prefix'     => Env::get("redis.prefix", ''),
            'expire'     => Env::get("redis.expire", 3600),
            'persistent' => Env::get("redis.persistent", false),
            'database'   => Env::get("redis.database", 1),
            'read_write_timeout' => -1,

        ];
        $password = Env::get("redis.password",'');
        if($password){
            $baseConfig['password'] = $password;
        }
        if ($config) {
            $config = array_merge($baseConfig,$config);
        }else{
            $config = $baseConfig;
        }
        return app('redis', [$config],$newInstance);
    }
}

if(!function_exists('mongo')){
    function mongo($database)
    {
        $uri = Env::get("{$database}.dsn");
        $db  = Env::get("{$database}.database");
        if(!$uri || !$db){
            return false;
        }
        $client =  app('mongo', [$uri]);
        return $client->$db;

    }
}