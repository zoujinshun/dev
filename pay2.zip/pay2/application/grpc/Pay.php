<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/11/27
 * Time: 14:48
 */

namespace app\grpc;

//常量
use Grpc_proto\Audit\AuditOrdersFields;
use Grpc_proto\Common_data\{OrderType,OrderStatus,PayStatus};
//请求
use Grpc_proto\Pay\{PayOrdersAddReq,PayOrderSelectReq,PayOrderQueryRowReq};
//其他分页
use Grpc_proto\Pay\{OrderFields, OrdersCondition, OrderUpdateField, PayOrderUpdateReq};
//排序分页
use Grpc_proto\Common_data\{SortInfo};
use protoProtocol\GrpcClient;

class Pay
{
    private $client;
    public function __construct()
    {
        $this -> client = new GrpcClient(true);
    }

    public function addOrder($order){
        $data = [
            'platform_type' => (int)$order['platform_type'],
            'order_no' => $order['order_no'],
            'username' => $order['username'],
            'order_name' => $order['order_name'],
            'payline_id' => OrderType::ORDER_TYPE_ONLINE,
            'payment_id' => (int)$order['payment_id'],
            'pay_receive_id' => 0,
            'order_status' => OrderStatus::ORDER_STATUS_PENDING,
            'pay_status' => PayStatus::PAY_STATUS_PENDING,
            'amount' => (float)$order['amount'],
            'merch_agent_id' => (int)$order['merch_agent_id'],
            'channel_type' => '',
            'config_valid_bet' => (float)$order['config_valid_bet'],
            'deduce_amount' => (float)$order['deduce_amount'],
            'deduce_bet' => (float)$order['deduce_bet'],
            'real_amount' => 0,
            'payed_amount' => 0,
            'out_trade_no' => '',
            'create_time' => time(),
            'notify_time' => 0,
            'is_first_order' => 0,
            'remark' => $order['remark'] ?? '',
            'optor' => ''
        ];

        $order_data = new OrderFields($data);

        $request = new PayOrdersAddReq();

        $request -> setPay($order_data);

        $res = $this -> client -> getResponse($request);

        if($res->getResult()){
            return false;
        }

        return true;
    }

    public function getOrders($username,$status,$offset,$limit){

        $condition_data = ['username' => $username];
        if($status){
            $condition_data['pay_status'] = is_array($status) ? $status : [$status];
        }
        $condition = new OrdersCondition($condition_data);
        $limit_data = ['sort_field'=>'create_time','sort_order'=>'desc','limit'=>$limit,'page'=>$offset];
        $limit = new SortInfo($limit_data);

        $request = new PayOrderSelectReq();
        $request -> setCondition($condition);
        $request -> setLimit($limit);

        $res = $this -> client -> getResponse($request,$error);

        if($res->getResult() || $error){
            return [];
        }
        $result = json_decode($res -> serializeToJsonString(),true);

        return $result['list'] ?? [];
    }

    public function getOrder($order_no){

        $request = new PayOrderQueryRowReq(['order_no' => $order_no]);
        $res = $this -> client -> getResponse($request,$error);
        if($res->getResult() || $error){
            return [];
        }
        $result = json_decode($res -> serializeToJsonString(),true);

        return $result['list'] ?? [];
    }

    public function updateOrder($order_no,$order,$audit){

        $order_info = new OrderUpdateField($order);

        $data = ['order_no'=>$order_no,'fields'=>$order_info];

        if(!empty($audit)){
            $data['audit'] = new AuditOrdersFields($audit);
        }
        $request = new PayOrderUpdateReq();

        $response = $this -> client -> getResponse($request,$error);

        if($response->getResult() || $error){
            return false;
        }
        return true;
    }

}