<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/3/12
 * Time: 11:06
 */

namespace cron;
use app\library\facade\model\GameDataDb;
use app\library\facade\model\PayIncomeDb;
use app\library\facade\model\UserDynamicBaseinfo;
use app\library\facade\model\Userplatformmapinfo;
use common\Code;
use common\Helper;
use think\exception\PDOException;
use think\facade\Env;
use think\facade\Log;
use app\library\facade\model\UserVipSetting;
class UserVip
{

    public static function init()
    {

    }
    public static function run()
    {
        self::init();
        $conf = new \RdKafka\Conf();

// Set the group id. This is required when storing offsets on the broker
        $conf->set('group.id', 'vip_group_1');

        $rk = new \RdKafka\Consumer($conf);
        $rk->addBrokers(Env::get("kafka.ip"));
        $topicConf = new \RdKafka\TopicConf();
        $topicConf->set("auto.commit.interval.ms", 1e3);
        $topicConf->set("offset.store.sync.interval.ms", 60e3);
// Set the offset store method to 'file'
        $topicConf->set('offset.store.method', 'broker');
//        @unlink(RUNTIME_PATH.'wm/kafka-offset.txt');
//        $topicConf->set('offset.store.path', RUNTIME_PATH.'wm/kafka-offset.txt');

// Alternatively, set the offset store method to 'broker'
// $topicConf->set('offset.store.method', 'broker');

// Set where to start consuming messages when there is no initial offset in
// offset store or the desired offset is out of range.
// 'smallest': start from the beginning
        $topicConf->set('auto.offset.reset', 'smallest');
        $topicConf->set('auto.commit.enable', true);
        $topic = $rk->newTopic("vip", $topicConf);
        // Start consuming partition 0
        $topic->consumeStart(0, RD_KAFKA_OFFSET_STORED);
        while (true) {
            $message = $topic->consume(0, 120*10000);
            if(!is_object($message)){
                sleep(2);
                continue;
            }
            switch ($message->err) {
                case RD_KAFKA_RESP_ERR_NO_ERROR:
                    self::payload($message->payload);
                    break;
                case RD_KAFKA_RESP_ERR__PARTITION_EOF:
                    Log::error("No more messages; will wait for more");
                    break;
                case RD_KAFKA_RESP_ERR__TIMED_OUT:
                    Log::error("Timed out");
                    break;
                default:
                    Log::error("error code {$message->err}:".$message->errstr());
                    break;
            }
        }
    }
    public static function payload($payload)
    {
        $data = (array)json_decode($payload,true);
        if(!$data){
            Log::error("解析异常:".$payload);
            return ;
        }
        //#TODO VIP更改处理逻辑
        self::updateUserVipLevel($data);
    }

    private static function updateUserVipLevel($item)
    {
        $username = $item['username'];
        $platform_type = $item['platform_type'];
        $operation_id = $item['operation_id'];

        // 获取用户信息
        $info = UserDynamicBaseinfo::getValidBet($username);
        if(!$info){
            return ;
        }
        // 根据有效投注计算 vip 等级
        $vip = UserVipSetting::getVipLevel($platform_type,$operation_id,$info['valid_bet']);
        $diff = $vip - $info['vip_level'];
        if(!$diff){
            return ;
        }
        // 更新 vip 等级
        $res = Helper::postVip($username,$diff);
        if($res['code'] != Code::SUCCESS){
            Log::error('update vip level error,username is '.$username.' error msg:'.$res['msg']);
        }
        return ;
    }
    public static function test($arg=null)
    {
        echo 122;
    }
}