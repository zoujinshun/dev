<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/5/5
 * Time: 9:48
 */

namespace cron;


use think\App;
use think\console\Command;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;
use think\facade\Config;
use think\worker\facade\Worker;
use Workerman\Lib\Timer;

class Kafka extends Command
{
    private $config;
    protected function configure()
    {
        $this->setName('kafka')
            ->addArgument('action', Argument::OPTIONAL, "start|stop|restart|reload|status", 'start')
            ->addOption('daemon', 'd', Option::VALUE_NONE, 'Run the workerman server in daemon mode.')
            ->setDescription('Workerman timer Server for ThinkPHP');
    }

    protected function execute(Input $input, Output $output)
    {
        $action = $input->getArgument('action');
        $daemon = $input->getOption('daemon');
        if (DIRECTORY_SEPARATOR !== '\\') {
            if (!in_array($action, ['start', 'stop', 'reload', 'restart', 'status'])) {
                $output->writeln("<error>Invalid argument action:{$action}, Expected start|stop|restart|reload|status|connections .</error>");
                return false;
            }

            global $argv;
            array_shift($argv);
            array_shift($argv);
            array_unshift($argv, 'think', $action);
        } elseif ('start' != $action) {
            $output->writeln("<error>Not Support action:{$action} on Windows.</error>");
            return false;
        }

        if ('start' == $action) {
            $output->writeln('Starting Workerman ...');
        }
        $this->config = Config::pull('kafka_worker');

        // 全局静态属性设置
        foreach ($this->config as $name => $val) {
            if (in_array($name, ['daemonize', 'pidFile', 'logFile'])) {
                \Workerman\Worker::${$name} = $val;
                unset($this->config[$name]);
            }
        }
        foreach ($this->config['taskList'] as $name=>$item)
        {
            if(!isset($item['timer']) || !isset($item['task']) || !isset($item['status'])){
                continue;
            }
            $status = $item['status'];
            if(!$status){
                continue;
            }
            $timer = $item['timer'];
            $worker = new \Workerman\Worker();
            $worker->name = $item['name']??$name;
            $worker->count = $item['count']??1;
            $task = $item['task'];
            $worker->onWorkerStart = function ($worker) use($output,$timer,$task){
                if($timer){
                    if(!is_array($task)){
                        $output->writeln("定时器任务配置错误:task必须配置为数组");
                        return ;
                    }
                    if(!isset($task['interval']) || !isset($task['function'])){
                        $output->writeln("定时器任务配置错误:interval参数或function没有配置");
                        return ;
                    }
                    $task['arguments'] = $task['arguments']??[];
                    Timer::add($task['interval'],$task['function'],$task['arguments']);

                }else{
                    if(is_string($task)){
                        call_user_func($task);
                    }else if(is_array($task)){
                        call_user_func_array($task['function'],$task['arguments']);
                    }
                }
            };
        }
        \Workerman\Worker::runAll();
    }
}