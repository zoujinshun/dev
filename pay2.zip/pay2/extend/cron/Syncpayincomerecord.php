<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/3/12
 * Time: 11:06
 */

namespace cron;
use app\library\facade\model\GameDataDb;
use app\library\facade\model\PayIncomeDb;
use app\library\facade\model\Userplatformmapinfo;
use common\Helper;
use common\Code;
use think\exception\PDOException;
use think\facade\Env;
use think\facade\Log;

class Syncpayincomerecord
{
    protected static $rktopic;


    public static function test()
    {
        var_export(RD_KAFKA_RESP_ERR__ASSIGN_PARTITIONS);exit;
        $res = <<<json
{"data":[{"username":"100036941","record_id":"425524644732S4001I183","start_game_time":"0","finish_game_time":"0","game_type":"4","room_id":"","seat_id":"0","room_type":"0","room_level":"0","room_rate":"0","room_flag":"0","player_flag":"0","service_id":"4001","opt_type":"101","all_bet":"0.0","valid_bet":"0.0","return_prize":"0.0","taxation":"0.0","item_type":"2","item_count":"-81697.4","cur_count":"0.0","opt_log":"","remark":"manager change","create_time":"0000-00-00 00:00:00"}],"database":"logic_db_run","es":1552464473000,"id":86584,"isDdl":false,"mysqlType":{"idx":"int(11) unsigned","username":"char(32)","record_id":"char(32)","start_game_time":"int(11) unsigned","finish_game_time":"int(11) unsigned","game_type":"int(10) unsigned","room_id":"char(32)","seat_id":"int(11)","room_type":"int(10) unsigned","room_level":"int(10) unsigned","room_rate":"int(10) unsigned","room_flag":"int(10) unsigned","player_flag":"int(10) unsigned","service_id":"int(10) unsigned","opt_type":"int(10) unsigned","all_bet":"double","valid_bet":"double","return_prize":"double","taxation":"double","item_type":"int(10) unsigned","item_count":"double","cur_count":"double","opt_log":"blob","remark":"char(32)","create_time":"datetime"},"old":null,"pkNames":["idx"],"sql":"","sqlType":{"idx":4,"username":1,"record_id":1,"start_game_time":4,"finish_game_time":4,"game_type":4,"room_id":1,"seat_id":4,"room_type":4,"room_level":4,"room_rate":4,"room_flag":4,"player_flag":4,"service_id":4,"opt_type":4,"all_bet":8,"valid_bet":8,"return_prize":8,"taxation":8,"item_type":4,"item_count":8,"cur_count":8,"opt_log":2004,"remark":1,"create_time":93},"table":"tb_user_pay_income_record","ts":1552464474277,"type":"INSERT"}
json;
        $resData = json_decode($res,true);
        $list = $resData['data'];
        foreach ($list as $item)
        {
            unset($item['idx'],$item['remark'],$item['create_time']);

            $username = $item['username'];
            if(!$username)
            {
                Log::error("用户名未找到:".json_encode($item));
                continue;
            }
            $platformInfo = Userplatformmapinfo::where("username",$username)->field("platform_type,operation_id")->find();
            if(!$platformInfo){
                Log::error("代理商未找到:".json_encode($item));
                continue;
            }
            $item['platform_type'] = $platformInfo['platform_type'];
            $item['operation_id'] = $platformInfo['operation_id'];
        }
    }
    public static function init()
    {

    }
    public static function run()
    {
        self::init();
        $conf = new \RdKafka\Conf();

// Set the group id. This is required when storing offsets on the broker
        $conf->set('group.id', 'app_group_1');

        $rk = new \RdKafka\Consumer($conf);
        $rk->addBrokers(Env::get("kafka.ip"));
        $topicConf = new \RdKafka\TopicConf();
        $topicConf->set("auto.commit.interval.ms", 1e3);
        $topicConf->set("offset.store.sync.interval.ms", 60e3);
// Set the offset store method to 'file'
        $topicConf->set('offset.store.method', 'broker');
//        @unlink(RUNTIME_PATH.'wm/kafka-offset.txt');
//        $topicConf->set('offset.store.path', RUNTIME_PATH.'wm/kafka-offset.txt');

// Alternatively, set the offset store method to 'broker'
// $topicConf->set('offset.store.method', 'broker');

// Set where to start consuming messages when there is no initial offset in
// offset store or the desired offset is out of range.
// 'smallest': start from the beginning
        $topicConf->set('auto.offset.reset', 'smallest');
        $topicConf->set('auto.commit.enable', true);
        $topic = $rk->newTopic("app", $topicConf);
        // Start consuming partition 0
        $topic->consumeStart(0, RD_KAFKA_OFFSET_STORED);

        $rk = new \RdKafka\Producer();
        $rk->setLogLevel(LOG_DEBUG);
        $rk->addBrokers(Env::get('kafka.ip'));
        $rktopicConf = new \RdKafka\TopicConf();
        $rktopicConf->set("auto.commit.interval.ms", 1e3);
        $rktopicConf->set("offset.store.sync.interval.ms", 60e3);
        self::$rktopic = $rk->newTopic('vip', $rktopicConf);
        while (true) {
            $message = $topic->consume(0, 120*10000);
            if(!is_object($message)){
                sleep(2);
                continue;
            }
            switch ($message->err) {
                case RD_KAFKA_RESP_ERR_NO_ERROR:
                    self::payload($message->payload);
                    break;
                case RD_KAFKA_RESP_ERR__PARTITION_EOF:
                    Log::error("No more messages; will wait for more");
                    break;
                case RD_KAFKA_RESP_ERR__TIMED_OUT:
                    Log::error("Timed out");
                    break;
                default:
                    Log::error("error code {$message->err}:".$message->errstr());
                    break;
            }
        }
    }
    public static function payload($payload)
    {
        $payload = json_decode($payload,true);
        if(!$payload){
            Log::error("解析异常:".$payload);
            return ;
        }
        if($payload['database'] == 'gamedata_log_master_app')
        {
            switch ($payload['table'])
            {

                case 'tb_game_data_pool_record':
                    /**
                     * @desc这个表不需要做update，delete处理
                     */
                    if($payload['type'] == "INSERT")
                    {
                        $list = $payload['data'];

                        foreach ($list as $item)
                        {
                            $r = GameDataDb::insertLog($item);
                            if(false === $r){
                            }else{
                                GameDataDb::copyLog($item);
                            }
                        }
                    }
                    break;
            }
        }
        if($payload['database'] == 'payincome_log_master_app')
        {
            switch ($payload['table'])
            {
                case 'tb_user_pay_income_record':
                    /**
                     * @desc这个表不需要做update，delete处理
                     */
                    if($payload['type'] == "INSERT")
                    {
                        $list = $payload['data'];
                        foreach ($list as $item)
                        {
                            unset($item['idx'],$item['remark'],$item['create_time']);
                            $username = $item['username'];
                            if(!$username)
                            {
                                Log::error("用户名未找到 username:{$username}");
                                continue;
                            }
                            $platformInfo = Userplatformmapinfo::where("username",$username)->field("username,platform_type,operation_id,platform_id")->find();
                            if(!$platformInfo){
                                Log::error("代理商未找到:username（{$username}）");
                                continue;
                            }
                            $item['platform_type'] = $platformInfo['platform_type'];
                            $item['pkg_id'] = $platformInfo['operation_id'];
                            $item['platform_id'] = $platformInfo['platform_id'];
                            try{
                                ;
                                self::$rktopic->produce(RD_KAFKA_PARTITION_UA, 0, json_encode($platformInfo));
                                $r = PayIncomeDb::insertLog($item);
                                if(false === $r){
                                    continue;
                                }else{
                                    PayIncomeDb::copyLog($item);
                                }
                            }catch (PDOException $e){
                                Log::error(__METHOD__.$e->getMessage());
                            }

                        }
                    }
                    break;
            }
        }


    }

}