<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/23
 * Time: 20:20
 */

namespace common;


use app\model\Tokens;
use think\facade\{Env, Log};

class Helper
{
    static function isXmlFormat($str)
    {
        $xml_parser = xml_parser_create();
        if (!xml_parse($xml_parser, $str, true)) {
            xml_parser_free($xml_parser);
            return false;
        } else {
            return true;
        }
    }
    public static function objectToArray($array)
    {

        if (is_object($array)) {
            $array = (array)$array;
        }
        if (is_array($array)) {
            foreach ($array as $key => $value) {
                $array[$key] = self::objectToArray($value);
            }
        }
        return $array;
    }

    public static function getSignature($content)
    {
        list($signature) = explode(" ", strtoupper(md5($content . "&" . Env::get("c++_server.key"))));
        return $signature;
    }

    /**
     * @desc 响应结果处理
     * @param $retMsg
     */
    public static function result($retMsg)
    {
        $res = json_decode($retMsg, true);
        if (!$res) {
            return ["code" => Code::PARAM_ERROR, "msg" => "响应格式异常"];
        }
        if (isset($res['code']) && $res['message'] && ($res['code'] == 0)) {
            //成功返回
            return ["code" => Code::SUCCESS, "msg" => $res['message']];
        }
        return ["code" => isset($res['code']) ? $res['code'] : Code::PARAM_ERROR, "msg" => isset($res['message']) ? $res['message'] : "message字段不存在"];
    }

    /**
     * 增减用户金币
     */
    public static function postGold($username, $num, $bills_id,$third_account , $optType = 109, $remark = '', $extraData = [])
    {
        // 游戏内操作
        $goodsType = 2;
        $data = [
            $goodsType => $num,
            'optType'  => $optType,
            'bills_id' => $bills_id,
            'third_account' => $third_account,
            'remark'   => $remark,
            'username' => $username,
            'mgr_info' => is_array($extraData) ? json_encode($extraData) : $extraData,
        ];
        ksort($data, SORT_NATURAL);
        $content = http_build_query($data);
        $url = Env::get("c++_server.url");
        $url = trim($url, "/")."/change/item";
        $signature = self::getSignature($content);
        $message = $content."&signature=".$signature;
        $retMsg = Http::post($url, $message);
        Log::info(json_encode(["url" => $url, 'params' => $message, 'response' => $retMsg]));
        return self::result($retMsg);
    }

    /**
     * 增减用户vip等级
     */
    public static function postVip($username, $vip = 1)
    {
        $data = [
            'opt_type' => 104,
            '202' => $vip,
            'username' => $username,
        ];
        ksort($data,SORT_NATURAL);
        $content = http_build_query($data);
        $url = Env::get("c++_server.url");
        $url = trim($url, "/") . "/change/user_data";
        $signature = self::getSignature($content);
        $message = $content . "&signature=" . $signature;
        $retMsg = Http::post($url, $message);
        Log::info(json_encode(["url" => $url, 'username' => $username, "vip" => $vip, 'response' => $retMsg]));
        return self::result($retMsg);
    }


    /**
     * 检测Token是否正确,数据是否正确
     *
     */
    public static function checkToken($token, $data)
    {

        ksort($data);
        list($real_token, $mcypt_data_token) = explode('.', $token);
        $row = Tokens::get(['token' => $real_token]);

        if (!$row || !($row->toArray())) {
            Log::error("token 在数据库中未找到");
            return Code::TOKEN_NO_FOUND;
        }

        if ($row['expire'] <= time()) {
            Log::error("token 已过期");
            return Code::TOKEN_EXPIRE;
        }

        if ($row['used_num'] > $row['num']) {
            Log::error("token 使用次数超额");
            return Code::TOKEN_USE_NUM_LIMITED;
        }
        if(!isset($data['username'])){
            Log::error("没有传入username");
            return Code::PARAM_ERROR;
        }
        if ($row['username'] != $data['username']) {
            Log::error("用户不匹配");
            return Code::TOKEN_USERNAME_ERR;

        }

        ksort($data);
//        if(hash('sha256',base64_encode(json_encode($data)).md5($row['profile'])) == $mcypt_data_token){
//            Log::error("签名不正确");
//            return Code::TOKEN_SIGN_ERR;
//        }
        if (md5(md5(json_encode($data, JSON_UNESCAPED_UNICODE)) . md5($row['profile'])) !== $mcypt_data_token) {
            Log::error("签名不正确");
            return Code::TOKEN_SIGN_ERR;
        }

        $row->setInc("used_num", 1);
        return [Code::SUCCESS, $row];

    }
    /**
     * @desc 更新用户配置
     * @param int $service_id
     * @return array
     * @throws \think\Exception
     * @throws \think\exception\DbException
     */
    public static function postConfig($service_id = 0)
    {
        $serviceConfigModel = model("serverconfig.Serviceconfiginfo");
        $data = $serviceConfigModel->field("idx,server_id,business_file_name")->where(["service_id" => $service_id])->select();
        $data = collection($data)->toArray();

        if (!$data) {
            Log::error(__METHOD__ . " tb_service_config_info表 service_id:$service_id 记录不存在");

        }
        $url = Env::get("c++_server.url");
        $url = trim($url, "/") . "/update/config";
        foreach ($data as $item)
        {
            foreach ($item as $key => $val) {
                $$key = $val;
            }
            $content = "idx={$idx}&server_id={$server_id}&file_name={$business_file_name}&file_context_type=business_config_context";

            $signature = self::getSignature($content);
            $message = $content . "&signature=" . $signature;
            $retMsg = Http::post($url, $message);
            Log::info(json_encode(["url" => $url, 'service_id' => $service_id, "param" => $content, 'response' => $retMsg]));
        }
        return self::result($retMsg);
    }
    public static function kafkaProduce($topic,$message)
    {
        $rk = new \RdKafka\Producer();
        $rk->setLogLevel(LOG_DEBUG);
        $rk->addBrokers(Env::get('kafka.ip'));
        $topicConf = new \RdKafka\TopicConf();
        $topicConf->set("auto.commit.interval.ms", 1e3);
        $topicConf->set("offset.store.sync.interval.ms", 60e3);
        $topic = $rk->newTopic($topic, $topicConf);
        $topic->produce(RD_KAFKA_PARTITION_UA, 0, $message);
    }

    public static function post($PostArry,$request_url,$header=[])
    {
        $postData = $PostArry;
        $postDataString = is_string($postData) ? $postData : http_build_query($postData);//格式化参数

        $curl = curl_init(); // 启动一个CURL会话
        curl_setopt($curl, CURLOPT_URL, $request_url); // 要访问的地址
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE); // 对认证证书来源的检查
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE); // 从证书中检查SSL加密算法是否存在
        curl_setopt($curl, CURLOPT_POST, true); // 发送一个常规的Post请求
        curl_setopt($curl, CURLOPT_POSTFIELDS, $postDataString); // Post提交的数据包
        curl_setopt($curl, CURLOPT_TIMEOUT, 60); // 设置超时限制防止死循环返回
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl,CURLOPT_HTTPHEADER,$header);


        $tmpInfo = curl_exec($curl); // 执行操作

        if (curl_errno($curl)) {
            $tmpInfo = curl_error($curl);//捕抓异常
        }
        curl_close($curl); // 关闭CURL会话
        return $tmpInfo; // 返回数据
    }

    public static function getHost(){
        $host = request() -> host();

        if(strpos($host,':') === false){
            $port = request() -> port();
            if($port != '80'){
                $host .= ':' . $port;
            }
        }

        $host = 'http://' . $host;

        return $host;
    }

    public static function getIP(){
        $reqIp = request()->header('X-REAL-IP');
        if(empty($reqIp)){
            $reqIp = request()->ip();
        }
        if(empty($reqIp)){
            $reqIp = request()->header('host');
        }
        return $reqIp;
    }

    /*
     * @function getPaySignature 获取签名串
     * @param $params 待组合数据
     * @param $sign_type 签名方式 默认md5
     * @param $sort 是否需要排序
     * @param $is_key 数据链接是否需要字段键 默认true
     * @param $link 数据链接方式 默认"default"-key1=value2&key2=value2
     * @param $encode 数据是否需要urlencode 默认false 不需要
     * @return $signature
     * */

    public static function getPaySignature($params , $sort=true , $is_key=true , $link='default',$encode = false)
    {

        if($sort){
            ksort($params);
        }

        $signature = '';

        if($is_key){
            if($link == 'default'){
                $signature .= http_build_query($params);
                if(!$encode){
                    $signature = urldecode($signature);
                }
            }else{
                foreach($params as $key=>$value){
                    $signature .= $key . '=' . $value . $link;
                }
                $signature = trim($signature,$link);
            }
        }else{
            foreach($params as $key=>$value){
                $signature .= $value . $link;
            }
            $signature = trim($signature,$link);
        }
        return $signature;
    }

    /*
     * @function Sign 签名方法
     * @param $signature 待签名数据
     * @param $key rsa私钥
     * @param $method 签名方法 默认MD5 (md5签名 key在signature中)
     * @param $option rsa签名后缀
     * @param $encrypt rsa签名加密方式
     * @return $sign
     * */
    public static function sign($signature,$key,$method = 'md5',$encrypt='base64',$option = ''){
        switch ($method){
            case "MD5":
                $sign = strtoupper(md5($signature));
                break;
            case 'RSA':
                if(strpos($key,"\r\t") === false){
                    $key = self::handleKey($key,'private');
                }
                $private_key = openssl_get_privatekey($key);

                if($option !== ''){
                    openssl_sign($signature,$sign,$private_key,$option);
                }else{
                    openssl_sign($signature,$sign,$private_key);
                }
                openssl_free_key($private_key);
                if($encrypt == 'base64'){
                    $sign = base64_encode($sign);
                }else{
                    $sign = bin2hex($sign);
                }
                break;
            case 'sha1':
                $sign = sha1($signature);
                break;
            default:
                $sign = md5($signature);
                break;
        }
        return $sign;
    }

    /*
     * RSA验签方法
     * @param $signature 待验签数据
     * @param $sign 签名
     * @param $key  密钥
     * @param $key_type 密钥类型 默认公钥
     * @param $option 验签类型 OPENSSL_ALGO_SHA256
     * @param $encrype 签名的加密方式 默认base64
     *
     * */

    public static function verify($signature,$sign,$key,$key_type='pub',$encrypt='base64',$option){

        if($key_type == 'pub'){
            if(strpos($key,"\r\n") === false){
                $key = self::handleKey($key,'public');
            }
            $key = openssl_get_publickey($key);
        }else{
            if(strpos($key,"\r\n") === false){
                $key = self::handleKey($key,'private');
            }
            $key = openssl_get_privatekey($key);
        }

        if($encrypt == 'base64'){
            $sign = base64_decode($sign);
        }else{
            $sign = hex2bin($sign);
        }

        if($option){
            $result = openssl_verify($signature,$sign,$key,$option);
        }else{
            $result = openssl_verify($signature,$sign,$key);
        }

        return $result;
    }

    public static function pub_encrypt($data,$public_key){

        $key = openssl_pkey_get_public($public_key);

        if ($key == false){
            return false;
        }

        $encryptData = '';
        $crypto = '';
        foreach (str_split($data, 117) as $chunk) {
            openssl_public_encrypt($chunk, $encryptData, $key);
            $crypto .= $encryptData;
        }

        $crypto = base64_encode($crypto);
        return $crypto;
    }

    public static function pri_decrypt($data,$private_key){

        if(strpos($private_key,"\r\n") === false){
            $private_key = self::handleKey($private_key,'private');
        }

        $key = openssl_get_privatekey($private_key);

        if ($key == false){
            return false;
        }
        $data = base64_decode($data);
        $crypto = '';
        foreach (str_split($data, 128) as $chunk) {
            openssl_private_decrypt($chunk, $decryptData, $key);
            $crypto .= $decryptData;
        }

        return json_decode($crypto,true);
    }

    public static function handleKey($key,$key_type='public'){

        if($key_type == 'public'){
            $key_header = "-----BEGIN PUBLIC KEY-----\r\n";
            $key_footer = "-----END PUBLIC KEY-----";
        }else{
            $key_header = "-----BEGIN RSA PRIVATE KEY-----\r\n";
            $key_footer = "-----END RSA PRIVATE KEY-----";
        }

        $key_str = "";

        $key = str_replace(' ','',$key);

        foreach (str_split($key,64) as $str){
            $key_str .= $str . "\r\n";
        }

        $key = $key_header . $key_str . $key_footer;

        return $key;
    }

    public static function desencrypt($input,$key){

        $iv = "00000000";

        $size = mcrypt_get_block_size(MCRYPT_3DES,MCRYPT_MODE_ECB);

        $pad = $size - (strlen($input) % $size);
        $input = $input . str_repeat(chr($pad), $pad);

        $key = str_pad($key,24,'0');
        $td = mcrypt_module_open(MCRYPT_3DES, '', MCRYPT_MODE_ECB, '');
        if( $iv == '' )
        {
            $iv = @mcrypt_create_iv (mcrypt_enc_get_iv_size($td), MCRYPT_RAND);
        }

        @mcrypt_generic_init($td, $key, $iv);
        $data = mcrypt_generic($td, $input);
        mcrypt_generic_deinit($td);
        mcrypt_module_close($td);
        $data = base64_encode($data);
        return $data;
    }

    public function decrypt($encrypted,$key){
        $iv = "00000000";
        $encrypted = base64_decode($encrypted);
        $key = str_pad($key,24,'0');
        $td = mcrypt_module_open(MCRYPT_3DES,'',MCRYPT_MODE_ECB,'');
        if( $iv == '' )
        {
            $iv = @mcrypt_create_iv (mcrypt_enc_get_iv_size($td), MCRYPT_RAND);
        }

        $ks = mcrypt_enc_get_key_size($td);
        @mcrypt_generic_init($td, $key, $iv);
        $decrypted = mdecrypt_generic($td, $encrypted);
        mcrypt_generic_deinit($td);
        mcrypt_module_close($td);
        $y=$this->pkcs5_unpad($decrypted);
        return $y;
    }

    public static function getStr($start,$end,$str){
        $start = strpos($str,$start) + strlen($start);
        $end = strpos($str,$end);
        $str = substr($str,$start,$end-$start);
        return $str;
    }

    public static function getTimestamp(){
        $mill_time = microtime();
        $timeInfo = explode(' ', $mill_time);
        $milis_time = sprintf('%d%03d',$timeInfo[1],$timeInfo[0] * 1000);
        return $milis_time;
    }
}