<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/8
 * Time: 9:54
 */

namespace common;


class Code
{
    const FAIL = 0;//操作失败
    const SUCCESS = 1;//操作成功
    const PARAM_ERROR = 100;//参数异常
    const DB_ERR = 101;//数据库操作异常
    const REQUEST_TOO_MANY = 102;//数据库操作异常
    const TOKEN_NO_FOUND = 103;//token未找到
    const TOKEN_EXPIRE = 104;//token过期
    const TOKEN_USE_NUM_LIMITED = 105;//token使用次数超额
    const TOKEN_USERNAME_ERR = 106;//token 用户不匹配
    const TOKEN_SIGN_ERR = 107;//token 签名算法错误
    const PKGID_NOT_FOUND = 108;// pkgid 未找到
    const DATA_NOT_FOUND = 404;//  数据未找到
    const PERMISSION_DENIED = 403;// 没有权限操作
    const LOGIN_DENIED = 405;// 没有权限操作
    const FREQUENTLY_OPERATION = 406 ;// 操作频繁

    public $kyCode = [
        0=>'成功',
        1=>'TOKEN 丢失（重新调用登录接口获取)',

    ];
}