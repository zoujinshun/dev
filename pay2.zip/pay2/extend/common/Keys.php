<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/8
 * Time: 10:50
 */

namespace common;


class Keys
{
    const SYNCACTIVEPLAYERS = "HA_syncActiveplayers";  //缓存Activeplayers最后的创建时间
    const SYNCGAMELOG = "HA_syncGamelog";      //缓存Gamelog最后的创建时间
    const SYNCONLINEPLAYERS = "HA_syncOnlineplayers";    //缓存Onlineplayers最后的创建时间
    const SYNCSTATISTICS = "HA_syncStatistics";   //缓存Statistics最后的创建时间
    const SYNCNEWUSER = "HA_syncnewuser";   //新增用户统计最后的创建时间
    const SYNCPOOLRECROD = "HA_syncPoolrecrod";   //当前奖池统计最后的创建时间
    const SYNCUSERLOGIN = "HA_syncUserLoginlogs";   //用户登陆日志最后的创建时间
    const SYNCUSERMAIN = "HA_syncRemain";   //留存率最后的创建时间

    public static function lockToken($username)
    {
        return "MA_1|$username";
    }

    public static function peipai($game, $uid)
    {
        return "MA_2|$game|$uid";
    }

    public static function peipaiData($game, $name)
    {
        return "MA_3|$game|$name";
    }

    public static function getPayIncomeDb($agent_id, $month)
    {
        return "MA_4|$agent_id|$month";
    }
    public static function getGameDataDb($table)
    {
        return "MA_5|$table";
    }
    public static function getGameDataDbB($table)
    {
        return "MA_6|$table";
    }
    public static function getUserIntegral($time,$username = '')
    {
        return "L_1|".$time.'|'.$username;
    }

    public static function getMessage($payload)
    {
        return "L_2|".$payload;
    }

    public static function getUserToken($agent,$pkg,$username)
    {
        return "L_3|".$agent."|".$pkg."|".$username;
    }

    /**
     * 监控记录获取 list key
     * @return string
     */
    public static function getRiskListKey()
    {
        return "MA_6_RISKLIST";
    }

    /**
     * 报警通知list key
     * @return string
     */
    public static function getRiskNotifyKey()
    {
        return "MA_7_RISKNOTIFY";
    }

    /**
     * 最后报警通知时间
     * @param $username
     * @return string
     */
    public static function getRiskNotifyLastTimeKey($username)
    {
        return "MA_7_RISKNOTIFY|$username";
    }

    public static function getUsersRankPromote($time)
    {
        return "L_4|".$time;
    }

    public static function getUsersFixedPromote($time)
    {
        return "L_5|".$time;
    }

    public static function getLimitKey($username){
        return "ML|" . strtoupper(md5($username)) . "|LIMIT";
    }

    public static function getPaytypeKey($paytype,$agent_id){
        return "ML|" . $paytype . "|" . $agent_id . "|PAYMENT";
    }

    public static function getLimitMoneyKey($payment_id,$merch_agent_id,$payment_type,$agent_id){
        return "ML|LIMIT|{$agent_id}|{$merch_agent_id}|{$payment_id}|{$payment_type}";
    }

    public static function getPaymentKey($pay_id,$agent_id){
        return "ML|" . strtoupper(md5($agent_id . '|' . $pay_id)) . "|LIMIT";
    }

    public static function getOrderKey($order_no){
        return "ML|" . $order_no . "|ORDER";
    }

    public static function getWithdrawKey($order_no){
        return "ML_WITHDRAW_" . $order_no . "_ORDER";
    }

    public static function getWithdrawMerchKey($agent_id){
        return "ML_WITHDRAW_" . $agent_id . "_ORDER";
    }
}