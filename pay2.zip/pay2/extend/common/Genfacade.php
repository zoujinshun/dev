<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/5/5
 * Time: 9:48
 */

namespace common;


use think\App;
use think\console\Command;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;

class Genfacade extends Command
{
    protected function configure()
    {
        $this->setName('facade')
            ->addArgument('name', Argument::REQUIRED, "facade name")
            ->setDescription('auto generate facade class');
    }

    protected function execute(Input $input, Output $output)
    {
        $name = trim($input->getArgument('name'));
        if($name == 'model'){
            $list = glob(APP_PATH.'/model/*');
            foreach ($list as $file)
            {
                $filename = basename($file);
                $tmp = <<<tmp
<?php
/**
 * Created by PhpStorm.
 * User: xiexingqiao
 * Date: 2019/4/29
 * Time: 20:36
 */

namespace app\\library\\facade\\model;


use think\\Facade;

class  className  extends Facade
{ 
    protected static function getFacadeClass()
    {
        return  \\app\\model\\className::class;
    }
}
tmp;

                $content = preg_replace("/className/",substr($filename,0,stripos($filename,'.')),$tmp);
                $dst= APP_PATH.'/library/facade/model/'.$filename;
                file_put_contents($dst,$content);
            }
            $output->writeln("success");
        }else if($name == 'service'){
            $list = glob(APP_PATH.'/service/*');
            foreach ($list as $file)
            {
                $filename = basename($file);
                $tmp = <<<tmp
<?php
/**
 * Created by PhpStorm.
 * User: xiexingqiao
 * Date: 2019/4/29
 * Time: 20:36
 */

namespace app\\library\\facade\\service;


use think\\Facade;

class  className  extends Facade
{ 
    protected static function getFacadeClass()
    {
        return  \\app\\service\\className::class;
    }
}
tmp;

                $content = preg_replace("/className/",substr($filename,0,stripos($filename,'.')),$tmp);
                $dst= APP_PATH.'/library/facade/service/'.$filename;
                file_put_contents($dst,$content);
            }
            $output->writeln("success");
        }else{
            $output->writeln("error");
        }
        $className= '';
      


    }
}