<?php
/**
 * Created by PhpStorm.
 * User: ADMIN
 * Date: 2019/9/20
 * Time: 15:43
 */
return [
    'key'=>'fc361cdb770aebc2126cc0dac989c896',

    'bank_info' => [
        'BOC'  => ['en'   => 'BOC', 'name' => '中国银行',],
        'CCB'  => ['en'   => 'CCB', 'name' => '中国建设银行',],
        'ABC'  => ['en'   => 'ABC', 'name' => '中国农业银行',],
        'ICBC' => ['en'   => 'ICBC', 'name' => '中国工商银行',],
        'CMB'  => ['en'   => 'CMB', 'name' => '招商银行',],
        'PABC' => ['en'   => 'PABC', 'name' => '平安银行',],
        'BCM'  => ['en'   => 'BCM', 'name' => '交通银行',],
        'HB'   => ['en' => 'HB', 'name' => '华夏银行',],
        'GDB'  => ['en'   => 'GDB', 'name' => '广发银行',],
        'CMBC' => ['en'   => 'CMBC', 'name' => '民生银行',],
        'CEB'  => ['en'   => 'CEB', 'name' => '光大银行',],
        'CIB'  => ['en'   => 'CIB', 'name' => '兴业银行',],
    ],
    'payment_info' => [
        '2' => 'wx_pay',
        '3' => 'union_pay',
        '4' => 'bank',
        '8' => 'QQ_wallet',
        '10' => 'bd_pay',
        '12' => 'jd_pay',
        '14' => 'QQ_scan',
        '15' => 'ali_pay'
    ],
    'bank_pay'=>[3,4],
];