<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
use think\facade\Env;

// +----------------------------------------------------------------------
// | Workerman设置 仅对 php think kafka 指令有效
// +----------------------------------------------------------------------
return [
    // 支持workerman的所有配置参数

    'daemonize'             => true,
    'pidFile'               => Env::get('runtime_path') . 'worker_kafka.pid',
    'logFile'               => Env::get('runtime_path') . 'worker_kafka.log',
    'taskList'              =>[//每个进程必须有timer字段标识进程类型
        'payincome'=>[//分表进程,
            'timer'                 =>false,//自定义字段，标识是否为定时器进程
            'status'                =>true,//启用
            'name'                  => 'payincome',//进程名
            'count'                 => 4,//进程数量
            'task'                  =>"\\cron\\Syncpayincomerecord::run",//执行任务
        ],
        'viplevel'=>[//vip处理进程，从kafka取任务，不是定时器
            'timer'                 =>false,//自定义字段，标识是否为定时器进程
            'status'                =>true,
            'name'                  => 'viplevel',
            'count'                 => 1,
            'task'                  =>[
                'function'             =>'\\cron\\UserVip::run',
                'arguments'             =>[],
            ],
        ],
//        'test'=>[//定时器进程
//            'timer'                 =>true,//自定义字段，标识是否为定时器进程
//            'status'                =>true,
//            'name'                  => 'test',
//            'count'                 => 1,
//            'task'                  =>[
//                'function'             =>'\\cron\\UserVip::test',
//                'arguments'             =>[],
//                'interval'          =>1,//秒数
//            ],
//        ],
    ],

];
