<?php
 
return [
    // master db
    'master' => [
        //稽核订单查询协议
\Protocol_id\AuditProtocolId::AUDIT_ORDER_QUERY_REQ => \Grpc_proto\Audit\AuditOrderQueryReq::class,
\Protocol_id\AuditProtocolId::AUDIT_ORDER_QUERY_RES => \Grpc_proto\Audit\AuditOrderQueryRsp::class,
//稽核订单新增协议
\Protocol_id\AuditProtocolId::AUDIT_ORDER_INSERT_REQ => \Grpc_proto\Audit\AuditOrderAddReq::class,
\Protocol_id\AuditProtocolId::AUDIT_ORDER_INSERT_RES => \Grpc_proto\Audit\AuditOrderAddRsp::class,
//稽核订单新增协议
\Protocol_id\AuditProtocolId::AUDIT_RESULT_UPDATE_REQ => \Grpc_proto\Audit\AuditOrderUpdateReq::class,
\Protocol_id\AuditProtocolId::AUDIT_RESULT_UPDATE_RES => \Grpc_proto\Audit\AuditOrderUpdateRsp::class,
//新增支付订单协议
\Protocol_id\PayProtoId::PAY_INSERT_PROTOCOL_ID_REQ => \Grpc_proto\Pay\PayOrdersAddReq::class,
\Protocol_id\PayProtoId::PAY_INSERT_PROTOCOL_ID_RSP => \Grpc_proto\Pay\PayOrdersAddRsp::class,
//修改支付订单协议
\Protocol_id\PayProtoId::PAY_UPDATE_PROTOCOL_ID_REQ => \Grpc_proto\Pay\PayOrderUpdateReq::class,
\Protocol_id\PayProtoId::PAY_UPDATE_PROTOCOL_ID_RSP => \Grpc_proto\Pay\PayOrderUpdateRsp::class,
//查询支付订单协议
\Protocol_id\PayProtoId::PAY_QUERY_PROTOCOL_ID_REQ => \Grpc_proto\Pay\PayOrderSelectReq::class,
\Protocol_id\PayProtoId::PAY_QUERY_PROTOCOL_ID_RSP => \Grpc_proto\Pay\PayOrderSelectRsp::class,
//查询单条订单数据协议
\Protocol_id\PayProtoId::PAY_QUERY_ROW_PROTOCOL_ID_REQ => \Grpc_proto\Pay\PayOrderQueryRowReq::class,
\Protocol_id\PayProtoId::PAY_QUERY_ROW_PROTOCOL_ID_RSP => \Grpc_proto\Pay\PayOrderQueryRowRsp::class,
//修改用户静态信息--批量
\Protocol_id\EUserDataProtocolId::USER_DATA_STATIC_UPDATE_ID_REQ => \Grpc_proto\User_data\UserDataStaticUpdateReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_STATIC_UPDATE_ID_RSP => \Grpc_proto\OperationReply::class,
//修改用户动态信息--批量
\Protocol_id\EUserDataProtocolId::USER_DATA_DYNAMIC_UPDATE_ID_REQ => \Grpc_proto\User_data\UserDataDynamicUpdateReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_DYNAMIC_UPDATE_ID_RSP => \Grpc_proto\OperationReply::class,
//新增会员--批量
\Protocol_id\EUserDataProtocolId::USER_DATA_ADD_USER_ID_REQ => \Grpc_proto\User_data\UserDataAddUserReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_ADD_USER_ID_RSP => \Grpc_proto\OperationReply::class,
//批量添加用户标签
\Protocol_id\EUserDataProtocolId::USER_DATA_ADD_TAG_ID_REQ => \Grpc_proto\User_data\UserDataAddTagReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_ADD_TAG_ID_RSP => \Grpc_proto\OperationReply::class,
//删除用户标签
\Protocol_id\EUserDataProtocolId::USER_DATA_DEL_TAG_ID_REQ => \Grpc_proto\User_data\UserDataDelTagReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_DEL_TAG_ID_RSP => \Grpc_proto\OperationReply::class,
//设置默认银行卡或取消默认银行卡
\Protocol_id\EUserDataProtocolId::USER_DATA_BANK_UDPATE_DEAFULT_CARD_REQ => \Grpc_proto\User_data\UserDataBankUpdateDefaultCardReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_BANK_UDPATE_DEAFULT_CARD_RSP => \Grpc_proto\User_data\UserDataBankUpdateDefaultCardRsp::class,
//删除银行卡
\Protocol_id\EUserDataProtocolId::USER_DATA_BANK_DELETE_CARD_REQ => \Grpc_proto\User_data\UserDataBankDeleteCardReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_BANK_DELETE_CARD_RSP => \Grpc_proto\User_data\UserDataBankDeleteCardRsp::class,
//添加银行卡
\Protocol_id\EUserDataProtocolId::USER_DATA_BANK_ADD_CARD_REQ => \Grpc_proto\User_data\UserDataBankAddCardReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_BANK_ADD_CARD_RSP => \Grpc_proto\User_data\UserDataBankAddCardRsp::class,
//修改银行卡数据
\Protocol_id\EUserDataProtocolId::USER_DATA_BANK_MODIFY_CARD_REQ => \Grpc_proto\User_data\UserDataBankModifyCardReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_BANK_MODIFY_CARD_RSP => \Grpc_proto\User_data\UserDataBankModifyCardRsp::class,

    ],
    'slave' => [
        //会员动态数据分页列表
\Protocol_id\EUserDataProtocolId::USER_DATA_DYNAMIC_RECORD_ID_REQ => \Grpc_proto\User_data\UserDataDynamicRecordReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_DYNAMIC_RECORD_ID_RSP => \Grpc_proto\User_data\UserDataDynamicRecordRsp::class,
//会员静态数据分页列表
\Protocol_id\EUserDataProtocolId::USER_DATA_STATIC_RECORD_ID_REQ => \Grpc_proto\User_data\UserDataStaticRecordReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_STATIC_RECORD_ID_RSP => \Grpc_proto\User_data\UserDataStaticRecordRsp::class,
//会员动态详情
\Protocol_id\EUserDataProtocolId::USER_DATA_DYNAMIC_DETAIL_ID_REQ => \Grpc_proto\User_data\UserDataDynamicInfoReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_DYNAMIC_DETAIL_ID_RSP => \Grpc_proto\User_data\UserDataDynamicInfoRsp::class,
//注册人数
\Protocol_id\EUserDataProtocolId::USER_DATA_REGISTER_ID_REQ => \Grpc_proto\User_data\UserDataRegisterStatisticReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_REGISTER_ID_RSP => \Grpc_proto\User_data\UserDataStatisticRsp::class,
//投注人数
\Protocol_id\EUserDataProtocolId::USER_DATA_BET_ID_REQ => \Grpc_proto\User_data\UserDataBetStatisticReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_BET_ID_RSP => \Grpc_proto\User_data\UserDataStatisticRsp::class,
//首存人数
\Protocol_id\EUserDataProtocolId::USER_DATA_FIRST_DEPOSIT_ID_REQ => \Grpc_proto\User_data\UserDataFirstDepositStatisticReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_FIRST_DEPOSIT_ID_RSP => \Grpc_proto\User_data\UserDataStatisticRsp::class,
//入款人数 
\Protocol_id\EUserDataProtocolId::USER_DATA_DEPOSIT_ID_REQ => \Grpc_proto\User_data\UserDataDepositStatisticReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_DEPOSIT_ID_RSP => \Grpc_proto\User_data\UserDataStatisticRsp::class,
//出款人数
\Protocol_id\EUserDataProtocolId::USER_DATA_WITHDRAW_ID_REQ => \Grpc_proto\User_data\UserDataWithdrawStatisticReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_WITHDRAW_ID_RSP => \Grpc_proto\User_data\UserDataStatisticRsp::class,
//新增设备数
\Protocol_id\EUserDataProtocolId::USER_DATA_DEVICE_ID_REQ => \Grpc_proto\User_data\UserDataDeviceStatisticReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_DEVICE_ID_RSP => \Grpc_proto\User_data\UserDataStatisticRsp::class,
//存取款总览
\Protocol_id\EUserDataProtocolId::USER_DATA_TOTAL_DEPOSIT_ID_REQ => \Grpc_proto\User_data\UserDataTotalDepositStatisticReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_TOTAL_DEPOSIT_ID_RSP => \Grpc_proto\User_data\UserDataStatisticRsp::class,
//
\Protocol_id\EUserDataProtocolId::USER_DATA_TOTAL_WITHDRAW_ID_REQ => \Grpc_proto\User_data\UserDataWithdrawStatisticReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_TOTAL_WITHDRAW_ID_RSP => \Grpc_proto\User_data\UserDataStatisticRsp::class,
//获取用户标签
\Protocol_id\EUserDataProtocolId::USER_DATA_USER_TAG_ID_REQ => \Grpc_proto\User_data\UserDataUserTagRecordReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_USER_TAG_ID_RSP => \Grpc_proto\User_data\UserDataUserTagRecordRsp::class,
// 查找最近活跃id用户
\Protocol_id\EUserDataProtocolId::USER_DATA_LOGIN_IP_REQ => \Grpc_proto\User_data\UserDataLoginIpReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_LOGIN_IP_RSP => \Grpc_proto\User_data\UserDataLoginIpRsp::class,
// 统计在线人数（去重）请求
\Protocol_id\EUserDataProtocolId::USER_ONLINE_COUNT_REQ => \Grpc_proto\User_data\UserOnlineCountReq::class,
\Protocol_id\EUserDataProtocolId::USER_ONLINE_COUNT_RSP => \Grpc_proto\User_data\UserOnlineCountRsp::class,
//当前在线-日累计在线时长(按用户分组) 请求
\Protocol_id\EUserDataProtocolId::USER_ONLINE_SECONDS_REQ => \Grpc_proto\User_data\UserOnlineSecondsSumReq::class,
\Protocol_id\EUserDataProtocolId::USER_ONLINE_SECONDS_RSP => \Grpc_proto\User_data\UserOnlineSecondsSumRsp::class,
// 查询用户登录记录
\Protocol_id\EUserDataProtocolId::USER_SELECT_RECORD_REQ => \Grpc_proto\User_data\UserSelectRecordReq::class,
\Protocol_id\EUserDataProtocolId::USER_SELECT_RECORD_RSP => \Grpc_proto\User_data\UserSelectRecordRsp::class,
// 统计不同设备登录数请求
\Protocol_id\EUserDataProtocolId::USER_COUNT_OS_REQ => \Grpc_proto\User_data\UserCountOsReq::class,
\Protocol_id\EUserDataProtocolId::USER_COUNT_OS_RSP => \Grpc_proto\User_data\UserCountOsRsp::class,
// 查询按游戏类型分组统计数据请求
\Protocol_id\EUserDataProtocolId::USER_SELECT_DAY_REQ => \Grpc_proto\User_data\UserSelectDayRecordReq::class,
\Protocol_id\EUserDataProtocolId::USER_SELECT_DAY_RSP => \Grpc_proto\User_data\UserSelectDayRecordRsp::class,
//获取用户所有的直属会员请求
\Protocol_id\EUserDataProtocolId::USER_RELATION_SELECT_REQ => \Grpc_proto\User_data\UserRelationSelectReq::class,
\Protocol_id\EUserDataProtocolId::USER_RELATION_SELECT_RSP => \Grpc_proto\User_data\UserRelationSelectRsp::class,
//会员静态信息详情
\Protocol_id\EUserDataProtocolId::USER_DATA_STATIC_DETAIL_ID_REQ => \Grpc_proto\User_data\UserDataStaticInfoReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_STATIC_DETAIL_ID_RSP => \Grpc_proto\User_data\UserDataStaticInfoRsp::class,
// 查询用户的所有银行卡信息
\Protocol_id\EUserDataProtocolId::USER_DATA_BANK_QUERY_USER_ALL_CARD_REQ => \Grpc_proto\User_data\UserDataBankQueryUserAllCardReq::class,
\Protocol_id\EUserDataProtocolId::USER_DATA_BANK_QUERY_USER_ALL_CARD_RSP => \Grpc_proto\User_data\UserDataBankQueryUserAllCardRsp::class,

    ],
];   