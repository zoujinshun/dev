<?php

// +----------------------------------------------------------------------
// | 支付通道信息设置
// +----------------------------------------------------------------------
return [
    'BetPay' => [
        'payment' => [
            '2'=>['wap'=>8003,'scan'=>8002],
            '3'=>['wap'=>8001,'scan'=>8014],
            '11'=>['wap'=>8013],
            '12'=>['wap'=>8012,'scan'=>8011],
            '14'=>['scan'=>8009],
            '15'=>['wap'=>8007,'scan'=>8006],
        ],
        'appId' => '3bf6813ffcfa4878bcfe3366072012df',
        'notify_url' => '/notify/betPay.php',
        'return_url' => '/notify/betPay.php',
        'pay_url' => 'http://api.51betpay.net/api/pay/create_order',
        'query_url' => 'http://api.51betpay.net/api/pay/query_order'
    ],
    'BaoPay'=>[
        'payment' => [
            '2'=>['scan'=>'WEIXIN'],
            '15'=>['scan'=>'ALIPAY'],
        ],
        'notify_url' => '/notify/baopay',
        'return_url' => 'http://www.baidu.com',
        'pay_url' => 'http://api.blpay1.com/PayBank.aspx',
        'query_url' => 'http://api.blpay1.com/Services/LwPay/MobilePayResult.aspx'
    ],
    'WheelPay'=>[
        'payment' => [
            '2'=>['scan'=>'WEIXIN'],
            '15'=>['scan'=>'ALIPAY'],
        ],
        'notify_url' => '/notify/wheelpay',
        'return_url' => 'http://www.baidu.com',
        'pay_url' => 'http://gate.motel147.com/Paybank.aspx',
        'query_url' => 'http://gate.motel147.com/Services/LwPay/MobilePayResult.aspx'
    ],
    'ApplePay'=>[
        'payment' => [
            '2'=>['wap'=>'wxwap','scan'=>'wxqrcode'],
            '15'=>['wap'=>'wap','scan'=>'qrcode'],
        ],
        'notify_url' => '/notify/applepay',
        'return_url' => 'http://www.baidu.com',
        'pay_url' => 'http://api.blpay1.com/PayBank.aspx',
        'query_url' => 'http://api.blpay1.com/Services/LwPay/MobilePayResult.aspx'
    ],
    'BaiPay'=>[
        'payment' => [
            '2'=>['wap'=>'WXWAP'],
        ],
        'notify_url' => '/notify/baipay',
        'return_url' => 'http://www.baidu.com',
        'pay_url' => 'http://api.baihuizfapi.com/interface/chargebank.aspx',
        'query_url' => 'http://api.blpay1.com/Services/LwPay/MobilePayResult.aspx'
    ],
    'Pay686'=>[
        'payment' => [
            '15'=>['wap'=>'alipay','scan'=>'aliqr']
        ],
        'notify_url' => '/notify/pay686',
        'return_url' => 'http://www.baidu.com',
        'pay_url' => 'http://120.77.165.254/index.php/686cz/trade/pay',
        //'query_url' => 'http://api.blpay1.com/Services/LwPay/MobilePayResult.aspx'
    ],
    'DdPay'=>[
        'payment' => [
            '3' => ['scan'=>912],
            '12' => ['scan' => 911]
        ],
        'notify_url' => '/notify/didaPay',
        'return_url' => 'http://www.baidu.com',
        'pay_url' => 'https://ddbay.ddongbay.com/index/pay/gateway',
        'query_url' => 'https://ddbay.ddongbay.com/index/pay/trade_query.html'
    ],
    'GaoshengPay'=>[
        'payment' => [
            '2' => ['wap'=>'WX_WAP','scan'=>'WX'],
            '15' => ['wap'=>'ZFB_WAP','scan'=>'ZFB']
        ],
        'notify_url' => '/notify/gaoshengPay',
        'return_url' => 'http://www.baidu.com',
        'pay_url' => 'http://gway.yt888f.com:7060/api/qrCodePay.action',
        'query_url' => 'https://ddbay.ddongbay.com/index/pay/trade_query.html'
    ],
    'HengPay' => [
        'payment' => [
            '2' => ['wap'=>'80001','scan'=>'60001'],
            '15' => ['wap'=>'80002','scan'=>'60002']
        ],
        'notify_url' => '/notify/hengPay',
        'return_url' => 'http://www.baidu.com',
        'pay_url' => 'http://api.kuaile8899.com:8088/pay/apply.shtml',
//        'query_url' => 'https://ddbay.ddongbay.com/index/pay/trade_query.html'
    ],
    "JinPay" => [
        'payment'=>[
            '2' => ['wap'=>'wx_wap','scan'=>'wx'],
            '15' => ['wap'=>'alipay_wap','scan'=>'alipay'],
            '12' => ['wap'=>'jd_wap','scan'=>'jd'],
            '4' => ['web'=>'web']
        ],
        'notify_url' => '/notify/jinPay',
        'return_url' => 'http://www.baidu.com',
        'wx_url' => 'http://interface.yjfpay.com:8070/pay.do',
        'ali_url' => 'http://interface.yjfpay.com:8050/pay.do',
        'pay_url' => 'http://interface.yjfpay.com:8080/pay.do',
//        'query_url' => 'https://ddbay.ddongbay.com/index/pay/trade_query.html'
    ]

];