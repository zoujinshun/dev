<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/4/29
 * Time: 17:09
 */


namespace think;
!defined('APP_PATH') && define('APP_PATH', __DIR__ . '/../application/');
!defined('VIEW_PATH') && define('VIEW_PATH',__DIR__ . '/view');
// 加载基础文件
require_once __DIR__ . '/../thinkphp/base.php';

// 执行应用并响应
Container::get('app')->path(APP_PATH)->run()->send();